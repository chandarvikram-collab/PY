import React, { useState, useEffect, useRef, ChangeEvent } from "react";
import { FoodEntry, UserProfile, MealCategory } from "./types";
import Dashboard from "./components/Dashboard";
import TrackerTab from "./components/TrackerTab";
import ProfileTab from "./components/ProfileTab";
import BarcodeScanner from "./components/BarcodeScanner";
import BarcodeConfirm from "./components/BarcodeConfirm";
import VisionConfirm from "./components/VisionConfirm";
import { 
  Flame, 
  BookOpen, 
  Scan, 
  User, 
  TrendingUp, 
  AlertCircle, 
  Sparkles, 
  Camera, 
  Loader2, 
  RefreshCw,
  Heart
} from "lucide-react";

const DEFAULT_PROFILE: UserProfile = {
  name: "Athlete",
  age: 26,
  weight: 78,
  height: 182,
  goal: "lose",
  dailyCalorieGoal: 2150,
  proteinGoal: 160,
  carbsGoal: 200,
  fatGoal: 65,
};

export default function App() {
  // Navigation & Date State
  const [activeTab, setActiveTab] = useState<"home" | "tracker" | "scan" | "profile">("home");
  const [selectedDateStr, setSelectedDateStr] = useState<string>("");

  // Core App Data
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [foodEntries, setFoodEntries] = useState<FoodEntry[]>([]);

  // Workflow State Machines
  const [showScanner, setShowScanner] = useState(false);
  
  // Barcode Lookup Workflow
  const [barcodeLoading, setBarcodeLoading] = useState(false);
  const [barcodeError, setBarcodeError] = useState<string | null>(null);
  const [scannedProduct, setScannedProduct] = useState<any | null>(null);

  // Vision Analysis Workflow
  const [visionLoading, setVisionLoading] = useState(false);
  const [visionError, setVisionError] = useState<string | null>(null);
  const [visionResult, setVisionResult] = useState<any | null>(null);
  const [visionImageSrc, setVisionImageSrc] = useState<string>("");
  const [loadingStepText, setLoadingStepText] = useState("Preparing photo file...");

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Set today's date on initial mount and load local data
  useEffect(() => {
    const today = new Date().toISOString().split("T")[0];
    setSelectedDateStr(today);

    // Load Profile
    const savedProfile = localStorage.getItem("calorie_tracker_profile");
    if (savedProfile) {
      try {
        setProfile(JSON.parse(savedProfile));
      } catch (e) {
        console.error("Error parsing profile:", e);
      }
    }

    // Load Food Log History
    const savedEntries = localStorage.getItem("calorie_tracker_food_entries");
    if (savedEntries) {
      try {
        setFoodEntries(JSON.parse(savedEntries));
      } catch (e) {
        console.error("Error parsing food entries:", e);
      }
    }
  }, []);

  // Sync profile edits to localStorage
  const handleSaveProfile = (newProfile: UserProfile) => {
    setProfile(newProfile);
    localStorage.setItem("calorie_tracker_profile", JSON.stringify(newProfile));
  };

  // Date Navigation offsets helper
  const handleOffsetDate = (daysOffset: number) => {
    if (!selectedDateStr) return;
    const parts = selectedDateStr.split("-");
    const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
    d.setDate(d.getDate() + daysOffset);
    setSelectedDateStr(d.toISOString().split("T")[0]);
  };

  const handleSetSpecificDate = (dateStr: string) => {
    setSelectedDateStr(dateStr);
  };

  // 1. Food Entries modification handlers
  const handleAddManualEntry = (entry: Omit<FoodEntry, "id" | "dateStr">) => {
    const newEntry: FoodEntry = {
      ...entry,
      id: Math.random().toString(36).substring(2, 9),
      dateStr: selectedDateStr,
    };
    const updated = [newEntry, ...foodEntries];
    setFoodEntries(updated);
    localStorage.setItem("calorie_tracker_food_entries", JSON.stringify(updated));
  };

  const handleUpdateEntryQuantity = (id: string, quantity: number) => {
    const updated = foodEntries.map((entry) => {
      if (entry.id === id) {
        return { ...entry, quantity };
      }
      return entry;
    });
    setFoodEntries(updated);
    localStorage.setItem("calorie_tracker_food_entries", JSON.stringify(updated));
  };

  const handleDeleteEntry = (id: string) => {
    const updated = foodEntries.filter((entry) => entry.id !== id);
    setFoodEntries(updated);
    localStorage.setItem("calorie_tracker_food_entries", JSON.stringify(updated));
  };

  // 2. Barcode scanner workflow handlers
  const handleScanSuccess = async (barcode: string) => {
    setShowScanner(false);
    setBarcodeLoading(true);
    setBarcodeError(null);
    setScannedProduct(null);

    try {
      const res = await fetch(`/api/barcode/${barcode}`);
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || `Barcode lookup returned status ${res.status}`);
      }
      const data = await res.json();
      setScannedProduct(data);
    } catch (err: any) {
      console.error("Barcode fetch failed:", err);
      setBarcodeError(err.message || "Failed to find product in Open Food Facts database.");
    } finally {
      setBarcodeLoading(false);
    }
  };

  const handleConfirmBarcodeEntry = (entry: Omit<FoodEntry, "id" | "dateStr">) => {
    handleAddManualEntry(entry);
    setScannedProduct(null);
  };

  // 3. AI Food Photo analysis workflow handlers
  const triggerCameraInput = () => {
    fileInputRef.current?.click();
  };

  const handlePhotoSelected = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setVisionLoading(true);
    setVisionError(null);
    setVisionResult(null);
    setLoadingStepText("Reading image capture stream...");

    const reader = new FileReader();
    reader.onload = async (event) => {
      const base64Data = event.target?.result as string;
      setVisionImageSrc(base64Data);

      // Extract raw base64 and mime type
      const match = base64Data.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (!match) {
        setVisionError("Invalid image capture file format.");
        setVisionLoading(false);
        return;
      }

      const mimeType = match[1];
      const rawBase64 = match[2];

      try {
        setLoadingStepText("Uploading photo to secure AI server...");
        const response = await fetch("/api/analyze-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            image: rawBase64,
            mimeType: mimeType
          })
        });

        if (!response.ok) {
          const errData = await response.json();
          throw new Error(errData.error || `AI model returned status ${response.status}`);
        }

        setLoadingStepText("Gemini estimating macronutrients & portions...");
        const result = await response.json();
        
        if (result.error) {
          throw new Error(result.error);
        }

        setVisionResult(result);
      } catch (err: any) {
        console.error("Vision analyze failed:", err);
        setVisionError(err.message || "Failed to analyze food image. Please check API key setup.");
      } finally {
        setVisionLoading(false);
        if (fileInputRef.current) fileInputRef.current.value = ""; // Clear file
      }
    };

    reader.readAsDataURL(file);
  };

  const handleConfirmVisionEntries = (entries: Omit<FoodEntry, "id" | "dateStr">[]) => {
    entries.forEach((entry) => handleAddManualEntry(entry));
    setVisionResult(null);
  };

  return (
    <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center font-sans antialiased text-white selection:bg-red-500/20 relative overflow-hidden p-0 md:p-4">
      
      {/* Background ambient lighting blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-1/4 left-1/3 w-96 h-96 rounded-full bg-red-600/10 blur-[120px] animate-float-slow" />
        <div className="absolute bottom-1/3 right-1/4 w-[400px] h-[400px] rounded-full bg-red-950/20 blur-[130px] animate-float-slower" />
        <div className="absolute top-1/2 right-1/3 w-80 h-80 rounded-full bg-neutral-800/10 blur-[100px]" />
      </div>

      {/* Centered Mobile Frame container */}
      <div className="w-full max-w-md min-h-screen md:min-h-[850px] bg-[#070707]/80 md:rounded-3xl border border-white/5 shadow-[0_0_80px_rgba(0,0,0,0.85)] flex flex-col relative overflow-hidden z-10 backdrop-blur-2xl">
        
        {/* Internal subtle glow for frosted elements to reflect over */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-20 -left-10 w-48 h-48 rounded-full bg-red-600/15 blur-[60px]" />
          <div className="absolute bottom-40 -right-10 w-60 h-60 rounded-full bg-red-900/10 blur-[80px]" />
        </div>

        {/* Hidden File Input for mobile camera photo capture */}
        <input
          type="file"
          ref={fileInputRef}
          accept="image/*"
          capture="environment"
          onChange={handlePhotoSelected}
          className="hidden"
        />

        {/* Top Status Header */}
        <header className="px-5 py-4 border-b border-white/10 bg-black/40 backdrop-blur-md flex items-center justify-between sticky top-0 z-45">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center shadow-lg shadow-red-600/20">
              <Flame className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div className="leading-none">
              <span className="text-sm font-black tracking-wider uppercase text-white">REDLINE</span>
              <span className="block text-[8px] text-red-500 uppercase font-bold tracking-widest mt-0.5">AI Nutrition</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-right">
              <span className="block text-[9px] text-white/40 uppercase tracking-widest">Active User</span>
              <span className="text-xs font-bold text-red-500 font-mono truncate max-w-[80px] block">
                {profile.name || "Athlete"}
              </span>
            </div>
            <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
              <User className="w-4 h-4 text-red-500" />
            </div>
          </div>
        </header>

        {/* Core Screen View Router */}
        <main className="flex-1 overflow-y-auto bg-transparent relative pb-20 z-10">
          {activeTab === "home" && (
            <Dashboard
              profile={profile}
              foodEntries={foodEntries}
              selectedDateStr={selectedDateStr}
              onChangeDate={handleOffsetDate}
              onSetSpecificDate={handleSetSpecificDate}
              onTriggerScanner={() => setShowScanner(true)}
              onTriggerPhoto={triggerCameraInput}
              onTriggerManualAdd={() => setActiveTab("tracker")}
            />
          )}

          {activeTab === "tracker" && (
            <TrackerTab
              foodEntries={foodEntries}
              selectedDateStr={selectedDateStr}
              onUpdateQuantity={handleUpdateEntryQuantity}
              onDeleteEntry={handleDeleteEntry}
              onAddManualEntry={handleAddManualEntry}
            />
          )}

          {activeTab === "scan" && (
            <div className="p-5 flex flex-col items-center justify-center text-center h-full min-h-[500px] space-y-6">
              <div className="w-16 h-16 rounded-full bg-red-600/10 flex items-center justify-center border border-red-500/20 animate-pulse">
                <Scan className="w-8 h-8 text-red-500" />
              </div>
              <div>
                <h2 className="text-lg font-bold uppercase tracking-tight">Launch Scanner Core</h2>
                <p className="text-xs text-neutral-400 max-w-xs mt-1.5 leading-relaxed">
                  Hold a package close to your camera to auto-parse calorie and macro stats using Open Food Facts API.
                </p>
              </div>
              <button
                onClick={() => setShowScanner(true)}
                className="px-6 py-3 bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white font-bold text-xs uppercase tracking-widest rounded-lg transition"
              >
                Start Barcode Scanner
              </button>
            </div>
          )}

          {activeTab === "profile" && (
            <ProfileTab
              profile={profile}
              onSaveProfile={handleSaveProfile}
            />
          )}
        </main>

        {/* Global Floating Modals & Loaders */}

        {/* 1. Barcode Scanner Camera Overlay */}
        {showScanner && (
          <BarcodeScanner
            onScanSuccess={handleScanSuccess}
            onClose={() => setShowScanner(false)}
          />
        )}

        {/* 2. Loading State: Barcode Lookup */}
        {barcodeLoading && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90">
            <div className="text-center space-y-4">
              <RefreshCw className="w-12 h-12 text-red-500 animate-spin mx-auto" />
              <div>
                <h3 className="font-extrabold text-sm uppercase tracking-widest">Searching Barcodes</h3>
                <p className="text-xs text-neutral-400 mt-1">Connecting to Open Food Facts database...</p>
              </div>
            </div>
          </div>
        )}

        {/* 3. Confirmation Dialog: Barcode Item */}
        {scannedProduct && (
          <BarcodeConfirm
            product={scannedProduct}
            onConfirm={handleConfirmBarcodeEntry}
            onCancel={() => setScannedProduct(null)}
          />
        )}

        {/* 4. Loading State: Vision Analysis */}
        {visionLoading && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95">
            <div className="text-center space-y-5 max-w-xs">
              <div className="relative w-16 h-16 mx-auto flex items-center justify-center">
                <Loader2 className="w-12 h-12 text-red-600 animate-spin absolute" />
                <Camera className="w-5 h-5 text-red-500 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-sm uppercase tracking-wider">AI Photo Analysis</h3>
                <p className="text-[11px] text-red-500 font-bold uppercase tracking-wider animate-pulse font-mono">
                  {loadingStepText}
                </p>
                <p className="text-[10px] text-neutral-400 leading-relaxed pt-1.5">
                  Analyzing plate ingredients, estimating gram portions, and calculating average nutritional distributions.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* 5. Confirmation Dialog: AI Vision Items */}
        {visionResult && (
          <VisionConfirm
            imageSrc={visionImageSrc}
            result={visionResult}
            onConfirm={handleConfirmVisionEntries}
            onCancel={() => setVisionResult(null)}
          />
        )}

        {/* Global Error Alerts toasts */}
        {(barcodeError || visionError) && (
          <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-[90%] max-w-sm bg-neutral-900 border border-red-900 rounded-lg p-3.5 flex items-start gap-3 shadow-2xl animate-bounce">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-xs text-white uppercase tracking-wider">Operation Error</h4>
              <p className="text-[11px] text-neutral-400 leading-normal mt-0.5">
                {barcodeError || visionError}
              </p>
              <button 
                onClick={() => {
                  setBarcodeError(null);
                  setVisionError(null);
                }}
                className="text-[10px] text-red-400 hover:text-red-300 font-bold uppercase tracking-widest mt-1.5 block"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Bottom Navigation Bar */}
        <nav className="absolute bottom-0 left-0 right-0 h-16 border-t border-white/10 bg-black/45 backdrop-blur-lg flex items-center justify-around px-2 z-40">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex flex-col items-center justify-center flex-1 h-full transition-all relative ${
              activeTab === "home" ? "text-red-500 scale-105" : "text-white/40 hover:text-white/70"
            }`}
          >
            <Flame className="w-5 h-5" />
            <span className="text-[9px] uppercase font-bold tracking-wider mt-1">Home</span>
            {activeTab === "home" && <div className="absolute bottom-1 w-6 h-[2px] bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)]" />}
          </button>

          <button
            onClick={() => setActiveTab("tracker")}
            className={`flex flex-col items-center justify-center flex-1 h-full transition-all relative ${
              activeTab === "tracker" ? "text-red-500 scale-105" : "text-white/40 hover:text-white/70"
            }`}
          >
            <BookOpen className="w-5 h-5" />
            <span className="text-[9px] uppercase font-bold tracking-wider mt-1">Tracker</span>
            {activeTab === "tracker" && <div className="absolute bottom-1 w-6 h-[2px] bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)]" />}
          </button>

          <button
            onClick={() => setActiveTab("scan")}
            className={`flex flex-col items-center justify-center flex-1 h-full transition-all relative ${
              activeTab === "scan" ? "text-red-500 scale-105" : "text-white/40 hover:text-white/70"
            }`}
          >
            <Scan className="w-5 h-5" />
            <span className="text-[9px] uppercase font-bold tracking-wider mt-1">Scan</span>
            {activeTab === "scan" && <div className="absolute bottom-1 w-6 h-[2px] bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)]" />}
          </button>

          <button
            onClick={() => setActiveTab("profile")}
            className={`flex flex-col items-center justify-center flex-1 h-full transition-all relative ${
              activeTab === "profile" ? "text-red-500 scale-105" : "text-white/40 hover:text-white/70"
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[9px] uppercase font-bold tracking-wider mt-1">Profile</span>
            {activeTab === "profile" && <div className="absolute bottom-1 w-6 h-[2px] bg-red-500 rounded-full shadow-[0_0_8px_rgba(239,68,68,0.8)]" />}
          </button>
        </nav>

      </div>
    </div>
  );
}
