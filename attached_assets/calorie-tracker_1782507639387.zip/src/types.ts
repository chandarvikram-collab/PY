export type MealCategory = 'Breakfast' | 'Lunch' | 'Dinner' | 'Snacks';

export interface UserProfile {
  name: string;
  age: number;
  weight: number; // in kg
  height: number; // in cm
  goal: 'lose' | 'maintain' | 'gain';
  dailyCalorieGoal: number;
  proteinGoal: number; // in grams
  carbsGoal: number; // in grams
  fatGoal: number; // in grams
}

export interface FoodEntry {
  id: string;
  name: string;
  brand?: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
  servingSize: string;
  quantity: number; // multiplier of servingSize (e.g. 1, 1.5, 2)
  category: MealCategory;
  dateStr: string; // YYYY-MM-DD
}

export interface DailySummary {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}
