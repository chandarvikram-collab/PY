import { FoodEntry, UserProfile } from "../types";
import { Plus, Camera, Scan, ChevronLeft, ChevronRight, Flame, Dumbbell, Apple, Droplet, Calendar } from "lucide-react";

interface DashboardProps {
  profile: UserProfile;
  foodEntries: FoodEntry[];
  selectedDateStr: string;
  onChangeDate: (offset: number) => void;
  onSetSpecificDate: (dateStr: string) => void;
  onTriggerScanner: () => void;
  onTriggerPhoto: () => void;
  onTriggerManualAdd: () => void;
}

export default function Dashboard({
  profile,
  foodEntries,
  selectedDateStr,
  onChangeDate,
  onSetSpecificDate,
  onTriggerScanner,
  onTriggerPhoto,
  onTriggerManualAdd
}: DashboardProps) {
  
  // Calculate today's totals
  const dayEntries = foodEntries.filter(entry => entry.dateStr === selectedDateStr);
  const totalCalories = dayEntries.reduce((sum, entry) => sum + (entry.calories || 0), 0);
  const totalProtein = dayEntries.reduce((sum, entry) => sum + (entry.protein || 0), 0);
  const totalCarbs = dayEntries.reduce((sum, entry) => sum + (entry.carbohydrates || 0), 0);
  const totalFat = dayEntries.reduce((sum, entry) => sum + (entry.fat || 0), 0);

  const calRemaining = Math.max(0, profile.dailyCalorieGoal - totalCalories);
  const isOverGoal = totalCalories > profile.dailyCalorieGoal;

  // Percentage calculations
  const calPercent = Math.min(100, (totalCalories / profile.dailyCalorieGoal) * 100);
  const proteinPercent = Math.min(100, (totalProtein / profile.dailyCalorieGoal) * 100); // just generic placeholders if we do ratio
  const protRatio = profile.proteinGoal ? Math.min(100, (totalProtein / profile.proteinGoal) * 100) : 0;
  const carbsRatio = profile.carbsGoal ? Math.min(100, (totalCarbs / profile.carbsGoal) * 100) : 0;
  const fatRatio = profile.fatGoal ? Math.min(100, (totalFat / profile.fatGoal) * 100) : 0;

  // Format date readable
  const getReadableDate = (dateStr: string) => {
    const today = new Date().toISOString().split("T")[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
    
    if (dateStr === today) return "Today";
    if (dateStr === yesterday) return "Yesterday";
    
    const parts = dateStr.split("-");
    if (parts.length === 3) {
      const d = new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
      return d.toLocaleDateString("en-US", { weekday: 'short', month: 'short', day: 'numeric' });
    }
    return dateStr;
  };

  return (
    <div className="p-4 max-w-md mx-auto space-y-6 text-white pb-24 font-sans">
      
      {/* Dynamic Date Header */}
      <div className="flex items-center justify-between glass-card rounded-2xl p-2.5 shadow-lg">
        <button 
          onClick={() => onChangeDate(-1)}
          className="p-1.5 hover:bg-white/10 rounded-xl text-white/60 hover:text-white transition active:scale-95"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-1.5 font-bold text-sm tracking-tight text-white uppercase">
          <Calendar className="w-4 h-4 text-red-500 animate-pulse" />
          <span>{getReadableDate(selectedDateStr)}</span>
          <span className="text-[10px] text-white/40 font-mono">({selectedDateStr})</span>
        </div>
        <button 
          onClick={() => onChangeDate(1)}
          className="p-1.5 hover:bg-white/10 rounded-xl text-white/60 hover:text-white transition active:scale-95"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      {/* Hero Circular Progress Panel */}
      <div className="glass-card rounded-3xl p-6 relative overflow-hidden shadow-xl shadow-black/30">
        {/* Soft glowing ambient drop in the card corner */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-red-600/10 rounded-full blur-2xl pointer-events-none" />
        
        <div className="flex items-center justify-between gap-4">
          
          {/* Circular/Visual representation */}
          <div className="relative flex items-center justify-center w-28 h-28">
            <svg className="w-full h-full transform -rotate-90">
              {/* Background ring */}
              <circle
                cx="56"
                cy="56"
                r="48"
                className="stroke-white/10 fill-none"
                strokeWidth="8"
              />
              {/* Progress ring */}
              <circle
                cx="56"
                cy="56"
                r="48"
                className="stroke-red-600 fill-none transition-all duration-500 ease-out"
                strokeWidth="8"
                strokeDasharray={2 * Math.PI * 48}
                strokeDashoffset={2 * Math.PI * 48 * (1 - calPercent / 100)}
                strokeLinecap="round"
              />
            </svg>
            
            {/* Center Text */}
            <div className="absolute text-center flex flex-col items-center">
              <span className="text-xl font-black font-mono leading-none tracking-tight text-white">{totalCalories}</span>
              <span className="text-[9px] uppercase tracking-wider font-semibold text-white/40 mt-1">Logged</span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex-1 space-y-1.5">
            <span className="text-[10px] text-red-500 uppercase tracking-widest font-black flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-red-500/15 animate-bounce" /> Energy Summary
            </span>
            <div className="space-y-0.5">
              <h2 className="text-2xl font-black tracking-tight">
                {isOverGoal ? (
                  <span className="text-amber-500">+{totalCalories - profile.dailyCalorieGoal} Over</span>
                ) : (
                  <span>{calRemaining} kcal</span>
                )}
              </h2>
              <p className="text-[11px] text-white/50">
                {isOverGoal ? "You have exceeded your calorie limit" : "Remaining to stay on target"}
              </p>
            </div>

            <div className="flex gap-4 pt-2 border-t border-white/10 mt-1.5">
              <div>
                <span className="block text-[9px] text-white/40 uppercase font-semibold">Daily Goal</span>
                <span className="text-xs font-bold font-mono text-white/80">{profile.dailyCalorieGoal} kcal</span>
              </div>
              <div>
                <span className="block text-[9px] text-white/40 uppercase font-semibold">Progress</span>
                <span className="text-xs font-bold font-mono text-white/80">{Math.round(calPercent)}%</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Quick Logging Buttons Grid */}
      <div className="grid grid-cols-3 gap-2.5">
        <button
          onClick={onTriggerScanner}
          className="glass-card hover:bg-white/10 hover:border-white/20 active:scale-[0.97] p-3.5 rounded-2xl transition flex flex-col items-center justify-center gap-2 group text-center cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 group-hover:bg-red-600 group-hover:text-white transition shadow-sm">
            <Scan className="w-5 h-5 text-red-500 group-hover:text-white transition" />
          </div>
          <div>
            <span className="block text-xs font-extrabold text-white/90">Scan Barcode</span>
            <span className="block text-[8px] text-white/40 mt-0.5 uppercase tracking-wide">OFF Database</span>
          </div>
        </button>

        <button
          onClick={onTriggerPhoto}
          className="glass-card hover:bg-white/10 hover:border-white/20 active:scale-[0.97] p-3.5 rounded-2xl transition flex flex-col items-center justify-center gap-2 group text-center cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 group-hover:bg-red-600 group-hover:text-white transition shadow-sm">
            <Camera className="w-5 h-5 text-red-500 group-hover:text-white transition" />
          </div>
          <div>
            <span className="block text-xs font-extrabold text-white/90">AI Photo Log</span>
            <span className="block text-[8px] text-white/40 mt-0.5 uppercase tracking-wide">Gemini Vision</span>
          </div>
        </button>

        <button
          onClick={onTriggerManualAdd}
          className="glass-card hover:bg-white/10 hover:border-white/20 active:scale-[0.97] p-3.5 rounded-2xl transition flex flex-col items-center justify-center gap-2 group text-center cursor-pointer"
        >
          <div className="w-10 h-10 rounded-xl bg-red-600/10 flex items-center justify-center border border-red-500/20 group-hover:bg-red-600 group-hover:text-white transition shadow-sm">
            <Plus className="w-5 h-5 text-red-500 group-hover:text-white transition" />
          </div>
          <div>
            <span className="block text-xs font-extrabold text-white/90">Add Food</span>
            <span className="block text-[8px] text-white/40 mt-0.5 uppercase tracking-wide">Manual Text</span>
          </div>
        </button>
      </div>

      {/* Macronutrient Tracking Dashboard */}
      <div className="glass-card rounded-3xl p-5 space-y-4 shadow-xl">
        <h3 className="text-xs font-black uppercase text-red-500 tracking-wider flex items-center gap-1.5">
          <Dumbbell className="w-4 h-4 text-red-500" /> Daily Macros Target
        </h3>

        <div className="space-y-3.5">
          {/* Protein progress */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-end text-xs">
              <span className="font-bold flex items-center gap-1.5 text-white/95">
                <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                Protein
              </span>
              <span className="font-mono text-white/45">
                <strong className="text-white">{totalProtein}g</strong> / {profile.proteinGoal}g
              </span>
            </div>
            <div className="w-full bg-white/5 border border-white/5 h-2.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-red-600 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]" 
                style={{ width: `${protRatio}%` }}
              />
            </div>
          </div>

          {/* Carbohydrates progress */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-end text-xs">
              <span className="font-bold flex items-center gap-1.5 text-white/95">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                Carbohydrates
              </span>
              <span className="font-mono text-white/45">
                <strong className="text-white">{totalCarbs}g</strong> / {profile.carbsGoal}g
              </span>
            </div>
            <div className="w-full bg-white/5 border border-white/5 h-2.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-amber-500 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]" 
                style={{ width: `${carbsRatio}%` }}
              />
            </div>
          </div>

          {/* Fats progress */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-end text-xs">
              <span className="font-bold flex items-center gap-1.5 text-white/95">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                Fats
              </span>
              <span className="font-mono text-white/45">
                <strong className="text-white">{totalFat}g</strong> / {profile.fatGoal}g
              </span>
            </div>
            <div className="w-full bg-white/5 border border-white/5 h-2.5 rounded-full overflow-hidden">
              <div 
                className="h-full bg-orange-500 rounded-full transition-all duration-500 shadow-[0_0_8px_rgba(249,115,22,0.4)]" 
                style={{ width: `${fatRatio}%` }}
              />
            </div>
          </div>
        </div>

        {/* Nutritional Pie Distribution Tip */}
        <div className="pt-2.5 text-[10px] text-white/40 italic text-center border-t border-white/10 flex items-center justify-center gap-1">
          <Apple className="w-3.5 h-3.5 text-red-500" />
          Balance your plates with high-protein sources to meet your daily {profile.goal} goals.
        </div>
      </div>

    </div>
  );
}
