import { useState } from "react";
import { MealCategory, FoodEntry } from "../types";
import { Check, X, Flame, ShieldAlert, Edit2, Camera, Plus, Trash2 } from "lucide-react";

interface VisionItem {
  name: string;
  portion: string;
  calories: number;
  protein: number;
  carbohydrates: number;
  fat: number;
}

interface VisionResult {
  items: VisionItem[];
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  description: string;
}

interface VisionConfirmProps {
  imageSrc: string; // base64 source for displaying the food photo
  result: VisionResult;
  onConfirm: (entries: Omit<FoodEntry, "id" | "dateStr">[]) => void;
  onCancel: () => void;
}

export default function VisionConfirm({ imageSrc, result, onConfirm, onCancel }: VisionConfirmProps) {
  const [items, setItems] = useState<VisionItem[]>([...result.items]);
  const [category, setCategory] = useState<MealCategory>("Lunch");
  const [description, setDescription] = useState(result.description);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  // Form states for editing a single item
  const [editName, setEditName] = useState("");
  const [editPortion, setEditPortion] = useState("");
  const [editCalories, setEditCalories] = useState(0);
  const [editProtein, setEditProtein] = useState(0);
  const [editCarbs, setEditCarbs] = useState(0);
  const [editFat, setEditFat] = useState(0);

  const handleStartEdit = (index: number) => {
    const item = items[index];
    setEditName(item.name);
    setEditPortion(item.portion);
    setEditCalories(item.calories);
    setEditProtein(item.protein);
    setEditCarbs(item.carbohydrates);
    setEditFat(item.fat);
    setEditingIndex(index);
  };

  const handleSaveEdit = () => {
    if (editingIndex === null) return;
    const updated = [...items];
    updated[editingIndex] = {
      name: editName.trim() || "Food Item",
      portion: editPortion.trim() || "1 portion",
      calories: editCalories,
      protein: editProtein,
      carbohydrates: editCarbs,
      fat: editFat
    };
    setItems(updated);
    setEditingIndex(null);
  };

  const handleDeleteItem = (index: number) => {
    const updated = items.filter((_, i) => i !== index);
    setItems(updated);
  };

  const handleAddCustomItem = () => {
    const newItem: VisionItem = {
      name: "Extra Item",
      portion: "1 portion",
      calories: 100,
      protein: 5,
      carbohydrates: 15,
      fat: 2
    };
    setItems([...items, newItem]);
    handleStartEdit(items.length);
  };

  // Compute calculated totals dynamically based on current edited items
  const totalCal = items.reduce((sum, item) => sum + item.calories, 0);
  const totalProt = items.reduce((sum, item) => sum + item.protein, 0);
  const totalCarb = items.reduce((sum, item) => sum + item.carbohydrates, 0);
  const totalFt = items.reduce((sum, item) => sum + item.fat, 0);

  const handleConfirmAll = () => {
    if (items.length === 0) return;
    
    // Convert vision items to standard food entries
    const entries = items.map((item) => ({
      name: item.name,
      calories: item.calories,
      protein: item.protein,
      carbohydrates: item.carbohydrates,
      fat: item.fat,
      servingSize: item.portion,
      quantity: 1,
      category,
    }));

    onConfirm(entries);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md font-sans overflow-y-auto">
      <div className="glass-panel border border-white/10 rounded-3xl w-full max-w-md overflow-hidden flex flex-col text-white my-8 shadow-2xl max-h-[90vh] animate-fade-in">
        
        {/* Header */}
        <div className="bg-white/[0.02] border-b border-white/10 px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white/85 uppercase tracking-wider">
            <Camera className="w-4 h-4 text-red-500 animate-pulse" />
            AI Calorie Estimator
          </div>
          <button onClick={onCancel} className="text-white/40 hover:text-white bg-white/5 hover:bg-white/10 p-1.5 rounded-full transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* Main food photo preview */}
          <div className="w-full h-40 bg-black/40 border border-white/10 rounded-2xl overflow-hidden relative">
            <img 
              src={imageSrc} 
              alt="Meal captured" 
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent flex items-end p-3">
              <span className="text-[10px] bg-red-600 font-bold uppercase tracking-wide px-2 py-0.5 rounded shadow">
                Image Analyzed By AI
              </span>
            </div>
          </div>

          {/* AI Assessment description */}
          {description && (
            <div className="bg-black/30 p-3 rounded-2xl border border-white/5 text-xs text-white/70 italic leading-relaxed">
              "{description}"
            </div>
          )}

          {/* Meal Category Select */}
          <div className="space-y-1.5">
            <label className="block text-[10px] text-white/40 uppercase font-bold tracking-wider mb-1">Assign Meal Log Category</label>
            <div className="grid grid-cols-4 gap-1.5">
              {(["Breakfast", "Lunch", "Dinner", "Snacks"] as MealCategory[]).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategory(cat)}
                  className={`py-1.5 rounded-xl text-[11px] font-bold text-center transition border cursor-pointer active:scale-95 ${
                    category === cat 
                      ? "bg-red-950/40 border-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.2)]" 
                      : "bg-white/5 border-white/5 text-white/40 hover:border-white/10 hover:text-white/80"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Detected Food Items list */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-[10px] text-white/40 uppercase font-bold tracking-wider">Estimated Items Details</label>
              <button 
                onClick={handleAddCustomItem}
                className="text-[10px] font-bold text-red-500 hover:text-red-400 flex items-center gap-0.5"
              >
                <Plus className="w-3 h-3" /> Add Item
              </button>
            </div>

            <div className="space-y-2">
              {items.map((item, idx) => (
                <div key={idx} className="bg-black/30 border border-white/5 p-3.5 rounded-2xl">
                  {editingIndex === idx ? (
                    /* Inline Editing Mode */
                    <div className="space-y-3 animate-fade-in">
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-[10px] text-white/40 uppercase tracking-wider font-semibold mb-0.5">Food Name</label>
                          <input 
                            type="text" 
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="w-full glass-input rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-white/40 uppercase tracking-wider font-semibold mb-0.5">Portion Estimate</label>
                          <input 
                            type="text" 
                            value={editPortion}
                            onChange={(e) => setEditPortion(e.target.value)}
                            className="w-full glass-input rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-1.5 text-center">
                        <div>
                          <label className="block text-[9px] text-white/40 mb-0.5">Calories</label>
                          <input 
                            type="number" 
                            value={editCalories}
                            onChange={(e) => setEditCalories(parseInt(e.target.value) || 0)}
                            className="w-full bg-black/40 border border-white/10 rounded-lg py-1 text-xs text-center font-mono focus:outline-none focus:border-red-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] text-white/40 mb-0.5">Prot (g)</label>
                          <input 
                            type="number" 
                            value={editProtein}
                            onChange={(e) => setEditProtein(parseInt(e.target.value) || 0)}
                            className="w-full bg-black/40 border border-white/10 rounded-lg py-1 text-xs text-center font-mono focus:outline-none focus:border-red-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] text-white/40 mb-0.5">Carbs (g)</label>
                          <input 
                            type="number" 
                            value={editCarbs}
                            onChange={(e) => setEditCarbs(parseInt(e.target.value) || 0)}
                            className="w-full bg-black/40 border border-white/10 rounded-lg py-1 text-xs text-center font-mono focus:outline-none focus:border-red-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[9px] text-white/40 mb-0.5">Fat (g)</label>
                          <input 
                            type="number" 
                            value={editFat}
                            onChange={(e) => setEditFat(parseInt(e.target.value) || 0)}
                            className="w-full bg-black/40 border border-white/10 rounded-lg py-1 text-xs text-center font-mono focus:outline-none focus:border-red-500"
                          />
                        </div>
                      </div>

                      <div className="flex gap-2 justify-end pt-1">
                        <button 
                          onClick={() => setEditingIndex(null)}
                          className="px-3 py-1.5 bg-white/5 text-[10px] font-bold uppercase tracking-wider rounded-lg hover:bg-white/10 transition active:scale-95"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={handleSaveEdit}
                          className="px-4 py-1.5 bg-red-600 text-[10px] font-bold uppercase tracking-wider rounded-lg hover:bg-red-700 transition active:scale-95"
                        >
                          Save
                        </button>
                      </div>
                    </div>
                  ) : (
                    /* Display Mode */
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-bold text-xs truncate text-white/90">{item.name}</h4>
                          <span className="text-[10px] text-white/40 font-mono">({item.portion})</span>
                        </div>
                        <div className="flex gap-2.5 mt-1 text-[11px] text-white/50">
                          <span>P: <strong className="text-white/80 font-mono">{item.protein}g</strong></span>
                          <span>C: <strong className="text-white/80 font-mono">{item.carbohydrates}g</strong></span>
                          <span>F: <strong className="text-white/80 font-mono">{item.fat}g</strong></span>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-red-500 font-mono">{item.calories} kcal</span>
                        <div className="flex gap-1 border-l border-white/10 pl-2">
                          <button 
                            onClick={() => handleStartEdit(idx)}
                            className="text-white/40 hover:text-white p-1 transition"
                            title="Edit Item"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => handleDeleteItem(idx)}
                            className="text-white/30 hover:text-red-400 p-1 transition"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Summation panel */}
          <div className="bg-red-950/20 border border-red-500/20 p-4 rounded-2xl space-y-2">
            <div className="flex justify-between items-center text-xs">
              <span className="text-white/80 font-bold uppercase tracking-widest flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 text-red-500" /> Meal Grand Total
              </span>
              <span className="text-base font-extrabold text-red-500 font-mono">{totalCal} kcal</span>
            </div>
            <div className="grid grid-cols-3 gap-2.5 text-center text-xs pt-2.5 border-t border-white/5">
              <div>
                <span className="block text-[9px] text-white/40 uppercase">Protein</span>
                <span className="font-bold text-white/80 font-mono">{totalProt}g</span>
              </div>
              <div>
                <span className="block text-[9px] text-white/40 uppercase">Carbs</span>
                <span className="font-bold text-white/80 font-mono">{totalCarb}g</span>
              </div>
              <div>
                <span className="block text-[9px] text-white/40 uppercase">Fat</span>
                <span className="font-bold text-white/80 font-mono">{totalFt}g</span>
              </div>
            </div>
          </div>

        </div>

        {/* Buttons footer */}
        <div className="p-3 bg-white/[0.02] border-t border-white/10 flex gap-2.5">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-xs font-bold uppercase tracking-wider text-white/85 rounded-xl border border-white/10 transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <X className="w-4 h-4" /> Discard
          </button>
          <button
            onClick={handleConfirmAll}
            disabled={items.length === 0}
            className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 disabled:opacity-40 disabled:scale-100 text-xs font-bold uppercase tracking-wider text-white rounded-xl transition flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(220,38,38,0.3)] cursor-pointer active:scale-95"
          >
            <Check className="w-4 h-4" /> Log All {items.length} Items
          </button>
        </div>

      </div>
    </div>
  );
}
