import React, { useEffect, useRef, useState, FormEvent } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Camera, AlertCircle, RefreshCw, Keyboard, Send } from "lucide-react";

interface BarcodeScannerProps {
  onScanSuccess: (barcode: string) => void;
  onClose: () => void;
}

export default function BarcodeScanner({ onScanSuccess, onClose }: BarcodeScannerProps) {
  const [error, setError] = useState<string | null>(null);
  const [manualCode, setManualCode] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [permissionState, setPermissionState] = useState<"prompt" | "granted" | "denied">("prompt");
  
  const qrCodeRef = useRef<Html5Qrcode | null>(null);
  const scannerId = "reader-element-id";

  useEffect(() => {
    // Initialize html5-qrcode
    const html5Qrcode = new Html5Qrcode(scannerId);
    qrCodeRef.current = html5Qrcode;

    startCamera(html5Qrcode);

    return () => {
      if (html5Qrcode.isScanning) {
        html5Qrcode.stop().catch((err) => console.warn("Error stopping scanner on unmount:", err));
      }
    };
  }, []);

  const startCamera = async (scannerInstance: Html5Qrcode) => {
    setIsScanning(true);
    setError(null);
    try {
      // Direct scan with optimal formats for barcodes
      await scannerInstance.start(
        { facingMode: "environment" },
        {
          fps: 10,
          qrbox: (width, height) => {
            // Rectangular box for horizontal 1D barcodes
            return {
              width: Math.min(width * 0.85, 300),
              height: Math.min(height * 0.4, 150)
            };
          },
          aspectRatio: 1.0,
        },
        (decodedText) => {
          // Success callback
          if (decodedText) {
            cleanupAndNotify(decodedText);
          }
        },
        () => {
          // Failure callback (silent, triggered on every frame that doesn't contain a code)
        }
      );
      setPermissionState("granted");
    } catch (err: any) {
      console.error("Camera scanner start failed:", err);
      setIsScanning(false);
      
      if (err?.name === "NotAllowedError" || err?.message?.includes("Permission")) {
        setPermissionState("denied");
        setError("Camera permission denied. Please allow camera access in your browser or enter the barcode manually.");
      } else {
        setError(`Failed to open camera: ${err?.message || "Unknown error"}`);
      }
    }
  };

  const cleanupAndNotify = async (code: string) => {
    if (qrCodeRef.current && qrCodeRef.current.isScanning) {
      try {
        await qrCodeRef.current.stop();
      } catch (err) {
        console.warn("Failed to stop scanner:", err);
      }
    }
    onScanSuccess(code.trim());
  };

  const handleManualSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (manualCode.trim()) {
      cleanupAndNotify(manualCode.trim());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-neutral-950/80 backdrop-blur-xl text-white font-sans animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-white/10 bg-white/[0.02] backdrop-blur-md">
        <div className="flex items-center gap-2">
          <Camera className="w-5 h-5 text-red-500 animate-pulse" />
          <h2 className="font-bold tracking-tight text-sm uppercase">Barcode Scanner</h2>
        </div>
        <button 
          onClick={onClose}
          className="px-3.5 py-1.5 text-xs font-semibold bg-white/5 hover:bg-white/10 text-white/80 rounded-xl border border-white/10 transition active:scale-95 cursor-pointer"
        >
          Cancel
        </button>
      </div>

      {/* Main viewport */}
      <div className="flex-1 flex flex-col items-center justify-center relative p-4">
        {/* Scanner target element */}
        <div className="w-full max-w-sm aspect-square bg-black/40 border border-white/10 rounded-3xl overflow-hidden relative shadow-2xl">
          <div id={scannerId} className="w-full h-full" />
          
          {/* Custom overlays when camera is active */}
          {isScanning && (
            <div className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8">
              {/* Corner brackets */}
              <div className="flex justify-between">
                <div className="w-6 h-6 border-t-2 border-l-2 border-red-500 rounded-tl" />
                <div className="w-6 h-6 border-t-2 border-r-2 border-red-500 rounded-tr" />
              </div>

              {/* Red laser animation line */}
              <div className="w-full h-[2px] bg-red-600 animate-bounce shadow-[0_0_10px_#dc2626]" />

              <div className="flex justify-between">
                <div className="w-6 h-6 border-b-2 border-l-2 border-red-500 rounded-bl" />
                <div className="w-6 h-6 border-b-2 border-r-2 border-red-500 rounded-br" />
              </div>
            </div>
          )}

          {/* Fallback state / Error state overlay */}
          {!isScanning && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm text-center p-6">
              {permissionState === "denied" ? (
                <AlertCircle className="w-12 h-12 text-red-500 mb-2" />
              ) : (
                <RefreshCw className="w-10 h-10 text-white/40 animate-spin mb-3" />
              )}
              <p className="text-xs text-white/75 mb-4 px-4 font-medium leading-relaxed">
                {error || "Initializing camera stream..."}
              </p>
              {error && qrCodeRef.current && (
                <button
                  onClick={() => startCamera(qrCodeRef.current!)}
                  className="px-4 py-2 bg-red-600 hover:bg-red-700 text-xs font-bold uppercase tracking-wider rounded-xl transition active:scale-95"
                >
                  Retry Camera
                </button>
              )}
            </div>
          )}
        </div>

        <p className="text-xs text-white/40 mt-4 text-center max-w-xs leading-relaxed font-medium">
          Align the barcode of a product inside the target frame to scan automatically.
        </p>
      </div>

      {/* Manual Entry Fallback Panel */}
      <div className="p-5 border-t border-white/10 bg-white/[0.01] backdrop-blur-md pb-8">
        <div className="max-w-sm mx-auto">
          <div className="flex items-center gap-1.5 mb-2.5">
            <Keyboard className="w-4 h-4 text-white/40" />
            <span className="text-[10px] font-bold text-white/50 uppercase tracking-widest">
              Can't Scan? Enter Code Manually
            </span>
          </div>
          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <input
              type="text"
              placeholder="e.g., 737628064502"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              className="flex-1 glass-input rounded-xl px-3 py-2 text-sm focus:outline-none font-mono tracking-wider text-white"
            />
            <button
              type="submit"
              disabled={!manualCode.trim()}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-40 disabled:scale-100 text-white text-xs font-bold uppercase tracking-wide rounded-xl flex items-center gap-1 transition active:scale-95 cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              Fetch
            </button>
          </form>
          <div className="mt-3 flex flex-wrap gap-1.5 items-center">
            <span className="text-[10px] text-white/30 uppercase tracking-wider font-semibold">Test Barcodes:</span>
            <button
              type="button"
              onClick={() => setManualCode("737628064502")}
              className="text-[9px] bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white rounded-lg px-2 py-0.5 font-mono cursor-pointer transition"
            >
              737628064502 (Rice Noodles)
            </button>
            <button
              type="button"
              onClick={() => setManualCode("3017620422003")}
              className="text-[9px] bg-white/5 hover:bg-white/10 border border-white/10 text-white/60 hover:text-white rounded-lg px-2 py-0.5 font-mono cursor-pointer transition"
            >
              3017620422003 (Nutella)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
