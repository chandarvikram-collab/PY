import { useState } from "react";
import { MealCategory, FoodEntry } from "../types";
import { Check, X, ShieldAlert, Edit2, Archive, Hash, Flame } from "lucide-react";

interface BarcodeConfirmProps {
  product: {
    barcode: string;
    name: string;
    brand?: string;
    calories: number;
    protein: number;
    carbohydrates: number;
    fat: number;
    servingSize: string;
    ingredients?: string;
    image?: string;
  };
  onConfirm: (entry: Omit<FoodEntry, "id" | "dateStr">) => void;
  onCancel: () => void;
}

export default function BarcodeConfirm({ product, onConfirm, onCancel }: BarcodeConfirmProps) {
  const [quantity, setQuantity] = useState(1);
  const [category, setCategory] = useState<MealCategory>("Breakfast");
  const [isEditing, setIsEditing] = useState(false);

  // Editable fields state
  const [name, setName] = useState(product.name);
  const [brand, setBrand] = useState(product.brand || "");
  const [calories, setCalories] = useState(product.calories);
  const [protein, setProtein] = useState(product.protein);
  const [carbs, setCarbs] = useState(product.carbohydrates);
  const [fat, setFat] = useState(product.fat);
  const [servingSize, setServingSize] = useState(product.servingSize);

  const handleSave = () => {
    onConfirm({
      name: name.trim() || "Scanned Food Item",
      brand: brand.trim() || undefined,
      calories: Math.round(calories * quantity),
      protein: Math.round(protein * quantity),
      carbohydrates: Math.round(carbs * quantity),
      fat: Math.round(fat * quantity),
      servingSize: servingSize || "1 serving",
      quantity,
      category,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md font-sans">
      <div className="glass-panel border border-white/10 rounded-3xl w-full max-w-sm overflow-hidden flex flex-col text-white shadow-2xl animate-fade-in">
        
        {/* Header */}
        <div className="bg-white/[0.02] border-b border-white/10 px-4 py-3.5 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-bold text-white/85 uppercase tracking-wider">
            <Archive className="w-4 h-4 text-red-500" />
            Barcode Food Detected
          </div>
          <button onClick={onCancel} className="text-white/40 hover:text-white bg-white/5 hover:bg-white/10 p-1.5 rounded-full transition">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          
          {/* Product basic info */}
          <div className="flex gap-3 items-start bg-black/30 p-3 rounded-2xl border border-white/5">
            {product.image ? (
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-16 h-16 object-cover rounded-xl bg-white/5 border border-white/10"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-16 h-16 bg-white/5 rounded-xl border border-white/10 flex items-center justify-center text-red-500 font-bold text-xs font-mono">
                UPC
              </div>
            )}
            <div className="flex-1 min-w-0">
              {isEditing ? (
                <div className="space-y-1.5">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full glass-input rounded-lg px-2 py-1 text-xs text-white"
                    placeholder="Product name"
                  />
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full glass-input rounded-lg px-2 py-1 text-[11px] text-white/70"
                    placeholder="Brand name"
                  />
                </div>
              ) : (
                <>
                  <h3 className="font-bold text-sm text-white leading-tight truncate">{name}</h3>
                  <p className="text-xs text-white/40 leading-tight mt-0.5">{brand || "Unknown Brand"}</p>
                  <p className="text-[10px] text-white/30 mt-1 font-mono uppercase">Barcode: {product.barcode}</p>
                </>
              )}
            </div>
            <button 
              onClick={() => setIsEditing(!isEditing)} 
              className={`p-1.5 rounded-xl transition cursor-pointer active:scale-95 ${isEditing ? 'bg-red-950/40 text-red-400 border border-red-900/60' : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white/80'}`}
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Portion/Quantity config */}
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1">
                  <Hash className="w-3 h-3 text-red-500" /> Quantity (Servings)
                </label>
                <div className="flex items-center gap-1">
                  <button 
                    onClick={() => setQuantity(q => Math.max(0.25, q - 0.25))}
                    className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 font-bold text-sm cursor-pointer active:scale-90"
                  >
                    -
                  </button>
                  <span className="flex-1 text-center font-mono text-sm font-bold bg-black/40 py-1 rounded-xl border border-white/10">
                    {quantity}x
                  </span>
                  <button 
                    onClick={() => setQuantity(q => q + 0.25)}
                    className="w-8 h-8 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 font-bold text-sm cursor-pointer active:scale-90"
                  >
                    +
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Serving Size</label>
                {isEditing ? (
                  <input
                    type="text"
                    value={servingSize}
                    onChange={(e) => setServingSize(e.target.value)}
                    className="w-full glass-input rounded-xl px-2 py-1.5 text-xs text-center text-white"
                  />
                ) : (
                  <div className="w-full bg-black/40 border border-white/10 py-1.5 rounded-xl text-xs text-white/80 text-center font-medium truncate h-8 flex items-center justify-center">
                    {servingSize}
                  </div>
                )}
              </div>
            </div>

            {/* Meal Category Select */}
            <div>
              <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Meal Log Target</label>
              <div className="grid grid-cols-4 gap-1.5">
                {(["Breakfast", "Lunch", "Dinner", "Snacks"] as MealCategory[]).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setCategory(cat)}
                    className={`py-1.5 rounded-xl text-[11px] font-bold text-center transition border cursor-pointer active:scale-95 ${
                      category === cat 
                        ? "bg-red-950/40 border-red-500 text-white shadow-[0_0_10px_rgba(239,68,68,0.2)]" 
                        : "bg-white/5 border-white/5 text-white/40 hover:border-white/10 hover:text-white/80"
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Nutritional specs breakdown */}
          <div className="bg-black/30 border border-white/5 p-3.5 rounded-2xl space-y-3">
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <div className="flex items-center gap-1 text-xs text-white/50 font-bold uppercase tracking-wider">
                <Flame className="w-3.5 h-3.5 text-red-500" />
                Est. Calories
              </div>
              {isEditing ? (
                <input
                  type="number"
                  value={calories}
                  onChange={(e) => setCalories(parseInt(e.target.value) || 0)}
                  className="w-20 bg-black/60 border border-white/10 rounded-lg px-2 py-0.5 text-xs text-right text-red-500 font-mono focus:outline-none focus:border-red-500"
                />
              ) : (
                <span className="text-base font-extrabold text-red-500 font-mono">
                  {Math.round(calories * quantity)} kcal
                </span>
              )}
            </div>

            <div className="grid grid-cols-3 gap-2.5 pt-1 text-center">
              <div className="bg-black/40 p-2 rounded-xl border border-white/5">
                <span className="block text-[10px] text-white/40 uppercase font-semibold">Protein</span>
                {isEditing ? (
                  <input
                    type="number"
                    value={protein}
                    onChange={(e) => setProtein(parseInt(e.target.value) || 0)}
                    className="w-full mt-1 bg-black/60 border border-white/15 rounded-lg py-0.5 text-[11px] text-center font-mono text-white focus:outline-none"
                  />
                ) : (
                  <span className="text-xs font-bold text-white/90 font-mono mt-0.5 block">
                    {Math.round(protein * quantity)}g
                  </span>
                )}
              </div>

              <div className="bg-black/40 p-2 rounded-xl border border-white/5">
                <span className="block text-[10px] text-white/40 uppercase font-semibold">Carbs</span>
                {isEditing ? (
                  <input
                    type="number"
                    value={carbs}
                    onChange={(e) => setCarbs(parseInt(e.target.value) || 0)}
                    className="w-full mt-1 bg-black/60 border border-white/15 rounded-lg py-0.5 text-[11px] text-center font-mono text-white focus:outline-none"
                  />
                ) : (
                  <span className="text-xs font-bold text-white/90 font-mono mt-0.5 block">
                    {Math.round(carbs * quantity)}g
                  </span>
                )}
              </div>

              <div className="bg-black/40 p-2 rounded-xl border border-white/5">
                <span className="block text-[10px] text-white/40 uppercase font-semibold">Fat</span>
                {isEditing ? (
                  <input
                    type="number"
                    value={fat}
                    onChange={(e) => setFat(parseInt(e.target.value) || 0)}
                    className="w-full mt-1 bg-black/60 border border-white/15 rounded-lg py-0.5 text-[11px] text-center font-mono text-white focus:outline-none"
                  />
                ) : (
                  <span className="text-xs font-bold text-white/90 font-mono mt-0.5 block">
                    {Math.round(fat * quantity)}g
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Ingredients if available */}
          {product.ingredients && (
            <div className="space-y-1">
              <span className="block text-[10px] text-white/40 uppercase font-bold tracking-wider">Ingredients Summary</span>
              <p className="text-[10px] text-white/50 max-h-16 overflow-y-auto leading-relaxed bg-black/20 p-2.5 rounded-xl border border-white/5">
                {product.ingredients}
              </p>
            </div>
          )}
        </div>

        {/* Buttons */}
        <div className="p-3 bg-white/[0.02] border-t border-white/10 flex gap-2.5">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-xs font-bold uppercase tracking-wider text-white/80 rounded-xl border border-white/10 transition flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <X className="w-4 h-4" /> Discard
          </button>
          <button
            onClick={handleSave}
            className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-xs font-bold uppercase tracking-wider text-white rounded-xl transition flex items-center justify-center gap-1.5 shadow-[0_0_12px_rgba(220,38,38,0.3)] cursor-pointer active:scale-95"
          >
            <Check className="w-4 h-4" /> Log Item
          </button>
        </div>

      </div>
    </div>
  );
}
