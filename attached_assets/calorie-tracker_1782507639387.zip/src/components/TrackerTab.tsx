import React, { useState, FormEvent } from "react";
import { FoodEntry, MealCategory } from "../types";
import { Plus, Trash2, Edit2, Check, X, ShieldAlert, BookOpen, Coffee, Sun, Sunset, Moon, Sparkles, PlusCircle } from "lucide-react";

interface TrackerTabProps {
  foodEntries: FoodEntry[];
  selectedDateStr: string;
  onUpdateQuantity: (id: string, quantity: number) => void;
  onDeleteEntry: (id: string) => void;
  onAddManualEntry: (entry: Omit<FoodEntry, "id" | "dateStr">) => void;
}

export default function TrackerTab({
  foodEntries,
  selectedDateStr,
  onUpdateQuantity,
  onDeleteEntry,
  onAddManualEntry
}: TrackerTabProps) {
  
  const [showManualForm, setShowManualForm] = useState(false);
  const [formCategory, setFormCategory] = useState<MealCategory>("Breakfast");

  // Form Fields State
  const [itemName, setItemName] = useState("");
  const [itemBrand, setItemBrand] = useState("");
  const [itemCalories, setItemCalories] = useState("");
  const [itemProtein, setItemProtein] = useState("");
  const [itemCarbs, setItemCarbs] = useState("");
  const [itemFat, setItemFat] = useState("");
  const [itemServingSize, setItemServingSize] = useState("1 serving");
  const [itemQuantity, setItemQuantity] = useState(1);

  // Filter entries for the selected date
  const dayEntries = foodEntries.filter(entry => entry.dateStr === selectedDateStr);

  const categories: { name: MealCategory; icon: any; colorClass: string; desc: string }[] = [
    { name: "Breakfast", icon: Coffee, colorClass: "text-red-500", desc: "Mornings, Shakes, Oatmeal" },
    { name: "Lunch", icon: Sun, colorClass: "text-amber-500", desc: "Midday Power Bowls, Proteins" },
    { name: "Dinner", icon: Sunset, colorClass: "text-orange-500", desc: "Suppers, Lean Meats, Veggies" },
    { name: "Snacks", icon: Moon, colorClass: "text-neutral-400", desc: "Energy bars, nuts, pre-workout" }
  ];

  const handleOpenManualForm = (cat: MealCategory) => {
    setFormCategory(cat);
    setShowManualForm(true);
    // Reset fields
    setItemName("");
    setItemBrand("");
    setItemCalories("");
    setItemProtein("");
    setItemCarbs("");
    setItemFat("");
    setItemServingSize("1 serving");
    setItemQuantity(1);
  };

  const handleManualSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!itemName.trim() || !itemCalories) return;

    onAddManualEntry({
      name: itemName.trim(),
      brand: itemBrand.trim() || undefined,
      calories: parseInt(itemCalories) || 0,
      protein: parseInt(itemProtein) || 0,
      carbohydrates: parseInt(itemCarbs) || 0,
      fat: parseInt(itemFat) || 0,
      servingSize: itemServingSize || "1 serving",
      quantity: itemQuantity,
      category: formCategory,
    });

    setShowManualForm(false);
  };

  // Sum calculations per category
  const getCategoryTotal = (catName: MealCategory) => {
    const catEntries = dayEntries.filter(entry => entry.category === catName);
    const calories = catEntries.reduce((sum, entry) => sum + (entry.calories || 0), 0);
    const protein = catEntries.reduce((sum, entry) => sum + (entry.protein || 0), 0);
    const carbs = catEntries.reduce((sum, entry) => sum + (entry.carbohydrates || 0), 0);
    const fat = catEntries.reduce((sum, entry) => sum + (entry.fat || 0), 0);
    return { calories, protein, carbs, fat, count: catEntries.length };
  };

  return (
    <div className="p-4 max-w-md mx-auto space-y-6 text-white pb-24 font-sans">
      
      {/* Page Title */}
      <div className="flex items-center justify-between border-b border-white/10 pb-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-red-600/10 flex items-center justify-center border border-red-500/20">
            <BookOpen className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <h1 className="text-xl font-bold uppercase tracking-tight">Nutrition Tracker</h1>
            <p className="text-xs text-white/40">Meal entries for today's logs</p>
          </div>
        </div>
      </div>

      {/* Meals Accordion/List */}
      <div className="space-y-4">
        {categories.map((cat) => {
          const stats = getCategoryTotal(cat.name);
          const catEntries = dayEntries.filter(entry => entry.category === cat.name);
          const IconComponent = cat.icon;

          return (
            <div key={cat.name} className="glass-card rounded-2xl overflow-hidden shadow-md">
              {/* Category Header */}
              <div className="px-4 py-3.5 bg-white/[0.03] border-b border-white/5 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <IconComponent className={`w-5 h-5 ${cat.colorClass}`} />
                  <div>
                    <h3 className="font-extrabold text-sm text-white/90">{cat.name}</h3>
                    <span className="block text-[10px] text-white/40">{cat.desc}</span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="block text-xs font-bold text-red-500 font-mono">{stats.calories} kcal</span>
                    {stats.count > 0 && (
                      <span className="block text-[9px] text-white/50">
                        P:{stats.protein}g C:{stats.carbs}g F:{stats.fat}g
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => handleOpenManualForm(cat.name)}
                    className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-white/80 transition active:scale-90 border border-white/10"
                    title={`Add items to ${cat.name}`}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Category Entries */}
              <div className="p-3 divide-y divide-white/5">
                {catEntries.length === 0 ? (
                  <div className="py-5 text-center text-xs text-white/30 flex flex-col items-center justify-center gap-1 bg-white/[0.01]">
                    <span>No foods logged for {cat.name} yet.</span>
                    <button
                      onClick={() => handleOpenManualForm(cat.name)}
                      className="text-[10px] text-red-500 font-extrabold hover:underline uppercase mt-1 tracking-wide"
                    >
                      + Quick Manual Log
                    </button>
                  </div>
                ) : (
                  catEntries.map((entry) => (
                    <div key={entry.id} className="py-2.5 flex items-center justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-1.5">
                          <h4 className="text-xs font-bold text-white/90 truncate">{entry.name}</h4>
                          {entry.brand && (
                            <span className="text-[10px] text-white/40 truncate max-w-[100px]">({entry.brand})</span>
                          )}
                        </div>
                        <div className="flex items-center gap-2.5 mt-1 text-[10px] text-white/50">
                          <span>{entry.servingSize}</span>
                          <span className="w-1 h-1 rounded-full bg-white/15" />
                          <span>P:{entry.protein}g C:{entry.carbohydrates}g F:{entry.fat}g</span>
                        </div>
                      </div>

                      {/* Quantity Editor / Delete */}
                      <div className="flex items-center gap-2.5">
                        <div className="flex items-center gap-1.5 bg-black/40 border border-white/10 rounded-xl px-2 py-0.5">
                          <button
                            onClick={() => onUpdateQuantity(entry.id, Math.max(0.25, entry.quantity - 0.25))}
                            className="text-xs font-bold text-white/40 hover:text-white px-1 active:scale-90"
                          >
                            -
                          </button>
                          <span className="text-[11px] font-mono font-bold text-white/90">
                            {entry.quantity}x
                          </span>
                          <button
                            onClick={() => onUpdateQuantity(entry.id, entry.quantity + 0.25)}
                            className="text-xs font-bold text-white/40 hover:text-white px-1 active:scale-90"
                          >
                            +
                          </button>
                        </div>

                        <div className="text-right min-w-[55px]">
                          <span className="block text-xs font-bold font-mono text-red-500">
                            {Math.round(entry.calories * entry.quantity)} kcal
                          </span>
                        </div>

                        <button
                          onClick={() => onDeleteEntry(entry.id)}
                          className="text-white/40 hover:text-red-500 p-1.5 transition active:scale-95"
                          title="Delete food log"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Manual Input Modal Dialog overlay */}
      {showManualForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md">
          <div className="glass-panel border border-white/10 rounded-3xl w-full max-w-sm overflow-hidden text-white shadow-2xl">
            {/* Header */}
            <div className="bg-white/[0.02] border-b border-white/10 px-4 py-3.5 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-white/80 flex items-center gap-1.5">
                <PlusCircle className="w-4 h-4 text-red-500 animate-pulse" />
                Add Food to {formCategory}
              </span>
              <button onClick={() => setShowManualForm(false)} className="text-white/40 hover:text-white bg-white/5 hover:bg-white/10 p-1.5 rounded-full transition">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleManualSubmit} className="p-4 space-y-4">
              <div>
                <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Food Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Grilled Chicken Breast"
                  value={itemName}
                  onChange={(e) => setItemName(e.target.value)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-red-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Brand Name</label>
                  <input
                    type="text"
                    placeholder="e.g., Tyson (optional)"
                    value={itemBrand}
                    onChange={(e) => setItemBrand(e.target.value)}
                    className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Serving Unit</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., 100g, 1 piece"
                    value={itemServingSize}
                    onChange={(e) => setItemServingSize(e.target.value)}
                    className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none"
                  />
                </div>
              </div>

              <div className="bg-black/30 p-3.5 rounded-2xl border border-white/5 space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-[11px] font-bold uppercase text-red-500 tracking-wider">Estimated Calories *</label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="250"
                    value={itemCalories}
                    onChange={(e) => setItemCalories(e.target.value)}
                    className="w-24 bg-black/60 border border-white/10 rounded-xl px-2 py-1 text-xs text-right font-mono text-red-500 font-bold focus:border-red-500 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Protein (g)</label>
                    <input
                      type="number"
                      placeholder="25"
                      value={itemProtein}
                      onChange={(e) => setItemProtein(e.target.value)}
                      className="w-full bg-black/40 border border-white/5 rounded-xl py-1 text-center font-mono text-xs focus:border-red-500/50 focus:outline-none text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Carbs (g)</label>
                    <input
                      type="number"
                      placeholder="10"
                      value={itemCarbs}
                      onChange={(e) => setItemCarbs(e.target.value)}
                      className="w-full bg-black/40 border border-white/5 rounded-xl py-1 text-center font-mono text-xs focus:border-red-500/50 focus:outline-none text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-white/40 mb-1">Fat (g)</label>
                    <input
                      type="number"
                      placeholder="5"
                      value={itemFat}
                      onChange={(e) => setItemFat(e.target.value)}
                      className="w-full bg-black/40 border border-white/5 rounded-xl py-1 text-center font-mono text-xs focus:border-red-500/50 focus:outline-none text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="p-1 flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowManualForm(false)}
                  className="flex-1 py-2.5 bg-white/5 hover:bg-white/10 text-white/80 rounded-xl text-xs font-bold uppercase tracking-wider border border-white/10 transition active:scale-95"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition shadow-[0_0_12px_rgba(220,38,38,0.3)] active:scale-95"
                >
                  ✓ Save Log
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
