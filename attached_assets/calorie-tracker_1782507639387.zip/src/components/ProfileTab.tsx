import React, { useState, FormEvent } from "react";
import { UserProfile } from "../types";
import { User, Weight, Ruler, Activity, Award, Flame, Dumbbell } from "lucide-react";

interface ProfileTabProps {
  profile: UserProfile;
  onSaveProfile: (profile: UserProfile) => void;
}

export default function ProfileTab({ profile, onSaveProfile }: ProfileTabProps) {
  const [formData, setFormData] = useState<UserProfile>({ ...profile });
  const [showSavedToast, setShowSavedToast] = useState(false);

  // Recalculate estimates based on Mifflin-St Jeor Equation (Male average default, solid general proxy)
  const handleAutoCalculate = () => {
    const { weight, height, age, goal } = formData;
    if (!weight || !height || !age) return;

    // Basal Metabolic Rate
    const bmr = 10 * weight + 6.25 * height - 5 * age + 5;
    // TDEE with Light Activity multiplier
    const tdee = Math.round(bmr * 1.375);

    let calorieGoal = tdee;
    let pRatio = 0.30; // protein % calories
    let cRatio = 0.45; // carbs % calories
    let fRatio = 0.25; // fat % calories

    if (goal === "lose") {
      calorieGoal = tdee - 450; // Moderate deficit
      pRatio = 0.35; // Higher protein to preserve lean mass
      cRatio = 0.35;
      fRatio = 0.30;
    } else if (goal === "gain") {
      calorieGoal = tdee + 350; // Moderate surplus
      pRatio = 0.30;
      cRatio = 0.50; // Extra carbs to fuel workouts
      fRatio = 0.20;
    }

    // Convert calorie ratios to grams
    // Protein: 4 kcal/g
    // Carbs: 4 kcal/g
    // Fat: 9 kcal/g
    const proteinGoal = Math.round((calorieGoal * pRatio) / 4);
    const carbsGoal = Math.round((calorieGoal * cRatio) / 4);
    const fatGoal = Math.round((calorieGoal * fRatio) / 9);

    const updated = {
      ...formData,
      dailyCalorieGoal: calorieGoal,
      proteinGoal,
      carbsGoal,
      fatGoal,
    };

    setFormData(updated);
    onSaveProfile(updated);
    triggerSavedToast();
  };

  const triggerSavedToast = () => {
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 2500);
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSaveProfile(formData);
    triggerSavedToast();
  };

  const handleInputChange = (key: keyof UserProfile, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  return (
    <div className="p-4 max-w-md mx-auto space-y-6 text-white pb-24 font-sans">
      {/* Page Title */}
      <div className="flex items-center gap-3 border-b border-white/10 pb-3">
        <div className="w-10 h-10 rounded-2xl bg-red-600/10 flex items-center justify-center border border-red-500/20">
          <User className="w-5 h-5 text-red-500" />
        </div>
        <div>
          <h1 className="text-xl font-bold uppercase tracking-tight">Fitness Profile</h1>
          <p className="text-xs text-white/40">Configure your daily calorie & macro goals</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Personal Details */}
        <div className="glass-card p-5 rounded-3xl space-y-4 shadow-xl">
          <h3 className="text-xs font-bold uppercase text-red-500 tracking-wider flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-red-500 animate-pulse" /> Personal Details
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-xs text-white/40 uppercase tracking-wider mb-1 font-semibold">Display Name</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs text-white/40 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1">
                  Age <Award className="w-3 h-3 text-white/30" />
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="120"
                  value={formData.age || ""}
                  onChange={(e) => handleInputChange("age", parseInt(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs text-white/40 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1">
                  Weight (kg) <Weight className="w-3 h-3 text-white/30" />
                </label>
                <input
                  type="number"
                  required
                  min="10"
                  max="300"
                  value={formData.weight || ""}
                  onChange={(e) => handleInputChange("weight", parseFloat(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-xs text-white/40 uppercase tracking-wider mb-1 font-semibold flex items-center gap-1">
                  Height (cm) <Ruler className="w-3 h-3 text-white/30" />
                </label>
                <input
                  type="number"
                  required
                  min="50"
                  max="250"
                  value={formData.height || ""}
                  onChange={(e) => handleInputChange("height", parseInt(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-3 py-2 text-xs focus:outline-none font-mono"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Nutritional Goal Selection */}
        <div className="glass-card p-5 rounded-3xl space-y-4 shadow-xl">
          <h3 className="text-xs font-bold uppercase text-red-500 tracking-wider flex items-center gap-1.5">
            <Dumbbell className="w-3.5 h-3.5 text-red-500" /> Primary Goal
          </h3>

          <div className="grid grid-cols-3 gap-2">
            {[
              { id: "lose", label: "Lose Weight", desc: "Deficit" },
              { id: "maintain", label: "Maintain", desc: "TDEE balance" },
              { id: "gain", label: "Build Muscle", desc: "Surplus" },
            ].map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => handleInputChange("goal", g.id as any)}
                className={`p-2.5 rounded-2xl border text-center transition flex flex-col items-center justify-center cursor-pointer active:scale-95 ${
                  formData.goal === g.id
                    ? "bg-red-950/40 border-red-500 text-white shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                    : "bg-white/5 border-white/5 text-white/40 hover:border-white/10 hover:text-white/80"
                }`}
              >
                <span className="text-xs font-bold leading-tight">{g.label}</span>
                <span className="text-[9px] opacity-60 mt-0.5 font-medium">{g.desc}</span>
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={handleAutoCalculate}
            className="w-full mt-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
          >
            <Flame className="w-3.5 h-3.5 text-red-500 fill-red-500/10 animate-pulse" />
            Recalculate Calorie & Macro Goals
          </button>
        </div>

        {/* Target Setup */}
        <div className="glass-card p-5 rounded-3xl space-y-4 shadow-xl">
          <h3 className="text-xs font-bold uppercase text-red-500 tracking-wider flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-red-500" /> Target Thresholds
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs text-white/50 uppercase tracking-wider font-semibold">Daily Calories Goal</label>
                <span className="text-sm font-bold text-red-500 font-mono">{formData.dailyCalorieGoal} kcal</span>
              </div>
              <input
                type="range"
                min="1000"
                max="5000"
                step="50"
                value={formData.dailyCalorieGoal}
                onChange={(e) => handleInputChange("dailyCalorieGoal", parseInt(e.target.value))}
                className="w-full accent-red-600 cursor-pointer h-1.5 bg-white/10 rounded-lg appearance-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-3 pt-2">
              <div>
                <label className="block text-[10px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Protein (g)</label>
                <input
                  type="number"
                  required
                  min="10"
                  max="400"
                  value={formData.proteinGoal || ""}
                  onChange={(e) => handleInputChange("proteinGoal", parseInt(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-2.5 py-1.5 text-xs focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Carbs (g)</label>
                <input
                  type="number"
                  required
                  min="10"
                  max="600"
                  value={formData.carbsGoal || ""}
                  onChange={(e) => handleInputChange("carbsGoal", parseInt(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-2.5 py-1.5 text-xs focus:outline-none font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] text-white/40 uppercase tracking-wider mb-1 font-semibold">Fat (g)</label>
                <input
                  type="number"
                  required
                  min="5"
                  max="200"
                  value={formData.fatGoal || ""}
                  onChange={(e) => handleInputChange("fatGoal", parseInt(e.target.value) || 0)}
                  className="w-full glass-input rounded-xl px-2.5 py-1.5 text-xs focus:outline-none font-mono"
                />
              </div>
            </div>
            <p className="text-[10px] text-white/30 italic mt-1 text-center">
              Target Macros: {(formData.proteinGoal * 4 + formData.carbsGoal * 4 + formData.fatGoal * 9).toLocaleString()} kcal total
            </p>
          </div>
        </div>

        {/* Submit */}
        <button
          type="submit"
          className="w-full bg-red-600 hover:bg-red-700 active:scale-[0.98] text-white py-3 rounded-2xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-red-950/30 transition-all flex items-center justify-center gap-1 cursor-pointer"
        >
          Save Changes
        </button>
      </form>

      {/* Floating Save Toast Notification */}
      {showSavedToast && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 glass-panel text-white text-xs font-bold px-4 py-2.5 rounded-full shadow-lg border border-red-500 animate-bounce flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-ping" />
          Profile saved successfully!
        </div>
      )}
    </div>
  );
}
