import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Increase JSON request limit for base64 images
app.use(express.json({ limit: "10mb" }));

// Initialize Google Gen AI
const geminiApiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (geminiApiKey && geminiApiKey !== "MY_GEMINI_API_KEY") {
  ai = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY is not configured or has placeholder value.");
}

// 1. API: Barcode Lookup from Open Food Facts
app.get("/api/barcode/:code", async (req, res) => {
  const { code } = req.params;
  try {
    const url = `https://world.openfoodfacts.org/api/v2/product/${code}.json`;
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'CalorieTrackerApp - Web - Version 1.0 - https://ai.studio/build'
      }
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: `Open Food Facts returned status ${response.status}` });
    }

    const data = await response.json();
    if (data.status === 0 || !data.product) {
      return res.status(404).json({ error: "Product not found on Open Food Facts database." });
    }

    const prod = data.product;
    const nutriments = prod.nutriments || {};

    // Helper to get number safely
    const getNutrient = (key: string): number => {
      const val = nutriments[key];
      if (typeof val === 'number') return Math.round(val);
      if (typeof val === 'string') {
        const parsed = parseFloat(val);
        return isNaN(parsed) ? 0 : Math.round(parsed);
      }
      return 0;
    };

    // Extract serving details
    const servingSize = prod.serving_size || "100g";
    
    // We want the nutrient values. Usually nutriments has values per 100g and per serving.
    // Let's grab values per serving if available, otherwise per 100g.
    const hasServingData = nutriments['energy-kcal_serving'] !== undefined;
    const prefix = hasServingData ? '_serving' : '_100g';

    const calories = getNutrient(`energy-kcal${prefix}`) || getNutrient('energy-kcal_100g') || getNutrient('energy-kcal');
    const protein = getNutrient(`proteins${prefix}`) || getNutrient('proteins_100g') || getNutrient('proteins');
    const carbs = getNutrient(`carbohydrates${prefix}`) || getNutrient('carbohydrates_100g') || getNutrient('carbohydrates');
    const fat = getNutrient(`fat${prefix}`) || getNutrient('fat_100g') || getNutrient('fat');

    const result = {
      barcode: code,
      name: prod.product_name || "Unknown Product",
      brand: prod.brands || "Unknown Brand",
      calories: calories || 0,
      protein: protein || 0,
      carbohydrates: carbs || 0,
      fat: fat || 0,
      servingSize: servingSize,
      ingredients: prod.ingredients_text || undefined,
      image: prod.image_front_url || undefined
    };

    return res.json(result);
  } catch (error: any) {
    console.error("Barcode API lookup error:", error);
    return res.status(500).json({ error: error.message || "Failed to search barcode database." });
  }
});

// 2. API: Food Image Calorie Estimation
app.post("/api/analyze-image", async (req, res) => {
  const { image, mimeType } = req.body;

  if (!image || !mimeType) {
    return res.status(400).json({ error: "Missing image data or mimeType." });
  }

  // Check if OpenAI key is provided in headers or env, or if we use Gemini
  const customOpenAiKey = process.env.OPENAI_API_KEY;

  if (customOpenAiKey && customOpenAiKey !== "MY_OPENAI_API_KEY") {
    // Call OpenAI Vision API
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${customOpenAiKey}`
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          response_format: { type: "json_object" },
          messages: [
            {
              role: "system",
              content: `You are an expert nutritionist AI. Analyze the food image and estimate the calories and macronutrients (protein, carbs, fat in grams) for each item detected. Respond with a JSON object strictly conforming to this format:
              {
                "items": [
                  {
                    "name": "Food item name",
                    "portion": "Estimated portion (e.g. 150g, 1 cup)",
                    "calories": 250,
                    "protein": 20,
                    "carbohydrates": 10,
                    "fat": 15
                  }
                ],
                "totalCalories": 250,
                "totalProtein": 20,
                "totalCarbs": 10,
                "totalFat": 15,
                "description": "Short explanation of findings"
              }`
            },
            {
              role: "user",
              content: [
                { type: "text", text: "Estimate calories and macros for the food items in this picture." },
                {
                  type: "image_url",
                  image_url: {
                    url: `data:${mimeType};base64,${image}`
                  }
                }
              ]
            }
          ]
        })
      });

      if (!response.ok) {
        const errBody = await response.text();
        throw new Error(`OpenAI API returned ${response.status}: ${errBody}`);
      }

      const openAiData = await response.json();
      const rawText = openAiData.choices?.[0]?.message?.content || "{}";
      const parsed = JSON.parse(rawText);
      return res.json(parsed);
    } catch (openaiErr: any) {
      console.error("OpenAI Image analysis failed:", openaiErr);
      return res.status(500).json({ error: `OpenAI Vision analysis error: ${openaiErr.message}` });
    }
  }

  // Fallback to Server-Side Gemini API (the default, seamless approach)
  if (!ai) {
    return res.status(500).json({
      error: "AI estimation is not configured. Please add GEMINI_API_KEY or OPENAI_API_KEY to the secrets panel."
    });
  }

  try {
    const imagePart = {
      inlineData: {
        mimeType: mimeType,
        data: image
      }
    };

    const promptText = "Identify all food items in this image, estimate their portion sizes, and calculate estimated calories, protein (g), carbs (g), and fat (g). Sum them up correctly in totalCalories, totalProtein, totalCarbs, and totalFat.";

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: [imagePart, promptText],
      config: {
        systemInstruction: "You are a professional nutrition expert. Analyze the provided image of a meal, identify components, estimate weights or portions, and provide highly accurate nutritional values. If no food is detected, return an empty items list and set the description accordingly.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            items: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING, description: "Name of the food item" },
                  portion: { type: Type.STRING, description: "Estimated portion size (e.g., 150g, 1 cup)" },
                  calories: { type: Type.NUMBER, description: "Estimated calories (kcal)" },
                  protein: { type: Type.NUMBER, description: "Protein in grams" },
                  carbohydrates: { type: Type.NUMBER, description: "Carbohydrates in grams" },
                  fat: { type: Type.NUMBER, description: "Fat in grams" }
                },
                required: ["name", "portion", "calories", "protein", "carbohydrates", "fat"]
              }
            },
            totalCalories: { type: Type.NUMBER, description: "Sum of calories of all items" },
            totalProtein: { type: Type.NUMBER, description: "Total protein in grams" },
            totalCarbs: { type: Type.NUMBER, description: "Total carbohydrates in grams" },
            totalFat: { type: Type.NUMBER, description: "Total fat in grams" },
            description: { type: Type.STRING, description: "Brief visual analysis and portion details" }
          },
          required: ["items", "totalCalories", "totalProtein", "totalCarbs", "totalFat", "description"]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("Empty response received from Gemini.");
    }

    const parsedResult = JSON.parse(textOutput.trim());
    return res.json(parsedResult);
  } catch (geminiErr: any) {
    console.error("Gemini image analysis error:", geminiErr);
    return res.status(500).json({ error: `Gemini Vision analysis failed: ${geminiErr.message}` });
  }
});

// Serve frontend assets
async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    // Serve index.html for all SPA routes
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Calorie Tracker server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
