/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AVATARS } from '../data';
import { FitnessLevel } from '../types';

interface AvatarProps {
  avatarId: string;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  showStatus?: boolean;
  isOnline?: boolean;
  className?: string;
}

export const AvatarHelper: React.FC<AvatarProps> = ({
  avatarId,
  size = 'md',
  showStatus = false,
  isOnline = true,
  className = ''
}) => {
  const avatar = AVATARS.find(av => av.id === avatarId) || AVATARS[AVATARS.length - 1];

  let sizeClasses = '';
  let emojiSize = 'text-xl';
  let badgeSize = 'w-3 h-3';

  switch (size) {
    case 'sm':
      sizeClasses = 'w-10 h-10';
      emojiSize = 'text-lg';
      badgeSize = 'w-2.5 h-2.5';
      break;
    case 'md':
      sizeClasses = 'w-14 h-14';
      emojiSize = 'text-2xl';
      badgeSize = 'w-3.5 h-3.5 border-2';
      break;
    case 'lg':
      sizeClasses = 'w-20 h-20';
      emojiSize = 'text-4xl';
      badgeSize = 'w-4 h-4 border-2';
      break;
    case 'xl':
      sizeClasses = 'w-28 h-28';
      emojiSize = 'text-5xl';
      badgeSize = 'w-5 h-5 border-2';
      break;
    case '2xl':
      sizeClasses = 'w-36 h-36';
      emojiSize = 'text-6xl';
      badgeSize = 'w-6 h-6 border-2';
      break;
  }

  return (
    <div className={`relative inline-flex items-center justify-center rounded-full select-none shadow-md ${className}`} id={`avatar-${avatarId}`}>
      <div
        className={`flex items-center justify-center rounded-full ${sizeClasses}`}
        style={{ background: avatar.bg }}
      >
        <span className={emojiSize}>{avatar.emoji}</span>
      </div>

      {showStatus && (
        <span
          className={`absolute bottom-0 right-0 rounded-full border-zinc-900 ${badgeSize} ${
            isOnline ? 'bg-emerald-500' : 'bg-zinc-500'
          }`}
        />
      )}
    </div>
  );
};

export const SkillBadge: React.FC<{ level: FitnessLevel }> = ({ level }) => {
  let bg = '';
  let text = '';
  switch (level) {
    case 'Beginner':
      bg = 'bg-blue-500/10 border-blue-500/30';
      text = 'text-blue-400';
      break;
    case 'Intermediate':
      bg = 'bg-amber-500/10 border-amber-500/30';
      text = 'text-amber-400';
      break;
    case 'Advanced':
      bg = 'bg-rose-500/10 border-rose-500/30';
      text = 'text-rose-400';
      break;
  }

  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border ${bg} ${text}`}>
      ● {level}
    </span>
  );
};
