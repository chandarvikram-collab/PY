/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { User, WorkoutInvite, Friend } from '../types';
import { AvatarHelper } from './AvatarHelper';
import { Calendar, Trash2, MessageSquare, Activity, Compass } from 'lucide-react';

interface FriendsViewProps {
  currentUser: User;
  allUsers: User[];
  connectedBuddiesIds: string[];
  workoutInvites: WorkoutInvite[];
  onRemoveFriend: (friendId: string) => void;
  onOpenChatWith: (friendId: string) => void;
  onNavigateToDiscover: () => void;
}

export const FriendsView: React.FC<FriendsViewProps> = ({
  currentUser,
  allUsers,
  connectedBuddiesIds,
  workoutInvites,
  onRemoveFriend,
  onOpenChatWith,
  onNavigateToDiscover
}) => {
  // Get active friend users
  const activeFriends = allUsers.filter(u => connectedBuddiesIds.includes(u.id));

  // Get mutual upcoming workout invitations that are "Accepted"
  const upcomingWorkouts = workoutInvites.filter(invite => {
    const isParticipant = invite.senderId === currentUser.id || invite.receiverId === currentUser.id;
    return isParticipant && invite.status === 'Accepted';
  }).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  return (
    <div className="max-w-5xl mx-auto py-8 px-4" id="friends-dashboard">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Buddy Directory (8 Columns) */}
        <div className="md:col-span-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-black text-white tracking-tight uppercase">Fitness Buddies</h2>
              <p className="text-xs text-zinc-500 mt-1">Your network of active mutual gym partners and trainers.</p>
            </div>
            <span className="bg-red-600/10 border border-red-500/20 text-red-500 text-xs font-bold font-mono px-3 py-1 rounded-xl">
              {activeFriends.length} Active Connections
            </span>
          </div>

          {activeFriends.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {activeFriends.map((friend) => (
                <div
                  key={friend.id}
                  className="bg-zinc-900 border border-zinc-850 p-5 rounded-3xl flex flex-col justify-between hover:border-zinc-800 transition-all text-left shadow-md"
                  id={`friend-card-${friend.id}`}
                >
                  <div className="flex items-center gap-3">
                    <AvatarHelper avatarId={friend.profilePic} size="md" showStatus isOnline={true} />
                    <div>
                      <h4 className="text-sm font-extrabold text-white leading-tight">{friend.name}</h4>
                      <p className="text-[10px] text-zinc-500 font-mono mt-0.5">📍 {friend.favoriteGym}</p>
                    </div>
                  </div>

                  {/* Highlights */}
                  <div className="grid grid-cols-2 gap-2 my-4 bg-zinc-950/40 border border-zinc-850 p-2.5 rounded-xl text-[10px]">
                    <div>
                      <span className="text-zinc-500 font-bold uppercase block">Activity</span>
                      <span className="text-white font-semibold truncate block mt-0.5">{friend.activities[0]}</span>
                    </div>
                    <div>
                      <span className="text-zinc-500 font-bold uppercase block">Experience</span>
                      <span className="text-red-500 font-mono font-bold block mt-0.5">{friend.fitnessLevel}</span>
                    </div>
                  </div>

                  {/* Actions footer */}
                  <div className="flex items-center justify-between border-t border-zinc-850/60 pt-3">
                    <span className="text-[9px] text-zinc-500 font-mono italic">{friend.lastActive}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => onRemoveFriend(friend.id)}
                        className="p-2 rounded-xl bg-zinc-950 border border-zinc-800 hover:bg-red-500/10 hover:text-red-500 text-zinc-500 transition-colors"
                        title="Remove Connection"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onOpenChatWith(friend.id)}
                        className="px-3.5 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl flex items-center gap-1 transition-all active:scale-95"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat</span>
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-zinc-900 border border-zinc-850 p-12 rounded-[32px] text-center shadow-lg min-h-[300px] flex flex-col items-center justify-center">
              <div className="w-12 h-12 bg-red-600/10 rounded-full flex items-center justify-center border border-red-500/20 mb-4 animate-bounce">
                <Compass className="text-red-500 w-6 h-6" />
              </div>
              <h4 className="text-white font-bold text-sm">Find gym buddies nearby</h4>
              <p className="text-xs text-zinc-500 mt-1 max-w-xs leading-normal">
                You haven't made any connections yet. Swipe on the feed or explore local users to find exercise partners.
              </p>
              <button
                onClick={onNavigateToDiscover}
                className="mt-5 px-5 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition-all shadow-md"
              >
                Start Swiping
              </button>
            </div>
          )}
        </div>

        {/* Right column: Upcoming workouts list (4 Columns) */}
        <div className="md:col-span-4 bg-zinc-900 border border-zinc-850 p-6 rounded-3xl text-left shadow-md">
          <div className="flex items-center gap-2 border-b border-zinc-850 pb-3 mb-4">
            <Calendar className="text-red-500 w-5 h-5" />
            <h3 className="font-extrabold text-sm text-white uppercase tracking-wider">Workout Schedule</h3>
          </div>

          {upcomingWorkouts.length > 0 ? (
            <div className="space-y-3">
              {upcomingWorkouts.map((invite) => {
                const partnerId = invite.senderId === currentUser.id ? invite.receiverId : invite.senderId;
                const partner = allUsers.find(u => u.id === partnerId);
                if (!partner) return null;

                return (
                  <div key={invite.id} className="bg-zinc-950/60 border border-zinc-850 p-3.5 rounded-2xl text-xs space-y-2">
                    <div className="flex items-center gap-2 border-b border-zinc-900 pb-2">
                      <AvatarHelper avatarId={partner.profilePic} size="sm" />
                      <div>
                        <p className="font-bold text-white text-[11px] leading-tight">{invite.activity}</p>
                        <p className="text-[10px] text-zinc-500">With {partner.name.split(' ')[0]}</p>
                      </div>
                    </div>

                    <div className="space-y-1 text-[10px] text-zinc-400">
                      <p>📍 {invite.location}</p>
                      <p className="text-red-400 font-bold font-mono">📅 {invite.date} @ {invite.time}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-6 text-center text-zinc-500 text-xs">
              No accepted workouts in your schedule. Select an active buddy in Chat and send a "Workout Invitation" to coordinate!
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
