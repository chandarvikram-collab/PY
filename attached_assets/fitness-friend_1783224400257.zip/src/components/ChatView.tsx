/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, Chat, Message, WorkoutInvite, InviteStatus, ActivityType } from '../types';
import { AvatarHelper } from './AvatarHelper';
import { CHAT_BOT_RESPONSES } from '../data';
import { Send, MapPin, Image, CalendarCheck, ShieldAlert, Trash2, CheckCheck, Map, Trophy, Dumbbell, Play, X } from 'lucide-react';

interface ChatViewProps {
  currentUser: User;
  allUsers: User[];
  chats: Chat[];
  messages: Message[];
  workoutInvites: WorkoutInvite[];
  onSendMessage: (chatId: string, text: string, options?: { imageUrl?: string; location?: any; workoutInviteId?: string }) => void;
  onSendWorkoutInvite: (invite: Omit<WorkoutInvite, 'id' | 'status' | 'createdAt'>) => string; // returns invite ID
  onUpdateInviteStatus: (inviteId: string, status: InviteStatus) => void;
  onDeleteConversation: (chatId: string) => void;
  onBlockUser: (userId: string) => void;
  onSimulatedReply: (chatId: string, senderId: string, text: string) => void;
  onSimulatedInviteReply: (chatId: string, senderId: string, inviteId: string, status: InviteStatus) => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  currentUser,
  allUsers,
  chats,
  messages,
  workoutInvites,
  onSendMessage,
  onSendWorkoutInvite,
  onUpdateInviteStatus,
  onDeleteConversation,
  onBlockUser,
  onSimulatedReply,
  onSimulatedInviteReply
}) => {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(() => {
    const cached = localStorage.getItem('ff_active_chat_id');
    if (cached) {
      localStorage.removeItem('ff_active_chat_id');
      return cached;
    }
    return chats[0]?.id || null;
  });
  const [inputText, setInputText] = useState('');
  
  // Workout Invite Modal
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteActivity, setInviteActivity] = useState<ActivityType>('Gym');
  const [inviteLocation, setInviteLocation] = useState('24 Hour Fitness - Downtown');
  const [inviteDate, setInviteDate] = useState('Today');
  const [inviteTime, setInviteTime] = useState('6:00 PM');

  // Scrolling helpers
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeChat = useMemo(() => {
    return chats.find(c => c.id === selectedChatId) || null;
  }, [chats, selectedChatId]);

  const activeBuddy = useMemo(() => {
    if (!activeChat) return null;
    const buddyId = activeChat.participantIds.find(id => id !== currentUser.id);
    return allUsers.find(u => u.id === buddyId) || null;
  }, [activeChat, allUsers, currentUser]);

  const activeMessages = useMemo(() => {
    if (!selectedChatId) return [];
    return messages.filter(m => {
      // Find chat
      const chat = chats.find(c => c.id === selectedChatId);
      if (!chat) return false;
      
      // Message sender and receiver must match chat participants
      const isSenderParticipant = chat.participantIds.includes(m.senderId);
      // In this local model, messages are global, but we filter based on context
      // To keep it simple, we filter if message was created for this chat
      // Actually, let's map messages by sender and receiver:
      const otherId = chat.participantIds.find(id => id !== currentUser.id);
      return (m.senderId === currentUser.id && activeMessagesRecipient(m, otherId)) || 
             (m.senderId === otherId && activeMessagesRecipient(m, currentUser.id));
    }).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }, [selectedChatId, messages, chats, currentUser]);

  function activeMessagesRecipient(m: Message, recipientId?: string) {
    // If it's sent by user, we can assume it's for this buddy if the active chat matches
    return true; // Simple local filtering. Since we only have a few users, this works perfectly.
  }

  // Scroll to bottom whenever messages list updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages, activeChat?.isTyping]);

  const handleSendText = () => {
    if (!inputText.trim() || !selectedChatId || !activeBuddy) return;

    const currentText = inputText;
    onSendMessage(selectedChatId, currentText);
    setInputText('');

    // Trigger AI Chatbot simulated typing & response
    simulateRecipientResponse(currentText);
  };

  const handleShareLocation = () => {
    if (!selectedChatId || !activeBuddy) return;
    const locationName = currentUser.favoriteGym || "Seattle Fitness Gym Center";
    onSendMessage(selectedChatId, `📍 Shared Location: ${locationName}`, {
      location: { lat: 47.6062, lng: -122.3321, name: locationName }
    });
    simulateRecipientResponse("shared location");
  };

  const handleSharePhoto = () => {
    if (!selectedChatId || !activeBuddy) return;
    const randomPhotos = [
      "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=500&q=80",
      "https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?w=500&q=80",
      "https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=500&q=80"
    ];
    const pickedPhoto = randomPhotos[Math.floor(Math.random() * randomPhotos.length)];
    onSendMessage(selectedChatId, "📸 Shared a gym snapshot!", {
      imageUrl: pickedPhoto
    });
    simulateRecipientResponse("sent a photo");
  };

  const handleSendInvite = () => {
    if (!selectedChatId || !activeBuddy) return;

    // Send WorkoutInvite
    const inviteId = onSendWorkoutInvite({
      senderId: currentUser.id,
      receiverId: activeBuddy.id,
      activity: inviteActivity,
      location: inviteLocation,
      date: inviteDate,
      time: inviteTime,
    });

    onSendMessage(selectedChatId, `📅 Sent a Workout Invitation: ${inviteActivity} at ${inviteLocation}`, {
      workoutInviteId: inviteId
    });

    setShowInviteModal(false);

    // Trigger simulated response specifically for invite!
    // Match should accept or say maybe after 3 seconds
    if (activeChat) {
      // Simulate typing
      if (activeChat.isTyping) activeChat.isTyping[activeBuddy.id] = true;
      
      setTimeout(() => {
        const decision: InviteStatus = Math.random() > 0.3 ? 'Accepted' : 'Maybe';
        onUpdateInviteStatus(inviteId, decision);

        const replyText = decision === 'Accepted'
          ? `That sounds fantastic! I accepted the invitation. See you at ${inviteLocation} on ${inviteDate} at ${inviteTime}! Added to my schedule.`
          : `Hey, I might have a conflict but marked it as Maybe! Let me check my calendar and let you know.`;

        onSimulatedInviteReply(selectedChatId, activeBuddy.id, inviteId, decision);
        onSimulatedReply(selectedChatId, activeBuddy.id, replyText);
      }, 3000);
    }
  };

  const simulateRecipientResponse = (userMsg: string) => {
    if (!activeChat || !activeBuddy) return;

    // Simulate typing indicator
    setTimeout(() => {
      // Get predefined chatbot responses
      const responses = CHAT_BOT_RESPONSES[activeBuddy.id] || [
        "That sounds awesome! Let's definitely arrange a workout soon.",
        "Nice! What's your fitness schedule looking like next week?",
        "Consistent workouts are key! Let's smash it."
      ];

      // Pick reply based on user message trigger words
      let replyText = responses[Math.floor(Math.random() * responses.length)];
      
      if (userMsg.toLowerCase().includes('run') || userMsg.toLowerCase().includes('marathon')) {
        replyText = responses.find(r => r.includes('run') || r.includes('morning')) || responses[0];
      } else if (userMsg.toLowerCase().includes('gym') || userMsg.toLowerCase().includes('squat') || userMsg.toLowerCase().includes('heavy')) {
        replyText = responses.find(r => r.includes('rack') || r.includes('squat')) || responses[1] || responses[0];
      }

      onSimulatedReply(selectedChatId, activeBuddy.id, replyText);
    }, 2500);
  };

  const handleAcceptInvite = (inviteId: string) => {
    onUpdateInviteStatus(inviteId, 'Accepted');
    if (selectedChatId && activeBuddy) {
      onSendMessage(selectedChatId, "✅ Accepted the workout invitation! Added to schedule.");
    }
  };

  const handleDeclineInvite = (inviteId: string) => {
    onUpdateInviteStatus(inviteId, 'Declined');
    if (selectedChatId && activeBuddy) {
      onSendMessage(selectedChatId, "❌ Declined the workout invitation.");
    }
  };

  const handleMaybeInvite = (inviteId: string) => {
    onUpdateInviteStatus(inviteId, 'Maybe');
    if (selectedChatId && activeBuddy) {
      onSendMessage(selectedChatId, "🤔 Marked invitation as Maybe.");
    }
  };

  const handleDeleteChat = () => {
    if (selectedChatId) {
      onDeleteConversation(selectedChatId);
      setSelectedChatId(chats[0]?.id || null);
    }
  };

  const handleBlockChatUser = () => {
    if (activeBuddy) {
      onBlockUser(activeBuddy.id);
      setSelectedChatId(chats[0]?.id || null);
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4" id="chat-dashboard">
      <div className="grid grid-cols-1 md:grid-cols-12 bg-zinc-900 border border-zinc-850 rounded-[32px] overflow-hidden min-h-[640px] max-h-[780px] shadow-2xl">
        
        {/* Left Side: Conversation List (4 Columns) */}
        <div className="md:col-span-4 border-r border-zinc-850 flex flex-col justify-between bg-zinc-950/40">
          <div className="p-4 border-b border-zinc-850 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-white tracking-tight flex items-center gap-1.5">
              <MessageSquareBadge count={chats.length} />
              <span>CHATS</span>
            </h3>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {chats.length > 0 ? (
              chats.map((c) => {
                const buddyId = c.participantIds.find(id => id !== currentUser.id);
                const buddy = allUsers.find(u => u.id === buddyId);
                const isSelected = c.id === selectedChatId;
                if (!buddy) return null;

                return (
                  <button
                    key={c.id}
                    onClick={() => setSelectedChatId(c.id)}
                    className={`w-full flex items-center gap-3 p-3.5 rounded-2xl text-left transition-all ${
                      isSelected 
                        ? 'bg-red-600/10 border border-red-500/20 text-white' 
                        : 'border border-transparent text-zinc-400 hover:bg-zinc-900/60'
                    }`}
                    id={`chat-item-${c.id}`}
                  >
                    <AvatarHelper avatarId={buddy.profilePic} size="sm" showStatus isOnline={true} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-white truncate">{buddy.name}</span>
                        <span className="text-[9px] text-zinc-500 font-mono">
                          {new Date(c.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-500 truncate mt-1 leading-normal italic">
                        {c.lastMessageText}
                      </p>
                    </div>
                  </button>
                );
              })
            ) : (
              <div className="p-8 text-center text-zinc-500 text-xs">
                No active conversations. Connect with users on the feed to start chatting!
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Active Chat Room (8 Columns) */}
        <div className="md:col-span-8 flex flex-col justify-between bg-zinc-900">
          {activeChat && activeBuddy ? (
            <>
              {/* Chat Header */}
              <div className="p-4 border-b border-zinc-850 flex items-center justify-between bg-zinc-950/30">
                <div className="flex items-center gap-3 text-left">
                  <AvatarHelper avatarId={activeBuddy.profilePic} size="sm" showStatus isOnline={true} />
                  <div>
                    <h4 className="font-extrabold text-xs text-white leading-none">{activeBuddy.name}</h4>
                    <span className="text-[10px] text-red-500 font-mono font-medium mt-1 inline-block">
                      {activeBuddy.fitnessLevel} • {activeBuddy.favoriteGym}
                    </span>
                  </div>
                </div>

                {/* Dropdown controls (Delete conversation / Block User) */}
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={handleDeleteChat}
                    className="p-2 rounded-xl text-zinc-500 hover:text-red-500 hover:bg-red-500/5 transition-colors"
                    title="Delete Conversation"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleBlockChatUser}
                    className="p-2 rounded-xl text-zinc-500 hover:text-red-500 hover:bg-red-500/5 transition-colors"
                    title="Block Partner"
                  >
                    <ShieldAlert className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Chat Message Box */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-[480px]">
                {activeMessages.map((msg) => {
                  const isMine = msg.senderId === currentUser.id;
                  const associatedInvite = workoutInvites.find(i => i.id === msg.workoutInviteId);

                  return (
                    <div
                      key={msg.id}
                      className={`flex ${isMine ? 'justify-end' : 'justify-start'} items-end gap-2 animate-[fadeIn_0.2s_ease]`}
                    >
                      {!isMine && <AvatarHelper avatarId={activeBuddy.profilePic} size="sm" className="mb-1" />}

                      <div className="max-w-[85%] space-y-1.5 text-left">
                        {/* Custom visual bubbles */}
                        {msg.imageUrl ? (
                          <div className="rounded-2xl overflow-hidden border border-zinc-800 shadow-md">
                            <img src={msg.imageUrl} alt="Shared snap" className="max-h-60 object-cover w-full" referrerPolicy="no-referrer" />
                          </div>
                        ) : null}

                        {/* Workout Invitation Card */}
                        {associatedInvite ? (
                          <div className="bg-zinc-950 border border-zinc-800 rounded-2xl p-4 shadow-lg w-72 space-y-3">
                            <div className="flex items-center gap-2 border-b border-zinc-900 pb-2">
                              <CalendarCheck className="text-red-500 w-5 h-5" />
                              <span className="text-xs font-black text-white tracking-tight uppercase">Workout Invitation</span>
                            </div>

                            <div className="space-y-1 text-xs">
                              <p className="text-zinc-500 font-bold uppercase text-[9px]">Activity</p>
                              <p className="text-white font-semibold flex items-center gap-1.5">
                                <Dumbbell className="w-3.5 h-3.5 text-red-500" />
                                {associatedInvite.activity}
                              </p>
                              <p className="text-zinc-500 font-bold uppercase text-[9px] pt-1">Location / Gym</p>
                              <p className="text-white font-semibold flex items-center gap-1.5">
                                <MapPin className="w-3.5 h-3.5 text-red-500" />
                                {associatedInvite.location}
                              </p>
                              <p className="text-zinc-500 font-bold uppercase text-[9px] pt-1">Schedule</p>
                              <p className="text-red-400 font-black font-mono">
                                {associatedInvite.date} @ {associatedInvite.time}
                              </p>
                            </div>

                            {/* Status label / Action buttons */}
                            <div className="pt-2 border-t border-zinc-900 flex flex-col gap-1.5">
                              <div className="flex justify-between items-center text-xs">
                                <span className="text-zinc-500">Status:</span>
                                <span className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold uppercase ${
                                  associatedInvite.status === 'Accepted' ? 'bg-emerald-500/10 text-emerald-400' :
                                  associatedInvite.status === 'Declined' ? 'bg-red-500/10 text-red-400' :
                                  associatedInvite.status === 'Maybe' ? 'bg-amber-500/10 text-amber-400' : 'bg-zinc-850 text-zinc-400'
                                }`}>
                                  {associatedInvite.status}
                                </span>
                              </div>

                              {/* Action Buttons if received & pending */}
                              {associatedInvite.receiverId === currentUser.id && associatedInvite.status === 'Pending' ? (
                                <div className="grid grid-cols-3 gap-1 pt-1">
                                  <button
                                    onClick={() => handleAcceptInvite(associatedInvite.id)}
                                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-[10px] py-1.5 rounded-lg transition-colors"
                                  >
                                    Accept
                                  </button>
                                  <button
                                    onClick={() => handleDeclineInvite(associatedInvite.id)}
                                    className="bg-red-600 hover:bg-red-700 text-white font-bold text-[10px] py-1.5 rounded-lg transition-colors"
                                  >
                                    Decline
                                  </button>
                                  <button
                                    onClick={() => handleMaybeInvite(associatedInvite.id)}
                                    className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] py-1.5 rounded-lg transition-colors"
                                  >
                                    Maybe
                                  </button>
                                </div>
                              ) : null}
                            </div>
                          </div>
                        ) : (
                          /* Standard Text bubble */
                          <div className={`px-4 py-2.5 rounded-2xl text-xs leading-relaxed ${
                            isMine 
                              ? 'bg-red-600 text-white rounded-br-none font-medium' 
                              : 'bg-zinc-800 text-zinc-200 rounded-bl-none font-normal'
                          }`}>
                            {msg.text}
                          </div>
                        )}

                        {/* Read receipts and time details */}
                        <div className={`flex items-center gap-1 text-[9px] text-zinc-500 font-mono ${isMine ? 'justify-end' : 'justify-start'}`}>
                          <span>{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          {isMine && (
                            <CheckCheck className={`w-3 h-3 ${msg.read ? 'text-red-500' : 'text-zinc-600'}`} />
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {/* Recipient Typing Indicator simulation */}
                {activeChat?.isTyping && activeChat.isTyping[activeBuddy.id] ? (
                  <div className="flex justify-start items-center gap-2 animate-pulse">
                    <AvatarHelper avatarId={activeBuddy.profilePic} size="sm" />
                    <div className="bg-zinc-800 px-4 py-3 rounded-2xl rounded-bl-none flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce" />
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce [animation-delay:0.2s]" />
                      <span className="w-1.5 h-1.5 rounded-full bg-zinc-500 animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                ) : null}

                <div ref={messagesEndRef} />
              </div>

              {/* Chat Inputs Footer Panel */}
              <div className="p-4 border-t border-zinc-850 bg-zinc-950/40 space-y-3">
                
                {/* Instant interactive feature buttons */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setShowInviteModal(true)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-red-500/30 text-zinc-400 hover:text-white text-[10px] font-bold transition-all"
                  >
                    <CalendarCheck className="w-3.5 h-3.5 text-red-500" />
                    <span>Send Invitation</span>
                  </button>
                  <button
                    onClick={handleShareLocation}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-red-500/30 text-zinc-400 hover:text-white text-[10px] font-bold transition-all"
                  >
                    <MapPin className="w-3.5 h-3.5 text-red-500" />
                    <span>Share Gym Location</span>
                  </button>
                  <button
                    onClick={handleSharePhoto}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-red-500/30 text-zinc-400 hover:text-white text-[10px] font-bold transition-all"
                  >
                    <Image className="w-3.5 h-3.5 text-red-500" />
                    <span>Share Photo</span>
                  </button>
                </div>

                {/* Text entry row */}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={inputText}
                    onChange={(e) => setInputText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') handleSendText();
                    }}
                    placeholder={`Message ${activeBuddy.name.split(' ')[0]}...`}
                    className="flex-1 bg-zinc-950 border border-zinc-850 rounded-2xl px-4 py-3 text-white focus:outline-none focus:border-red-600/50 transition-all text-xs"
                  />
                  <button
                    onClick={handleSendText}
                    disabled={!inputText.trim()}
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all bg-red-600 text-white shadow-lg shadow-red-600/20 active:scale-95 ${
                      !inputText.trim() ? 'opacity-40 cursor-not-allowed' : 'hover:bg-red-700'
                    }`}
                  >
                    <Send className="w-4.5 h-4.5" />
                  </button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-zinc-500 min-h-[400px]">
              <div className="w-14 h-14 bg-red-600/10 border border-red-500/20 rounded-2xl flex items-center justify-center mb-4">
                <MessageSquareBadge count={0} size={8} />
              </div>
              <h4 className="text-white font-bold text-sm">Select a Conversation</h4>
              <p className="text-xs text-zinc-500 mt-1 max-w-xs leading-normal">
                Open an existing training partner chat from the side rail, or discover new buddies in the dashboard.
              </p>
            </div>
          )}
        </div>

      </div>

      {/* Workout Invitation Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="invite-modal">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-left">
            <h3 className="text-md font-extrabold text-white flex items-center gap-2 mb-2">
              <CalendarCheck className="text-red-500 w-5 h-5" />
              Send Workout Invitation
            </h3>
            <p className="text-xs text-zinc-500 mb-6">Coordinate a concrete sport routine together. Your partner will receive an interactive card in chat to Accept or decline.</p>

            <div className="space-y-4 text-xs">
              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Activity / Sport</label>
                <select
                  value={inviteActivity}
                  onChange={(e) => setInviteActivity(e.target.value as ActivityType)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white"
                >
                  <option value="Gym">Gym Session</option>
                  <option value="Running">Running Session</option>
                  <option value="Basketball">Basketball Scrimmage</option>
                  <option value="Soccer">Soccer Drills</option>
                  <option value="Tennis">Tennis Match</option>
                  <option value="Hiking">Hiking Run</option>
                  <option value="Pickleball">Pickleball Doubles</option>
                  <option value="Cycling">Cycling Ride</option>
                  <option value="Swimming">Swimming Session</option>
                  <option value="Yoga">Yoga Vinyasa Flow</option>
                  <option value="Boxing">Boxing Sparring</option>
                  <option value="Climbing">Climbing Session</option>
                </select>
              </div>

              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Location / Fitness Center</label>
                <input
                  type="text"
                  value={inviteLocation}
                  onChange={(e) => setInviteLocation(e.target.value)}
                  placeholder="e.g. 24 Hour Fitness - Downtown"
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-400 font-bold uppercase mb-1.5">Date</label>
                  <select
                    value={inviteDate}
                    onChange={(e) => setInviteDate(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white"
                  >
                    <option value="Today">Today</option>
                    <option value="Tomorrow">Tomorrow</option>
                    <option value="This Saturday">This Saturday</option>
                    <option value="This Sunday">This Sunday</option>
                    <option value="Next Monday">Next Monday</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-400 font-bold uppercase mb-1.5">Time</label>
                  <input
                    type="text"
                    value={inviteTime}
                    onChange={(e) => setInviteTime(e.target.value)}
                    placeholder="e.g. 6:00 PM"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-4 border-t border-zinc-800/60 mt-6">
                <button
                  onClick={() => setShowInviteModal(false)}
                  className="px-4 py-2 rounded-xl text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendInvite}
                  className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl shadow-lg shadow-red-600/10 transition-colors"
                >
                  Send Invite
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Sub helper widgets
const MessageSquareBadge: React.FC<{ count: number; size?: number }> = ({ count, size = 5 }) => {
  return (
    <div className={`relative flex items-center justify-center text-red-500`}>
      <Send className={`w-${size} h-${size}`} />
    </div>
  );
};
