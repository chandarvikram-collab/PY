/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { User } from '../types';
import { Dumbbell, Compass, Users, MessageSquare, Settings, ShieldAlert, ArrowLeftRight, Bell } from 'lucide-react';
import { AvatarHelper } from './AvatarHelper';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentUser: User;
  allUsers: User[];
  onSwitchUser: (userId: string) => void;
  notificationsCount: number;
  isAdmin: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  currentUser,
  allUsers,
  onSwitchUser,
  notificationsCount,
  isAdmin
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#0A0A0A] border-b border-white/5 px-4 py-3" id="app-header">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* App Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#E53935] rounded-xl flex items-center justify-center shadow-[0_0_20px_rgba(229,57,53,0.4)]">
            <Dumbbell className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
              FITNESS <span className="text-[#E53935] font-bold text-sm tracking-widest px-1.5 py-0.5 bg-[#E53935]/10 border border-[#E53935]/20 rounded-md">FRIEND</span>
            </h1>
            <p className="text-[10px] text-white/40 font-mono">Sweat together, grow together</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 bg-white/5 p-1.5 border border-white/10 rounded-2xl overflow-x-auto w-full md:w-auto">
          {[
            { id: 'dashboard', label: 'Feed', icon: Dumbbell },
            { id: 'discover', label: 'Discover', icon: Compass },
            { id: 'friends', label: 'Buddies', icon: Users },
            { id: 'messages', label: 'Messages', icon: MessageSquare, badge: notificationsCount },
            { id: 'settings', label: 'Settings', icon: Settings },
            ...(isAdmin ? [{ id: 'admin', label: 'Admin', icon: ShieldAlert }] : [])
          ].map((tab) => {
            const IconComponent = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold tracking-tight transition-all flex-shrink-0 ${
                  isActive
                    ? 'bg-[#E53935] text-white shadow-lg shadow-[#E53935]/20'
                    : 'text-white/60 hover:text-white hover:bg-white/5'
                }`}
                id={`nav-tab-${tab.id}`}
              >
                <IconComponent className="w-4 h-4" />
                <span>{tab.label}</span>
                {tab.badge && tab.badge > 0 ? (
                  <span className="absolute -top-1 -right-1 min-w-4 h-4 rounded-full bg-[#E53935] text-white font-mono text-[9px] font-bold flex items-center justify-center px-1 animate-pulse">
                    {tab.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>

        {/* Account Info and Dev Account Switcher */}
        <div className="flex items-center gap-4 bg-[#0A0A0A] px-3 py-1.5 rounded-2xl border border-white/5 self-stretch md:self-auto justify-between md:justify-end">
          {/* Active User Label */}
          <div className="flex items-center gap-2">
            <AvatarHelper avatarId={currentUser.profilePic} size="sm" showStatus isOnline={true} />
            <div className="text-left hidden sm:block">
              <p className="text-xs font-bold text-white leading-none">{currentUser.name}</p>
              <p className="text-[10px] text-white/40 font-mono mt-0.5">@{currentUser.name.toLowerCase().replace(/\s+/g, '')}</p>
            </div>
          </div>

          {/* Dev Mode Switcher */}
          <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-xl p-1">
            <span className="text-[9px] font-bold text-[#E53935] tracking-wider font-mono px-1">DEV SWITCH:</span>
            <select
              value={currentUser.id}
              onChange={(e) => onSwitchUser(e.target.value)}
              className="bg-[#0A0A0A] border border-white/10 rounded-lg text-[10px] text-white py-1 px-2 focus:outline-none cursor-pointer hover:bg-white/5"
            >
              {allUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.fitnessLevel})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};
