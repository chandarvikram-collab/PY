/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { User, ActivityType, FitnessLevel, Match } from '../types';
import { AvatarHelper, SkillBadge } from './AvatarHelper';
import { calculateCompatibility } from '../data';
import { Search, MapPin, Sparkles, Sliders, Check, X, ShieldAlert, Zap, Calendar, Heart, Target, Dumbbell } from 'lucide-react';

interface DashboardProps {
  currentUser: User;
  allUsers: User[];
  onConnect: (userId: string) => void;
  onBlock: (userId: string) => void;
  onReport: (userId: string, reason: string, details: string) => void;
  connectedBuddiesIds: string[];
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  allUsers,
  onConnect,
  onBlock,
  onReport,
  connectedBuddiesIds
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeQuickFilter, setActiveQuickFilter] = useState<'All' | 'Nearby' | 'Today' | ActivityType | 'Gym' | 'Basketball' | 'Running'>('All');
  
  // Swipe deck index
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Spam');
  const [reportDetails, setReportDetails] = useState('');

  // Get current hour to personalize greeting
  const greeting = useMemo(() => {
    const hours = new Date().getHours();
    if (hours < 12) return 'Good Morning';
    if (hours < 18) return 'Good Afternoon';
    return 'Good Evening';
  }, []);

  // Filter out the current user, already matched/connected users, or banned/blocked profiles
  const eligibleCandidates = useMemo(() => {
    return allUsers.filter(u => {
      // Don't show myself
      if (u.id === currentUser.id) return false;
      // Don't show already connected friends
      if (connectedBuddiesIds.includes(u.id)) return false;
      // Don't show if banned
      if (u.isBanned) return false;
      
      // Calculate match compatibility for further filtering or sorting
      const score = calculateCompatibility(currentUser, u);
      
      // 1. Check Search Query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = u.name.toLowerCase().includes(query);
        const matchesBio = u.bio.toLowerCase().includes(query);
        const matchesGym = u.favoriteGym.toLowerCase().includes(query);
        const matchesCity = u.locationName.toLowerCase().includes(query);
        const matchesActivity = u.activities.some(act => act.toLowerCase().includes(query));
        if (!matchesName && !matchesBio && !matchesGym && !matchesCity && !matchesActivity) {
          return false;
        }
      }

      // 2. Quick Filters
      if (activeQuickFilter === 'Nearby') {
        const dx = currentUser.coordinates.x - u.coordinates.x;
        const dy = currentUser.coordinates.y - u.coordinates.y;
        const dist = Math.sqrt(dx * dx + dy * dy) * 0.7;
        if (dist > 15) return false; // within 15 miles
      } else if (activeQuickFilter === 'Today') {
        // Today workouts mean they are available on weekends if it is weekend, or weekdays if weekday
        const day = new Date().getDay();
        const isWeekend = day === 0 || day === 6;
        if (isWeekend && u.availability === 'Weekdays') return false;
        if (!isWeekend && u.availability === 'Weekends') return false;
      } else if (activeQuickFilter !== 'All') {
        // Activity filter
        if (!u.activities.includes(activeQuickFilter as ActivityType)) return false;
      }

      return true;
    }).map(u => ({
      ...u,
      compatibilityScore: calculateCompatibility(currentUser, u)
    })).sort((a, b) => b.compatibilityScore - a.compatibilityScore); // Higher match first
  }, [allUsers, currentUser, connectedBuddiesIds, searchQuery, activeQuickFilter]);

  // Handle swipes / connectors
  const activeCandidate = eligibleCandidates[currentIndex];

  const handleConnect = () => {
    if (activeCandidate) {
      onConnect(activeCandidate.id);
      // Advance to next card
      if (currentIndex < eligibleCandidates.length) {
        // Keep index intact, but because we matched u, eligibleCandidates list shrinks!
        // So we don't necessarily need to increment unless needed.
      }
    }
  };

  const handlePass = () => {
    setCurrentIndex(prev => Math.min(prev + 1, eligibleCandidates.length - 1));
  };

  const handleResetDeck = () => {
    setCurrentIndex(0);
    setActiveQuickFilter('All');
    setSearchQuery('');
  };

  const handleSubmitReport = () => {
    if (activeCandidate) {
      onReport(activeCandidate.id, reportReason, reportDetails);
      setShowReportModal(false);
      setReportDetails('');
      handlePass(); // Pass this user
    }
  };

  return (
    <div className="max-w-6xl mx-auto py-8 px-4" id="dashboard-root">
      {/* Welcome & Stats Row */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
        <div>
          <h2 className="text-3xl font-black text-white tracking-tight">
            {greeting}, <span className="text-[#E53935]">{currentUser.name.split(' ')[0]}</span> 👋
          </h2>
          <p className="text-sm text-white/40 mt-1">{eligibleCandidates.length} potential partners nearby active now.</p>
        </div>

        {/* Dynamic mini fitness summary */}
        <div className="flex items-center gap-3 bg-[#1A1A1A] border border-white/10 p-3 rounded-2xl">
          <div className="w-9 h-9 rounded-xl bg-[#E53935]/10 flex items-center justify-center border border-[#E53935]/20">
            <Sparkles className="text-[#E53935] w-4.5 h-4.5" />
          </div>
          <div className="text-left font-mono">
            <p className="text-[10px] text-white/40 font-bold uppercase leading-none">Goal Track</p>
            <p className="text-xs font-bold text-white mt-1">{currentUser.primaryGoal}</p>
          </div>
        </div>
      </div>

      {/* Search & Quick Filters */}
      <div className="bg-[#1A1A1A] border border-white/10 p-5 rounded-[24px] mb-8 space-y-4 shadow-xl">
        <div className="relative">
          <input
            type="text"
            placeholder="Search partners by name, activity, gym, city, or goal..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentIndex(0); // reset page
            }}
            className="w-full bg-white/5 border border-white/10 rounded-2xl pl-11 pr-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-[#E53935]/50 focus:border-[#E53935] transition-all text-sm font-medium"
          />
          <Search className="absolute left-4 top-3.5 text-white/30 w-4.5 h-4.5" />
        </div>

        {/* Quick Filters Horizontal Scrolling List */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 select-none custom-scrollbar">
          <span className="text-xs font-black text-white/40 uppercase tracking-[0.15em] mr-1">Quick:</span>
          {(['All', 'Nearby', 'Today', 'Gym', 'Basketball', 'Running'] as const).map((filter) => {
            const isActive = activeQuickFilter === filter;
            return (
              <button
                key={filter}
                onClick={() => {
                  setActiveQuickFilter(filter);
                  setCurrentIndex(0);
                }}
                className={`px-5 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all border ${
                  isActive
                    ? 'bg-[#E53935] text-white border-[#E53935] shadow-lg shadow-[#E53935]/20'
                    : 'bg-white/5 border border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
                }`}
              >
                {filter}
              </button>
            );
          })}
        </div>
      </div>

      {/* Swipe deck matching section */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Large recommendation card (7 columns) */}
        <div className="md:col-span-8 flex flex-col items-center">
          {activeCandidate ? (
            <div className="w-full bg-[#1A1A1A] border border-white/10 rounded-[32px] overflow-hidden shadow-2xl relative transition-all flex flex-col justify-between">
              
              {/* Profile Card Header with Distance Tag */}
              <div className="relative h-[340px] bg-[#0A0A0A] flex items-center justify-center p-6 border-b border-white/10">
                {/* Custom Gradient Background */}
                <div className="absolute inset-0 opacity-15 pointer-events-none" style={{ backgroundImage: `radial-gradient(circle at 50% 50%, #E53935 0%, transparent 70%)` }} />
                
                {/* Large Profile Picture / Custom Avatar */}
                <AvatarHelper avatarId={activeCandidate.profilePic} size="2xl" showStatus={true} isOnline={true} className="z-10" />

                {/* Floating Distance Pill */}
                <div className="absolute top-4 left-4 bg-[#0A0A0A]/95 backdrop-blur border border-white/10 px-3 py-1.5 rounded-xl flex items-center gap-1.5 text-xs font-semibold text-white">
                  <MapPin className="w-3.5 h-3.5 text-[#E53935]" />
                  <span>
                    {(Math.sqrt(
                      Math.pow(currentUser.coordinates.x - activeCandidate.coordinates.x, 2) +
                      Math.pow(currentUser.coordinates.y - activeCandidate.coordinates.y, 2)
                    ) * 0.7).toFixed(1)} miles away ({activeCandidate.locationName})
                  </span>
                </div>

                {/* Floating Compatibility Badge */}
                <div className="absolute top-4 right-4 bg-[#E53935] border border-red-500 text-white font-mono font-black text-xs px-3 py-1.5 rounded-xl flex items-center gap-1 shadow-lg shadow-[#E53935]/30">
                  <Zap className="w-3.5 h-3.5" />
                  <span>{activeCandidate.compatibilityScore}% Match</span>
                </div>

                {/* Dynamic Banner Overlay */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#0A0A0A]/90 backdrop-blur-md border border-white/10 p-4 rounded-2xl z-10">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-extrabold text-white leading-none">
                        {activeCandidate.name}, <span className="text-white/60 text-lg font-medium">{activeCandidate.age}</span>
                      </h3>
                      <p className="text-xs text-white/50 mt-1.5 flex items-center gap-1 font-medium">
                        📍 {activeCandidate.favoriteGym}
                      </p>
                    </div>
                    <SkillBadge level={activeCandidate.fitnessLevel} />
                  </div>
                </div>
              </div>

              {/* Bio & Fitness Metadata details */}
              <div className="p-6 space-y-5 text-left bg-[#1A1A1A]">
                <div>
                  <h4 className="text-xs font-bold text-white/40 uppercase tracking-wider mb-2">Bio</h4>
                  <p className="text-sm text-white/80 leading-relaxed font-normal bg-white/5 p-3 rounded-xl border border-white/10">
                    "{activeCandidate.bio}"
                  </p>
                </div>

                {/* Grid stats */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Goal</span>
                    <p className="text-xs font-semibold text-white mt-1 flex items-center gap-1.5">
                      <Target className="w-3.5 h-3.5 text-[#E53935]" />
                      {activeCandidate.primaryGoal}
                    </p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-xl p-3">
                    <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">Schedule</span>
                    <p className="text-xs font-semibold text-white mt-1 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#E53935]" />
                      {activeCandidate.availability} • {activeCandidate.preferredTime.join(', ')}
                    </p>
                  </div>
                </div>

                {/* Activities Overlap list */}
                <div>
                  <h4 className="text-xs font-bold text-white/40 uppercase tracking-wider mb-2">Activities</h4>
                  <div className="flex flex-wrap gap-2">
                    {activeCandidate.activities.map((act) => {
                      const overlaps = currentUser.activities.includes(act);
                      return (
                        <span
                          key={act}
                          className={`px-3 py-1 rounded-xl text-xs font-medium flex items-center gap-1 border ${
                            overlaps
                              ? 'bg-[#E53935]/10 text-white border-[#E53935]/30'
                              : 'bg-white/5 text-white/40 border-white/5'
                          }`}
                        >
                          {overlaps && <Heart className="w-3 h-3 text-[#E53935] fill-[#E53935]" />}
                          {act}
                        </span>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Swipe/Match Action Controls */}
              <div className="p-6 bg-[#0A0A0A] border-t border-white/5 flex items-center justify-between gap-4">
                {/* Report button */}
                <button
                  onClick={() => setShowReportModal(true)}
                  className="flex items-center gap-1 px-3 py-2 text-white/40 hover:text-[#E53935] text-xs font-bold transition-colors"
                >
                  <ShieldAlert className="w-4 h-4" />
                  Report User
                </button>

                <div className="flex items-center gap-3">
                  {/* Pass Button */}
                  <button
                    onClick={handlePass}
                    className="w-12 h-12 bg-white/5 border border-white/10 rounded-2xl flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white shadow-md transition-all active:scale-95"
                    title="Pass"
                  >
                    <X className="w-6 h-6" />
                  </button>

                  {/* Connect / Like Button */}
                  <button
                    onClick={handleConnect}
                    className="px-6 py-3 bg-[#E53935] hover:bg-[#D32F2F] text-white font-black text-xs rounded-2xl flex items-center gap-2 shadow-lg shadow-[#E53935]/20 transition-all active:scale-95 hover:scale-102 uppercase tracking-wider"
                    title="Connect"
                  >
                    <Check className="w-4 h-4" />
                    <span>CONNECT</span>
                  </button>
                </div>
              </div>

            </div>
          ) : (
            /* No more cards display */
            <div className="w-full bg-[#1A1A1A] border border-white/10 rounded-[32px] p-12 text-center shadow-lg flex flex-col items-center justify-center min-h-[480px]">
              <div className="w-16 h-16 rounded-full bg-[#E53935]/10 flex items-center justify-center border border-[#E53935]/20 mb-6">
                <Dumbbell className="text-[#E53935] w-8 h-8 animate-bounce" />
              </div>
              <h3 className="text-xl font-bold text-white tracking-tight">No training partners found</h3>
              <p className="text-sm text-white/40 mt-2 max-w-sm">
                Try expanding your search query, changing quick filters, or reset the deck to browse again.
              </p>
              <button
                onClick={handleResetDeck}
                className="mt-6 px-6 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs font-bold text-white hover:bg-white/10 transition-all"
              >
                Reset Feed & Filters
              </button>
            </div>
          )}
        </div>

        {/* Sidebar Info/Stats (4 columns) */}
        <div className="md:col-span-4 space-y-6">
          {/* Quick compatibility summary widget */}
          <div className="bg-[#1A1A1A] border border-white/10 p-6 rounded-3xl text-left shadow-md">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5 mb-4">
              <Zap className="text-[#E53935] w-4.5 h-4.5" />
              <span>Matching Algorithm</span>
            </h3>
            <p className="text-xs text-white/40 leading-relaxed mb-4">
              We look at your profile choices and calculate overlays to ensure workout compatibility:
            </p>
            <ul className="space-y-3 text-xs font-medium font-mono text-white/60">
              <li className="flex justify-between items-center bg-white/5 p-2 rounded-xl border border-white/5">
                <span>📍 Location proximity</span>
                <span className="text-[#E53935]">30% Weight</span>
              </li>
              <li className="flex justify-between items-center bg-white/5 p-2 rounded-xl border border-white/5">
                <span>🤝 Activity Overlap</span>
                <span className="text-[#E53935]">25% Weight</span>
              </li>
              <li className="flex justify-between items-center bg-white/5 p-2 rounded-xl border border-white/5">
                <span>💪 Fitness Level Match</span>
                <span className="text-[#E53935]">20% Weight</span>
              </li>
              <li className="flex justify-between items-center bg-white/5 p-2 rounded-xl border border-white/5">
                <span>📅 Availability Sync</span>
                <span className="text-[#E53935]">15% Weight</span>
              </li>
              <li className="flex justify-between items-center bg-white/5 p-2 rounded-xl border border-white/5">
                <span>🎯 Fitness Goals</span>
                <span className="text-[#E53935]">10% Weight</span>
              </li>
            </ul>
          </div>

          {/* Quick achievements box */}
          <div className="bg-[#1A1A1A] border border-white/10 p-6 rounded-3xl text-left shadow-md">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-3">Your Achievements</h3>
            <div className="space-y-2">
              {currentUser.achievements.map((ach) => (
                <div key={ach} className="text-xs text-white/80 bg-white/5 p-2.5 rounded-xl border border-white/10 flex items-center gap-2 font-medium">
                  <span className="text-[#E53935]">✔</span>
                  {ach}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm" id="report-modal">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-3xl p-6 shadow-2xl">
            <h3 className="text-lg font-bold text-white flex items-center gap-2 mb-2">
              <ShieldAlert className="text-red-500" />
              Report Account
            </h3>
            <p className="text-xs text-zinc-500 mb-4">
              Help keep Fitness Friend safe. Select a reason and detail why this profile should be moderated.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Reason</label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="Spam / Commercial">Spam / Commercial</option>
                  <option value="Inappropriate Profile Content">Inappropriate Profile Content</option>
                  <option value="Harassment or Abuse">Harassment or Abuse</option>
                  <option value="Fake / Impersonation">Fake / Impersonation</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-zinc-400 uppercase mb-2">Details (Optional)</label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  placeholder="Provide any additional details or chat references..."
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-bold text-zinc-400 hover:text-white transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSubmitReport}
                  className="px-5 py-2 rounded-lg text-xs font-bold bg-red-600 hover:bg-red-700 text-white transition-all shadow-md"
                >
                  Submit Report
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
