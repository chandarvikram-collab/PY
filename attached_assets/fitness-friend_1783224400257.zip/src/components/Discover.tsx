/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { User, ActivityType, FitnessLevel, PrimaryGoal, AvailabilityDay } from '../types';
import { AvatarHelper, SkillBadge } from './AvatarHelper';
import { calculateCompatibility } from '../data';
import { MapView } from './MapView';
import { MapPin, Sliders, List, Map, Sparkles, Filter, Check, Heart, Trophy, Search, Compass } from 'lucide-react';

interface DiscoverProps {
  currentUser: User;
  allUsers: User[];
  onConnect: (userId: string) => void;
  connectedBuddiesIds: string[];
}

export const Discover: React.FC<DiscoverProps> = ({
  currentUser,
  allUsers,
  onConnect,
  connectedBuddiesIds
}) => {
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [distanceFilter, setDistanceFilter] = useState(30);
  const [selectedActivity, setSelectedActivity] = useState<string>('All');
  const [selectedGoal, setSelectedGoal] = useState<string>('All');
  const [selectedSkill, setSelectedSkill] = useState<string>('All');
  const [selectedAvailability, setSelectedAvailability] = useState<string>('All');
  const [minAge, setMinAge] = useState(18);
  const [maxAge, setMaxAge] = useState(50);
  const [sortBy, setSortBy] = useState<'compatibility' | 'newest' | 'active'>('compatibility');
  const [searchWord, setSearchWord] = useState('');

  // Dropdown lists
  const activitiesList: ActivityType[] = [
    'Gym', 'Running', 'Basketball', 'Soccer', 'Tennis', 'Hiking', 
    'Pickleball', 'Cycling', 'Swimming', 'Yoga', 'Boxing', 'Climbing'
  ];

  const goalsList: PrimaryGoal[] = [
    'Lose weight', 'Build muscle', 'Strength', 'Endurance', 'Sports', 'General fitness'
  ];

  // Process and Filter Users List
  const filteredUsers = useMemo(() => {
    return allUsers
      .filter((u) => {
        // Exclude self and banned accounts
        if (u.id === currentUser.id) return false;
        if (u.isBanned) return false;

        // 1. Text Search query
        if (searchWord.trim()) {
          const query = searchWord.toLowerCase();
          const matchName = u.name.toLowerCase().includes(query);
          const matchBio = u.bio.toLowerCase().includes(query);
          const matchGym = u.favoriteGym.toLowerCase().includes(query);
          if (!matchName && !matchBio && !matchGym) return false;
        }

        // 2. Distance filter (coordinates based math)
        const dx = currentUser.coordinates.x - u.coordinates.x;
        const dy = currentUser.coordinates.y - u.coordinates.y;
        const dist = Math.sqrt(dx * dx + dy * dy) * 0.7; // coordinates scale to miles
        if (dist > distanceFilter) return false;

        // 3. Activity filter
        if (selectedActivity !== 'All' && !u.activities.includes(selectedActivity as ActivityType)) {
          return false;
        }

        // 4. Fitness goal filter
        if (selectedGoal !== 'All' && u.primaryGoal !== selectedGoal) {
          return false;
        }

        // 5. Experience Skill Level filter
        if (selectedSkill !== 'All' && u.fitnessLevel !== selectedSkill) {
          return false;
        }

        // 6. Availability filter
        if (selectedAvailability !== 'All' && u.availability !== selectedAvailability && u.availability !== 'Both') {
          return false;
        }

        // 7. Age filters
        if (u.age < minAge || u.age > maxAge) return false;

        return true;
      })
      .map((u) => ({
        ...u,
        compatibilityScore: calculateCompatibility(currentUser, u),
        distanceMiles: Math.sqrt(
          Math.pow(currentUser.coordinates.x - u.coordinates.x, 2) +
          Math.pow(currentUser.coordinates.y - u.coordinates.y, 2)
        ) * 0.7
      }))
      .sort((a, b) => {
        if (sortBy === 'compatibility') {
          return b.compatibilityScore - a.compatibilityScore;
        } else if (sortBy === 'newest') {
          // Sort by user ID as mock chronological
          return b.id.localeCompare(a.id);
        } else {
          // Active users first (e.g. active now vs active hours ago)
          const activeScore = (u: any) => {
            if (u.lastActive.includes('now')) return 3;
            if (u.lastActive.includes('m')) return 2;
            if (u.lastActive.includes('h')) return 1;
            return 0;
          };
          return activeScore(b) - activeScore(a);
        }
      });
  }, [allUsers, currentUser, searchWord, distanceFilter, selectedActivity, selectedGoal, selectedSkill, selectedAvailability, minAge, maxAge, sortBy]);

  const handleResetFilters = () => {
    setDistanceFilter(30);
    setSelectedActivity('All');
    setSelectedGoal('All');
    setSelectedSkill('All');
    setSelectedAvailability('All');
    setMinAge(18);
    setMaxAge(50);
    setSearchWord('');
    setSortBy('compatibility');
  };

  return (
    <div className="max-w-7xl mx-auto py-8 px-4" id="discover-root">
      {/* Header and Grid Toggle */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Compass className="text-[#E53935] w-6 h-6" />
            DISCOVER FITNESS BUDS
          </h2>
          <p className="text-xs text-white/40 mt-1">Browse, filter, and discover compatible partners on the list or nearby map.</p>
        </div>

        {/* List / Map Layout Switcher */}
        <div className="flex bg-white/5 border border-white/10 rounded-xl p-1 select-none self-stretch sm:self-auto justify-center">
          <button
            onClick={() => setViewMode('grid')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'grid'
                ? 'bg-[#E53935] text-white shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <List className="w-4 h-4" />
            <span>Card List</span>
          </button>
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
              viewMode === 'map'
                ? 'bg-[#E53935] text-white shadow-md'
                : 'text-white/60 hover:text-white'
            }`}
          >
            <Map className="w-4 h-4" />
            <span>Interactive Map</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Filters Sidebar (4 Columns) */}
        <div className="lg:col-span-4 bg-[#1A1A1A] border border-white/10 p-6 rounded-3xl text-left space-y-6 shadow-lg">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <h3 className="font-extrabold text-sm text-white flex items-center gap-1.5">
              <Filter className="text-[#E53935] w-4.5 h-4.5" />
              <span>REFINE FILTERS</span>
            </h3>
            <button
              onClick={handleResetFilters}
              className="text-[10px] font-bold text-white/40 hover:text-[#E53935] tracking-wide font-mono transition-colors uppercase"
            >
              Reset
            </button>
          </div>

          {/* Search bar within sidebar */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white/40 uppercase">Keyword Search</label>
            <div className="relative">
              <input
                type="text"
                placeholder="Search name, bio, gym..."
                value={searchWord}
                onChange={(e) => setSearchWord(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none focus:border-[#E53935]/50"
              />
              <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-white/30" />
            </div>
          </div>

          {/* Travel distance */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold uppercase">
              <span className="text-white/40">Travel Distance</span>
              <span className="text-[#E53935] font-mono font-black">{distanceFilter} miles</span>
            </div>
            <input
              type="range"
              min="5"
              max="50"
              value={distanceFilter}
              onChange={(e) => setDistanceFilter(parseInt(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-[#E53935]"
            />
          </div>

          {/* Age range */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs font-bold uppercase">
              <span className="text-white/40">Age limits</span>
              <span className="text-[#E53935] font-mono font-black">{minAge} - {maxAge} yrs</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <span className="text-[10px] text-white/30 font-mono">Min Age</span>
                <input
                  type="range"
                  min="18"
                  max="60"
                  value={minAge}
                  onChange={(e) => setMinAge(Math.min(parseInt(e.target.value), maxAge))}
                  className="w-full accent-[#E53935] h-1 bg-white/10 rounded-lg cursor-pointer"
                />
              </div>
              <div>
                <span className="text-[10px] text-white/30 font-mono">Max Age</span>
                <input
                  type="range"
                  min="18"
                  max="60"
                  value={maxAge}
                  onChange={(e) => setMaxAge(Math.max(parseInt(e.target.value), minAge))}
                  className="w-full accent-[#E53935] h-1 bg-white/10 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Selected Activity */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white/40 uppercase">Preferred Activity</label>
            <select
              value={selectedActivity}
              onChange={(e) => setSelectedActivity(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              <option value="All">All Activities</option>
              {activitiesList.map(act => (
                <option key={act} value={act}>{act}</option>
              ))}
            </select>
          </div>

          {/* Goal selection */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white/40 uppercase">Primary goal</label>
            <select
              value={selectedGoal}
              onChange={(e) => setSelectedGoal(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              <option value="All">All Fitness Goals</option>
              {goalsList.map(goal => (
                <option key={goal} value={goal}>{goal}</option>
              ))}
            </select>
          </div>

          {/* Skill level */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white/40 uppercase">Fitness Level</label>
            <select
              value={selectedSkill}
              onChange={(e) => setSelectedSkill(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              <option value="All">All Levels</option>
              <option value="Beginner">Beginner</option>
              <option value="Intermediate">Intermediate</option>
              <option value="Advanced">Advanced</option>
            </select>
          </div>

          {/* Availability */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-white/40 uppercase">Availability</label>
            <select
              value={selectedAvailability}
              onChange={(e) => setSelectedAvailability(e.target.value)}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              <option value="All">Any Availability</option>
              <option value="Weekdays">Weekdays</option>
              <option value="Weekends">Weekends</option>
              <option value="Both">Both</option>
            </select>
          </div>

          {/* Sorting Option */}
          <div className="space-y-1.5 border-t border-white/5 pt-4">
            <label className="text-xs font-bold text-white/40 uppercase">Sort Results By</label>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="w-full bg-[#0A0A0A] border border-white/10 rounded-xl px-3 py-2 text-xs text-white cursor-pointer"
            >
              <option value="compatibility">Highest Match %</option>
              <option value="newest">Recently Joined</option>
              <option value="active">Recently Active</option>
            </select>
          </div>
        </div>

        {/* Search Results / Map Content (8 Columns) */}
        <div className="lg:col-span-8">
          {viewMode === 'grid' ? (
            <div>
              {/* Count Tag */}
              <div className="flex justify-between items-center mb-4 px-1">
                <span className="text-xs font-black text-white/40 font-mono tracking-widest uppercase">
                  SHOWING {filteredUsers.length} RESULTS
                </span>
              </div>

              {filteredUsers.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {filteredUsers.map((user) => {
                    const isBuddy = connectedBuddiesIds.includes(user.id);
                    return (
                      <div
                        key={user.id}
                        className="bg-[#1A1A1A] border border-white/10 rounded-3xl p-5 shadow-lg flex flex-col justify-between hover:border-white/20 transition-all group"
                        id={`discover-card-${user.id}`}
                      >
                        {/* Card top banner */}
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex items-center gap-3">
                            <AvatarHelper avatarId={user.profilePic} size="md" showStatus isOnline={true} />
                            <div className="text-left">
                              <h4 className="text-sm font-black text-white leading-tight flex items-center gap-1.5">
                                {user.name}
                                <span className="text-white/40 font-medium text-xs">({user.age})</span>
                              </h4>
                              <p className="text-[10px] text-white/40 font-mono mt-0.5">📍 {user.locationName}</p>
                            </div>
                          </div>

                          {/* Match % pill */}
                          <div className="bg-[#E53935]/10 border border-[#E53935]/20 text-[#E53935] px-2.5 py-1 rounded-xl text-[10px] font-black font-mono flex items-center gap-0.5 shadow-sm">
                            <Sparkles className="w-3 h-3 fill-[#E53935]" />
                            {user.compatibilityScore}% Match
                          </div>
                        </div>

                        {/* Bio / Description */}
                        <p className="text-xs text-white/60 line-clamp-3 text-left mb-4 min-h-[48px] italic leading-relaxed">
                          "{user.bio}"
                        </p>

                        {/* Highlights Grid */}
                        <div className="bg-white/5 rounded-2xl p-3 border border-white/5 text-left space-y-2 mb-4">
                          <div className="flex justify-between text-[10px]">
                            <span className="text-white/40 font-bold uppercase">Experience</span>
                            <span className="text-rose-400 font-bold font-mono">{user.fitnessLevel}</span>
                          </div>
                          <div className="flex justify-between text-[10px]">
                            <span className="text-white/40 font-bold uppercase">Workout Goal</span>
                            <span className="text-white font-semibold">{user.primaryGoal}</span>
                          </div>
                          <div className="flex justify-between text-[10px]">
                            <span className="text-white/40 font-bold uppercase">Travel Dist</span>
                            <span className="text-white font-semibold font-mono">{user.distanceMiles.toFixed(1)} miles</span>
                          </div>
                          <div className="flex justify-between text-[10px]">
                            <span className="text-white/40 font-bold uppercase">Gym Location</span>
                            <span className="text-white/60 font-semibold max-w-[130px] truncate">{user.favoriteGym}</span>
                          </div>
                        </div>

                        {/* Activities list */}
                        <div className="flex flex-wrap gap-1.5 mb-5 justify-start">
                          {user.activities.slice(0, 3).map(act => (
                            <span key={act} className="px-2 py-0.5 rounded-lg bg-[#0A0A0A] border border-white/5 text-[10px] text-white/55">
                              {act}
                            </span>
                          ))}
                          {user.activities.length > 3 && (
                            <span className="px-2 py-0.5 rounded-lg bg-[#E53935]/15 text-[10px] text-[#E53935] font-mono font-bold">
                              +{user.activities.length - 3}
                            </span>
                          )}
                        </div>

                        {/* Action connect buttons */}
                        <div className="pt-3 border-t border-white/5 flex items-center justify-between">
                          <span className="text-[9px] text-white/40 font-mono font-semibold">{user.lastActive}</span>
                          {isBuddy ? (
                            <span className="px-4 py-2 rounded-xl bg-[#0A0A0A] border border-white/5 text-xs text-emerald-500 font-black tracking-tight flex items-center gap-1">
                              <span>Connected</span>
                              <Check className="w-3.5 h-3.5" />
                            </span>
                          ) : (
                            <button
                              onClick={() => onConnect(user.id)}
                              className="px-4 py-2 bg-[#E53935] hover:bg-[#D32F2F] text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-1 active:scale-95 shadow-[#E53935]/10"
                            >
                              Connect
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-[#1A1A1A] border border-white/10 rounded-[32px] p-12 text-center min-h-[350px] flex flex-col items-center justify-center shadow-lg">
                  <div className="w-12 h-12 bg-[#E53935]/10 rounded-full flex items-center justify-center border border-[#E53935]/20 mb-4">
                    <Filter className="text-[#E53935] w-6 h-6" />
                  </div>
                  <h4 className="text-lg font-bold text-white">No results fit your filters</h4>
                  <p className="text-xs text-white/40 mt-1 max-w-sm">Try widening your travel distance, age range limits, or selecting "All Activities".</p>
                  <button
                    onClick={handleResetFilters}
                    className="mt-4 px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-xs font-bold text-white hover:bg-white/10"
                  >
                    Reset Filters
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Interactive Map View */
            <div className="w-full h-[650px] bg-[#1A1A1A] border border-white/10 rounded-[32px] overflow-hidden shadow-2xl relative">
              <MapView 
                currentUser={currentUser} 
                nearbyUsers={filteredUsers} 
                onConnect={onConnect}
                connectedBuddiesIds={connectedBuddiesIds}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
