/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User } from '../types';
import { AvatarHelper, SkillBadge } from './AvatarHelper';
import { MapPin, Navigation, Sparkles, Plus, Check } from 'lucide-react';

interface MapViewProps {
  currentUser: User;
  nearbyUsers: (User & { compatibilityScore: number; distanceMiles: number })[];
  onConnect: (userId: string) => void;
  connectedBuddiesIds: string[];
}

export const MapView: React.FC<MapViewProps> = ({
  currentUser,
  nearbyUsers,
  onConnect,
  connectedBuddiesIds
}) => {
  const [selectedUser, setSelectedUser] = useState<(User & { compatibilityScore: number; distanceMiles: number }) | null>(null);

  // Scale coordinates (0-100) to fit a centered map view
  // Let's place currentUser exactly at the center (50, 50) on our SVG canvas
  const getRelativePosition = (x: number, y: number) => {
    // Current user coordinate offset
    const dx = x - currentUser.coordinates.x;
    const dy = y - currentUser.coordinates.y;

    // Scale so that 40 coordinate units = 85% of map radius
    // Centered at 50%
    const posX = 50 + dx * 1.5;
    const posY = 50 + dy * 1.5;

    return { x: posX, y: posY };
  };

  return (
    <div className="relative w-full h-full bg-zinc-950 flex items-center justify-center overflow-hidden" id="map-canvas-container">
      {/* Grid Pattern Background */}
      <div className="absolute inset-0 opacity-5 bg-[linear-gradient(to_right,#808080_1px,transparent_1px),linear-gradient(to_bottom,#808080_1px,transparent_1px)] bg-[size:40px_40px]" />

      {/* SVG Map Graphics */}
      <svg className="absolute w-full h-full pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
        {/* Radar Concentric Rings */}
        <circle cx="50" cy="50" r="10" fill="none" stroke="#e53935" strokeWidth="0.15" strokeDasharray="1 1" className="animate-[pulse_4s_infinite]" />
        <circle cx="50" cy="50" r="22" fill="none" stroke="#ffffff" strokeWidth="0.08" opacity="0.1" />
        <circle cx="50" cy="50" r="38" fill="none" stroke="#ffffff" strokeWidth="0.08" opacity="0.1" />
        <circle cx="50" cy="50" r="48" fill="none" stroke="#ffffff" strokeWidth="0.08" opacity="0.05" />

        {/* Crosshair guidelines */}
        <line x1="50" y1="2" x2="50" y2="98" stroke="#ffffff" strokeWidth="0.04" opacity="0.08" />
        <line x1="2" y1="50" x2="98" y2="50" stroke="#ffffff" strokeWidth="0.04" opacity="0.08" />

        {/* Range text markers */}
        <text x="50.5" y="74" fill="#ffffff" fontSize="1.2" opacity="0.3" fontFamily="monospace">15 MILE BOUNDARY</text>
        <text x="50.5" y="90" fill="#ffffff" fontSize="1.2" opacity="0.3" fontFamily="monospace">35 MILE BOUNDARY</text>
      </svg>

      {/* Compass / Location Info Indicator */}
      <div className="absolute bottom-4 left-4 bg-zinc-900/90 border border-zinc-850 p-3 rounded-2xl text-left shadow-lg pointer-events-none select-none z-10">
        <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider leading-none">Map Center</p>
        <p className="text-xs font-bold text-white mt-1 flex items-center gap-1.5">
          <Navigation className="w-3.5 h-3.5 text-red-500 fill-red-500 animate-pulse" />
          <span>{currentUser.locationName} (You)</span>
        </p>
      </div>

      {/* Legend */}
      <div className="absolute top-4 left-4 bg-zinc-900/90 border border-zinc-850 px-3 py-2 rounded-2xl flex items-center gap-4 text-[10px] text-zinc-400 font-medium tracking-wide z-10 shadow-md">
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-600 border border-red-500 animate-ping" />
          <span>You</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
          <span>Active Partner</span>
        </div>
      </div>

      {/* PLOT USER PINS */}
      {/* 1. Plot currentUser (always in center 50%, 50%) */}
      <div
        className="absolute w-12 h-12 flex items-center justify-center z-20"
        style={{ left: 'calc(50% - 24px)', top: 'calc(50% - 24px)' }}
      >
        <div className="absolute w-12 h-12 rounded-full bg-red-600/20 border border-red-500 animate-ping" />
        <AvatarHelper avatarId={currentUser.profilePic} size="sm" className="ring-2 ring-red-600 shadow-xl" />
      </div>

      {/* 2. Plot nearbyUsers pins */}
      {nearbyUsers.map((user) => {
        const { x, y } = getRelativePosition(user.coordinates.x, user.coordinates.y);
        const isSelected = selectedUser?.id === user.id;

        return (
          <button
            key={user.id}
            onClick={() => setSelectedUser(user)}
            className="absolute transition-all duration-300 hover:scale-125 z-10"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              transform: 'translate(-50%, -50%)',
            }}
            id={`map-pin-${user.id}`}
          >
            {/* Pulsing ring for matching score >= 85 */}
            {user.compatibilityScore >= 85 && (
              <div className="absolute inset-0 w-11 h-11 bg-red-500/10 rounded-full border border-red-500/30 animate-pulse" style={{ transform: 'translate(-3px, -3px)' }} />
            )}

            <div className={`p-1 rounded-full border transition-all shadow-lg ${
              isSelected 
                ? 'border-red-500 bg-red-600 scale-110 z-30 ring-4 ring-red-600/30' 
                : 'border-zinc-800 bg-zinc-900'
            }`}>
              <AvatarHelper avatarId={user.profilePic} size="sm" showStatus={false} />
            </div>

            {/* Glowing Tag above pin */}
            <span className="absolute -bottom-6 left-1/2 -translate-x-1/2 bg-zinc-900/90 text-white font-mono font-bold text-[8px] px-1.5 py-0.5 border border-zinc-800 rounded-md whitespace-nowrap shadow-sm">
              {user.name.split(' ')[0]} • {user.compatibilityScore}%
            </span>
          </button>
        );
      })}

      {/* SLIDE-UP PROFILE PREVIEW POPUP */}
      {selectedUser && (
        <div 
          className="absolute bottom-4 left-4 right-4 bg-zinc-900 border border-zinc-850 p-4 rounded-3xl text-left shadow-2xl z-40 animate-[slideUp_0.3s_ease-out] flex flex-col sm:flex-row items-center sm:items-stretch justify-between gap-4"
          id="map-preview-popup"
        >
          <div className="flex items-center gap-4">
            <AvatarHelper avatarId={selectedUser.profilePic} size="lg" showStatus isOnline={true} />
            <div className="text-left space-y-1">
              <div className="flex items-center gap-2">
                <h4 className="text-md font-black text-white">{selectedUser.name}, {selectedUser.age}</h4>
                <SkillBadge level={selectedUser.fitnessLevel} />
              </div>
              <p className="text-xs text-zinc-400 font-medium">📍 {selectedUser.favoriteGym}</p>
              <p className="text-xs text-zinc-500 leading-snug max-w-md line-clamp-1 italic">
                "{selectedUser.bio}"
              </p>
              {/* Distance and overlap tags */}
              <div className="flex items-center gap-2 pt-1">
                <span className="px-2 py-0.5 rounded-lg bg-zinc-950 border border-zinc-850 text-[10px] text-zinc-500 font-mono">
                  {selectedUser.distanceMiles.toFixed(1)} miles away
                </span>
                <span className="px-2 py-0.5 rounded-lg bg-red-600/10 text-[10px] text-red-400 font-mono font-bold">
                  {selectedUser.compatibilityScore}% Match
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-row sm:flex-col justify-center items-stretch gap-2 w-full sm:w-auto">
            <button
              onClick={() => setSelectedUser(null)}
              className="px-4 py-2.5 rounded-xl border border-zinc-800 bg-zinc-950 text-xs font-bold text-zinc-400 hover:text-white transition-all w-1/2 sm:w-28 text-center"
            >
              Close
            </button>
            {connectedBuddiesIds.includes(selectedUser.id) ? (
              <span className="px-4 py-2.5 rounded-xl bg-zinc-950 border border-zinc-800 text-xs text-emerald-500 font-black text-center flex items-center justify-center gap-1.5 w-1/2 sm:w-28">
                <Check className="w-3.5 h-3.5" />
                <span>Active</span>
              </span>
            ) : (
              <button
                onClick={() => {
                  onConnect(selectedUser.id);
                  // Refresh status
                }}
                className="px-4 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5 w-1/2 sm:w-28 animate-pulse"
              >
                <Plus className="w-4 h-4" />
                <span>Connect</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
