/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User } from '../types';
import { AvatarHelper } from './AvatarHelper';
import { Settings as SettingsIcon, Bell, Shield, Moon, Eye, UserX, LogOut, Check, Save } from 'lucide-react';

interface SettingsProps {
  currentUser: User;
  onUpdateProfile: (updatedFields: Partial<User>) => void;
  onDeleteAccount: () => void;
  onLogout: () => void;
  blockedUsersIds: string[];
  allUsers: User[];
  onUnblockUser: (userId: string) => void;
}

export const Settings: React.FC<SettingsProps> = ({
  currentUser,
  onUpdateProfile,
  onDeleteAccount,
  onLogout,
  blockedUsersIds,
  allUsers,
  onUnblockUser
}) => {
  // Profile Editor state
  const [name, setName] = useState(currentUser.name);
  const [bio, setBio] = useState(currentUser.bio);
  const [gym, setGym] = useState(currentUser.favoriteGym);
  const [city, setCity] = useState(currentUser.locationName);
  const [age, setAge] = useState(currentUser.age);
  const [selectedAvatar, setSelectedAvatar] = useState(currentUser.profilePic);

  // Notification toggles state
  const [notifMatches, setNotifMatches] = useState(true);
  const [notifMessages, setNotifMessages] = useState(true);
  const [notifInvites, setNotifInvites] = useState(true);

  // Privacy toggles state
  const [hideOnMap, setHideOnMap] = useState(false);
  const [onlySameLevel, setOnlySameLevel] = useState(false);

  const [saveSuccess, setSaveSuccess] = useState(false);

  const avatarOptions = [
    'avatar_vikram', 'avatar_sarah', 'avatar_mark', 'avatar_elena', 
    'avatar_carlos', 'avatar_jessica', 'avatar_david', 'avatar_charlie', 'avatar_user'
  ];

  const handleSaveProfile = () => {
    onUpdateProfile({
      name,
      bio,
      favoriteGym: gym,
      locationName: city,
      age,
      profilePic: selectedAvatar
    });
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const blockedUsers = allUsers.filter(u => blockedUsersIds.includes(u.id));

  return (
    <div className="max-w-4xl mx-auto py-8 px-4 text-left space-y-8 animate-[fadeIn_0.3s_ease]" id="settings-root">
      <div>
        <h2 className="text-2xl font-black text-white tracking-tight uppercase flex items-center gap-2">
          <SettingsIcon className="text-red-500 w-6 h-6" />
          <span>Profile & App Settings</span>
        </h2>
        <p className="text-xs text-zinc-500 mt-1">Configure your personal fitness statistics, notification schedules, and account preferences.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        
        {/* Left column: Profile Editor (8 Columns) */}
        <div className="md:col-span-8 bg-zinc-900 border border-zinc-850 rounded-[32px] p-6 shadow-md space-y-6">
          <div className="border-b border-zinc-850 pb-3 mb-2 flex items-center gap-1.5">
            <SettingsIcon className="text-red-500 w-4.5 h-4.5" />
            <h3 className="font-extrabold text-sm text-white uppercase tracking-wider">Edit Profile Stats</h3>
          </div>

          <div className="space-y-4 text-xs">
            {/* Avatar Selector */}
            <div>
              <label className="block text-zinc-400 font-bold uppercase mb-2">Change Avatar Style</label>
              <div className="flex flex-wrap gap-2.5 justify-start py-2.5 bg-zinc-950/40 rounded-2xl border border-zinc-850/80 p-3">
                {avatarOptions.map((avId) => (
                  <button
                    key={avId}
                    type="button"
                    onClick={() => setSelectedAvatar(avId)}
                    className={`p-0.5 rounded-full border transition-all ${
                      selectedAvatar === avId ? 'border-red-600 scale-105 shadow-md' : 'border-transparent opacity-60 hover:opacity-100'
                    }`}
                  >
                    <AvatarHelper avatarId={avId} size="sm" />
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Display Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Age</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(parseInt(e.target.value) || 18)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Home Gym</label>
                <input
                  type="text"
                  value={gym}
                  onChange={(e) => setGym(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-zinc-400 font-bold uppercase mb-1.5">Home City</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-zinc-400 font-bold uppercase mb-1.5">Bio Overview</label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3 py-2 text-white focus:outline-none resize-none"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              {saveSuccess ? (
                <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                  <Check className="w-4 h-4" />
                  Profile updated successfully!
                </span>
              ) : <div />}

              <button
                onClick={handleSaveProfile}
                className="px-6 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl transition-all shadow-md flex items-center gap-1.5 active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>Save Changes</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right column: System preferences (4 Columns) */}
        <div className="md:col-span-4 space-y-6">
          
          {/* Notification toggles */}
          <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-[32px] text-left shadow-sm space-y-4">
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-1.5 border-b border-zinc-850 pb-2 mb-1">
              <Bell className="text-red-500 w-4.5 h-4.5" />
              <span>Notifications</span>
            </h3>

            <div className="space-y-3 text-xs">
              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={notifMatches}
                  onChange={(e) => setNotifMatches(e.target.checked)}
                  className="rounded bg-zinc-950 border-zinc-800 text-red-500 focus:ring-0 w-4 h-4"
                />
                <span>Someone connects</span>
              </label>

              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={notifMessages}
                  onChange={(e) => setNotifMessages(e.target.checked)}
                  className="rounded bg-zinc-950 border-zinc-800 text-red-500 focus:ring-0 w-4 h-4"
                />
                <span>New chat messages</span>
              </label>

              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={notifInvites}
                  onChange={(e) => setNotifInvites(e.target.checked)}
                  className="rounded bg-zinc-950 border-zinc-800 text-red-500 focus:ring-0 w-4 h-4"
                />
                <span>Workout invitations</span>
              </label>
            </div>
          </div>

          {/* Privacy preferences */}
          <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-[32px] text-left shadow-sm space-y-4">
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-1.5 border-b border-zinc-850 pb-2 mb-1">
              <Shield className="text-red-500 w-4.5 h-4.5" />
              <span>Privacy</span>
            </h3>

            <div className="space-y-3 text-xs">
              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={hideOnMap}
                  onChange={(e) => setHideOnMap(e.target.checked)}
                  className="rounded bg-zinc-950 border-zinc-800 text-red-500 focus:ring-0 w-4 h-4"
                />
                <span>Hide on radar maps</span>
              </label>

              <label className="flex items-center gap-2.5 text-zinc-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={onlySameLevel}
                  onChange={(e) => setOnlySameLevel(e.target.checked)}
                  className="rounded bg-zinc-950 border-zinc-800 text-red-500 focus:ring-0 w-4 h-4"
                />
                <span>Only same skill match</span>
              </label>

              {/* Dark mode display item */}
              <div className="flex items-center justify-between text-zinc-500 font-medium pt-2 border-t border-zinc-850/60">
                <span className="flex items-center gap-1.5">
                  <Moon className="w-4 h-4" />
                  Dark Mode
                </span>
                <span className="text-[10px] bg-red-600/10 border border-red-500/20 text-red-500 px-2 py-0.5 rounded-lg font-mono font-bold">
                  DEFAULT ON
                </span>
              </div>
            </div>
          </div>

          {/* Blocked Accounts list */}
          <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-[32px] text-left shadow-sm space-y-3">
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider flex items-center gap-1.5 border-b border-zinc-850 pb-2">
              <UserX className="text-red-500 w-4.5 h-4.5" />
              <span>Blocked Users</span>
            </h3>

            {blockedUsers.length > 0 ? (
              <div className="space-y-2 text-xs max-h-[110px] overflow-y-auto pr-1">
                {blockedUsers.map((b) => (
                  <div key={b.id} className="flex items-center justify-between bg-zinc-950 p-2 rounded-xl border border-zinc-850/40">
                    <span className="font-bold text-white truncate max-w-[100px]">{b.name}</span>
                    <button
                      onClick={() => onUnblockUser(b.id)}
                      className="text-[10px] font-bold text-red-500 hover:text-red-400 font-mono"
                    >
                      Unblock
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-[10px] text-zinc-500 italic">No blocked accounts found.</p>
            )}
          </div>

          {/* Logout & Deletion actions */}
          <div className="bg-zinc-900 border border-zinc-850 p-6 rounded-[32px] text-left shadow-sm space-y-2.5">
            <button
              onClick={onLogout}
              className="w-full py-2.5 bg-zinc-950 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-850 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-sm active:scale-98"
            >
              <LogOut className="w-4 h-4 text-zinc-500" />
              <span>Log out</span>
            </button>
            <button
              onClick={onDeleteAccount}
              className="w-full py-2.5 bg-red-600/10 hover:bg-red-600 text-red-500 hover:text-white border border-red-900/30 text-xs font-bold rounded-xl transition-all shadow-sm active:scale-98"
            >
              Delete Account
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};
