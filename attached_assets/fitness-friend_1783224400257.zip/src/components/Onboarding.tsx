/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, FitnessLevel, PrimaryGoal, ActivityType, AvailabilityDay, PreferredTime, FrequencyType, GenderType } from '../types';
import { AvatarHelper } from './AvatarHelper';
import { Activity, Dumbbell, Calendar, Target, Users, MapPin } from 'lucide-react';

interface OnboardingProps {
  onComplete: (user: User) => void;
}

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [age, setAge] = useState(24);
  const [gender, setGender] = useState<GenderType>('Prefer not to say');
  const [profilePic, setProfilePic] = useState('avatar_user');
  const [bio, setBio] = useState('');
  const [locationName, setLocationName] = useState('Seattle, WA');
  const [fitnessLevel, setFitnessLevel] = useState<FitnessLevel>('Intermediate');
  const [primaryGoal, setPrimaryGoal] = useState<PrimaryGoal>('General fitness');
  const [selectedActivities, setSelectedActivities] = useState<ActivityType[]>(['Gym']);
  const [availability, setAvailability] = useState<AvailabilityDay>('Both');
  const [preferredTimes, setPreferredTimes] = useState<PreferredTime[]>(['Evening']);
  const [maxTravelDistance, setMaxTravelDistance] = useState(15);
  const [preferredFrequency, setPreferredFrequency] = useState<FrequencyType>('3x/week');
  const [genderPreference, setGenderPreference] = useState<'Male' | 'Female' | 'No preference'>('No preference');
  const [ageRangeMin, setAgeRangeMin] = useState(20);
  const [ageRangeMax, setAgeRangeMax] = useState(35);
  const [skillRangeMin, setSkillRangeMin] = useState<FitnessLevel>('Beginner');
  const [skillRangeMax, setSkillRangeMax] = useState<FitnessLevel>('Advanced');

  const avatarOptions = [
    'avatar_vikram', 'avatar_sarah', 'avatar_mark', 'avatar_elena', 
    'avatar_carlos', 'avatar_jessica', 'avatar_david', 'avatar_charlie', 'avatar_user'
  ];

  const goalsList: PrimaryGoal[] = [
    'Lose weight', 'Build muscle', 'Strength', 'Endurance', 'Sports', 'General fitness'
  ];

  const activitiesList: ActivityType[] = [
    'Gym', 'Running', 'Basketball', 'Soccer', 'Tennis', 'Hiking', 
    'Pickleball', 'Cycling', 'Swimming', 'Yoga', 'Boxing', 'Climbing'
  ];

  const timesList: PreferredTime[] = ['Morning', 'Afternoon', 'Evening', 'Night'];

  const frequencyOptions: FrequencyType[] = [
    'Daily', '2x/week', '3x/week', '4x/week', 'Flexible'
  ];

  const levels: FitnessLevel[] = ['Beginner', 'Intermediate', 'Advanced'];

  const toggleActivity = (activity: ActivityType) => {
    if (selectedActivities.includes(activity)) {
      setSelectedActivities(selectedActivities.filter(a => a !== activity));
    } else {
      setSelectedActivities([...selectedActivities, activity]);
    }
  };

  const toggleTime = (time: PreferredTime) => {
    if (preferredTimes.includes(time)) {
      setPreferredTimes(preferredTimes.filter(t => t !== time));
    } else {
      setPreferredTimes([...preferredTimes, time]);
    }
  };

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      const newUser: User = {
        id: 'user_current_' + Date.now(),
        name: name || 'Fitness Friend',
        age: Number(age) || 24,
        gender,
        profilePic,
        bio: bio || 'Let\'s get fit together!',
        locationName: locationName || 'Seattle, WA',
        coordinates: { x: 45, y: 50 }, // Rooted coordinates
        fitnessLevel,
        primaryGoal,
        activities: selectedActivities.length > 0 ? selectedActivities : ['Gym'],
        availability,
        preferredTime: preferredTimes.length > 0 ? preferredTimes : ['Evening'],
        maxTravelDistance,
        preferredFrequency,
        preferences: {
          genderPreference,
          ageRangeMin,
          ageRangeMax,
          skillRangeMin,
          skillRangeMax
        },
        achievements: ['New Member ⚡', 'Profile Complete Matchmaker'],
        favoriteGym: 'Any convenient fitness center',
        lastActive: 'Active now'
      };
      onComplete(newUser);
    }
  };

  const handlePrev = () => {
    if (step > 1) {
      setStep(step - 1);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-[85vh] py-12 px-4" id="onboarding-root">
      <div className="w-full max-w-xl bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        {/* Glow effect */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-red-600/5 rounded-full blur-3xl pointer-events-none" />

        {/* Steps header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-red-600 flex items-center justify-center text-white font-bold text-sm">
              {step}
            </span>
            <h2 className="text-xl font-bold tracking-tight text-white">
              {step === 1 && 'Basic Information'}
              {step === 2 && 'Your Fitness Persona'}
              {step === 3 && 'Logistics & Availability'}
              {step === 4 && 'Your Ideal Partner'}
            </h2>
          </div>
          <span className="text-sm font-mono text-zinc-500">
            Step {step} of 4
          </span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-zinc-800 h-1.5 rounded-full mb-8 overflow-hidden">
          <div 
            className="bg-red-600 h-full transition-all duration-300 rounded-full"
            style={{ width: `${(step / 4) * 100}%` }}
          />
        </div>

        {/* Form Steps */}
        <div className="min-h-[380px] flex flex-col justify-between">
          <div>
            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-2">Select Your Avatar Style</label>
                  <div className="flex flex-wrap gap-3 justify-center py-2 bg-zinc-950/40 rounded-2xl border border-zinc-800/50 p-4">
                    {avatarOptions.map((avId) => (
                      <button
                        key={avId}
                        type="button"
                        onClick={() => setProfilePic(avId)}
                        className={`p-1 rounded-full border-2 transition-all ${
                          profilePic === avId ? 'border-red-600 scale-110 shadow-lg' : 'border-transparent opacity-70 hover:opacity-100'
                        }`}
                      >
                        <AvatarHelper avatarId={avId} size="sm" />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Display Name</label>
                    <input
                      type="text"
                      placeholder="Vikram"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Age</label>
                    <input
                      type="number"
                      min="18"
                      max="100"
                      value={age}
                      onChange={(e) => setAge(Math.max(18, parseInt(e.target.value) || 18))}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Gender</label>
                    <select
                      value={gender}
                      onChange={(e) => setGender(e.target.value as GenderType)}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm appearance-none cursor-pointer"
                    >
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Non-binary">Non-binary</option>
                      <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Home City</label>
                    <div className="relative">
                      <input
                        type="text"
                        value={locationName}
                        onChange={(e) => setLocationName(e.target.value)}
                        placeholder="e.g. Seattle, WA"
                        className="w-full bg-zinc-950 border border-zinc-850 rounded-xl pl-10 pr-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm"
                      />
                      <MapPin className="absolute left-3 top-3.5 text-zinc-500 w-4.5 h-4.5" />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-2">Short Bio</label>
                  <textarea
                    rows={3}
                    placeholder="Tell local fitness partners a bit about your workouts, favorite gyms, or routines..."
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm resize-none"
                  />
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Fitness Experience</label>
                    <div className="flex flex-col gap-2">
                      {levels.map((lvl) => (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => setFitnessLevel(lvl)}
                          className={`flex items-center justify-between px-4 py-3 rounded-xl border text-sm transition-all ${
                            fitnessLevel === lvl 
                              ? 'border-red-600 bg-red-600/5 text-white font-medium' 
                              : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          <span>{lvl}</span>
                          <Dumbbell className={`w-4 h-4 ${fitnessLevel === lvl ? 'text-red-500' : 'text-zinc-600'}`} />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Primary Goal</label>
                    <div className="flex flex-col gap-2 max-h-[190px] overflow-y-auto pr-1">
                      {goalsList.map((g) => (
                        <button
                          key={g}
                          type="button"
                          onClick={() => setPrimaryGoal(g)}
                          className={`flex items-center justify-between px-4 py-2.5 rounded-xl border text-xs transition-all ${
                            primaryGoal === g 
                              ? 'border-red-600 bg-red-600/5 text-white font-medium' 
                              : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:text-zinc-200'
                          }`}
                        >
                          <span>{g}</span>
                          <Target className={`w-3.5 h-3.5 ${primaryGoal === g ? 'text-red-500' : 'text-zinc-600'}`} />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-2">Preferred Activities (Choose Multiple)</label>
                  <div className="flex flex-wrap gap-2 max-h-[120px] overflow-y-auto p-1 bg-zinc-950/40 border border-zinc-850 rounded-2xl">
                    {activitiesList.map((act) => {
                      const isSelected = selectedActivities.includes(act);
                      return (
                        <button
                          key={act}
                          type="button"
                          onClick={() => toggleActivity(act)}
                          className={`px-3 py-1.5 rounded-xl border text-xs flex items-center gap-1.5 transition-all ${
                            isSelected 
                              ? 'border-red-600 bg-red-600/10 text-white font-medium' 
                              : 'border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-300'
                          }`}
                        >
                          <Activity className="w-3.5 h-3.5" />
                          {act}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Weekly Availability</label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['Weekdays', 'Weekends', 'Both'] as AvailabilityDay[]).map((av) => (
                        <button
                          key={av}
                          type="button"
                          onClick={() => setAvailability(av)}
                          className={`px-3 py-3 rounded-xl border text-xs font-medium text-center transition-all ${
                            availability === av 
                              ? 'border-red-600 bg-red-600/10 text-white' 
                              : 'border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-300'
                          }`}
                        >
                          {av}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Preferred Frequency</label>
                    <select
                      value={preferredFrequency}
                      onChange={(e) => setPreferredFrequency(e.target.value as FrequencyType)}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-sm appearance-none cursor-pointer"
                    >
                      {frequencyOptions.map((freq) => (
                        <option key={freq} value={freq}>{freq}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-2">Time of Day Overlaps</label>
                  <div className="grid grid-cols-4 gap-2">
                    {timesList.map((t) => {
                      const isSelected = preferredTimes.includes(t);
                      return (
                        <button
                          key={t}
                          type="button"
                          onClick={() => toggleTime(t)}
                          className={`py-3 rounded-xl border text-xs font-medium flex flex-col items-center gap-1 transition-all ${
                            isSelected 
                              ? 'border-red-600 bg-red-600/10 text-white' 
                              : 'border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-300'
                          }`}
                        >
                          <Calendar className="w-4 h-4 text-zinc-500" />
                          {t}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-zinc-400">Maximum Travel Distance</label>
                    <span className="text-sm font-mono text-red-500 font-bold">{maxTravelDistance} miles</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="50"
                    value={maxTravelDistance}
                    onChange={(e) => setMaxTravelDistance(parseInt(e.target.value))}
                    className="w-full accent-red-600 h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-xs text-zinc-600 font-mono mt-1">
                    <span>1 mi</span>
                    <span>25 mi</span>
                    <span>50 mi</span>
                  </div>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-zinc-400 mb-2">Workout Partner Gender Preference</label>
                  <div className="grid grid-cols-3 gap-2">
                    {(['Male', 'Female', 'No preference'] as const).map((pref) => (
                      <button
                        key={pref}
                        type="button"
                        onClick={() => setGenderPreference(pref)}
                        className={`py-3 rounded-xl border text-xs font-medium text-center transition-all ${
                          genderPreference === pref 
                            ? 'border-red-600 bg-red-600/10 text-white' 
                            : 'border-zinc-800 bg-zinc-950 text-zinc-500 hover:text-zinc-300'
                        }`}
                      >
                        {pref}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="text-sm font-medium text-zinc-400">Target Partner Age Range</label>
                    <span className="text-sm font-mono text-red-500 font-bold">{ageRangeMin} - {ageRangeMax} years</span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <span className="text-xs text-zinc-600 font-mono block mb-1">Min Age</span>
                      <input
                        type="range"
                        min="18"
                        max="60"
                        value={ageRangeMin}
                        onChange={(e) => setAgeRangeMin(Math.min(parseInt(e.target.value), ageRangeMax))}
                        className="w-full accent-red-600 h-1 bg-zinc-850 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                    <div>
                      <span className="text-xs text-zinc-600 font-mono block mb-1">Max Age</span>
                      <input
                        type="range"
                        min="18"
                        max="60"
                        value={ageRangeMax}
                        onChange={(e) => setAgeRangeMax(Math.max(parseInt(e.target.value), ageRangeMin))}
                        className="w-full accent-red-600 h-1 bg-zinc-850 rounded-lg appearance-none cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Min Experience Level</label>
                    <select
                      value={skillRangeMin}
                      onChange={(e) => setSkillRangeMin(e.target.value as FitnessLevel)}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-xs"
                    >
                      {levels.map((lvl) => (
                        <option key={lvl} value={lvl}>{lvl}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-zinc-400 mb-2">Max Experience Level</label>
                    <select
                      value={skillRangeMax}
                      onChange={(e) => setSkillRangeMax(e.target.value as FitnessLevel)}
                      className="w-full bg-zinc-950 border border-zinc-850 rounded-xl px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-red-600/50 transition-all text-xs"
                    >
                      {levels.map((lvl) => (
                        <option key={lvl} value={lvl}>{lvl}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="flex items-center gap-2 p-3 bg-red-600/5 border border-red-900/30 rounded-xl">
                  <Users className="w-5 h-5 text-red-500 flex-shrink-0" />
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    Fitness Friend matches you on schedule, workouts, and gyms first to ensure high-quality, safe collaborations.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between mt-8 pt-6 border-t border-zinc-800/60">
            {step > 1 ? (
              <button
                type="button"
                onClick={handlePrev}
                className="px-6 py-2.5 rounded-xl text-sm font-medium text-zinc-400 hover:text-white transition-all bg-zinc-850 hover:bg-zinc-800"
              >
                Back
              </button>
            ) : (
              <div /> // spacing placeholder
            )}

            <button
              type="button"
              onClick={handleNext}
              disabled={step === 1 && !name.trim()}
              className={`px-8 py-2.5 rounded-xl text-sm font-semibold text-white tracking-tight flex items-center justify-center transition-all bg-red-600 hover:bg-red-700 shadow-lg ${
                step === 1 && !name.trim() ? 'opacity-50 cursor-not-allowed' : ''
              }`}
            >
              {step === 4 ? 'Complete Profile' : 'Continue'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
