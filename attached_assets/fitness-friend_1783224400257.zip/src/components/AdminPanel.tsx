/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { User, Report } from '../types';
import { AvatarHelper } from './AvatarHelper';
import { Users, BarChart2, MessageSquare, ShieldAlert, Check, Ban, Sparkles, Smile } from 'lucide-react';

interface AdminPanelProps {
  allUsers: User[];
  reports: Report[];
  onBanUser: (userId: string) => void;
  onDismissReport: (reportId: string) => void;
  onUnbanUser: (userId: string) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  allUsers,
  reports,
  onBanUser,
  onDismissReport,
  onUnbanUser
}) => {
  const activeReports = reports.filter(r => r.status === 'Pending');
  const bannedUsers = allUsers.filter(u => u.isBanned);

  // Dynamic analytic calculations
  const totalUsers = allUsers.length;
  const matchRatio = Math.round((allUsers.filter(u => u.fitnessLevel === 'Advanced').length / totalUsers) * 100);

  return (
    <div className="max-w-5xl mx-auto py-8 px-4 text-left space-y-8 animate-[fadeIn_0.3s_ease]" id="admin-dashboard">
      
      {/* Header and status info */}
      <div>
        <h2 className="text-2xl font-black text-white tracking-tight uppercase flex items-center gap-2">
          <ShieldAlert className="text-red-500 w-6 h-6 animate-pulse" />
          <span>Admin Moderation Console</span>
        </h2>
        <p className="text-xs text-zinc-500 mt-1">Review user flags, moderate abusive account registrations, and inspect platform activity logs.</p>
      </div>

      {/* Analytics Bento Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-3xl flex items-center gap-4 shadow-sm">
          <div className="w-11 h-11 rounded-2xl bg-red-600/10 flex items-center justify-center border border-red-500/20 text-red-500">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider block">Total Members</span>
            <p className="text-xl font-black text-white font-mono mt-1">{totalUsers}</p>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-3xl flex items-center gap-4 shadow-sm">
          <div className="w-11 h-11 rounded-2xl bg-emerald-600/10 flex items-center justify-center border border-emerald-500/20 text-emerald-500">
            <Smile className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider block">Elite Athletes</span>
            <p className="text-xl font-black text-white font-mono mt-1">{matchRatio}%</p>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-3xl flex items-center gap-4 shadow-sm">
          <div className="w-11 h-11 rounded-2xl bg-amber-600/10 flex items-center justify-center border border-amber-500/20 text-amber-500">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider block">Active Reports</span>
            <p className="text-xl font-black text-white font-mono mt-1">{activeReports.length}</p>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-zinc-900 border border-zinc-850 p-5 rounded-3xl flex items-center gap-4 shadow-sm">
          <div className="w-11 h-11 rounded-2xl bg-blue-600/10 flex items-center justify-center border border-blue-500/20 text-blue-500">
            <BarChart2 className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider block">Banned Accounts</span>
            <p className="text-xl font-black text-white font-mono mt-1">{bannedUsers.length}</p>
          </div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Active Flagged Reports List (8 Columns) */}
        <div className="lg:col-span-8 bg-zinc-900 border border-zinc-850 rounded-[32px] p-6 shadow-md space-y-4">
          <div className="border-b border-zinc-850 pb-3 mb-2 flex items-center gap-1.5">
            <ShieldAlert className="text-red-500 w-5 h-5" />
            <h3 className="font-extrabold text-sm text-white uppercase tracking-wider">Reported Accounts Queue</h3>
          </div>

          {activeReports.length > 0 ? (
            <div className="space-y-4">
              {activeReports.map((report) => {
                const reporter = allUsers.find(u => u.id === report.reporterId);
                const reported = allUsers.find(u => u.id === report.reportedUserId);
                if (!reported) return null;

                return (
                  <div
                    key={report.id}
                    className="bg-zinc-950/60 border border-zinc-850 p-5 rounded-2xl text-xs space-y-3"
                    id={`report-item-${report.id}`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-900 pb-3">
                      <div className="flex items-center gap-3">
                        <AvatarHelper avatarId={reported.profilePic} size="sm" />
                        <div>
                          <p className="font-bold text-white text-sm">{reported.name}</p>
                          <span className="text-[10px] text-zinc-500 font-mono block">Target User ID: {reported.id}</span>
                        </div>
                      </div>
                      <div className="text-left sm:text-right">
                        <span className="px-2.5 py-1 rounded-xl bg-red-600/15 border border-red-500/20 text-red-400 font-black tracking-tight text-[10px] uppercase">
                          {report.reason}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1 bg-zinc-900 p-3 rounded-xl border border-zinc-850 text-[11px] leading-relaxed">
                      <p className="text-zinc-500 font-bold uppercase text-[9px] mb-1">Details Flagged by {reporter?.name || 'Anonymous'}</p>
                      <p className="text-zinc-300 italic">"{report.details || 'No additional comment provided.'}"</p>
                    </div>

                    {/* Report action buttons */}
                    <div className="flex items-center justify-end gap-2 pt-2">
                      <button
                        onClick={() => onDismissReport(report.id)}
                        className="px-4 py-2 rounded-xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 text-zinc-400 hover:text-white transition-all text-xs font-bold flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4 text-emerald-500" />
                        Dismiss Flag
                      </button>
                      <button
                        onClick={() => onBanUser(report.reportedUserId)}
                        className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white transition-all text-xs font-bold flex items-center gap-1.5 shadow-md"
                      >
                        <Ban className="w-4 h-4" />
                        Ban Account
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-8 text-center text-zinc-500 text-xs italic">
              ✔ Beautiful! The flagged accounts queue is clean and empty.
            </div>
          )}
        </div>

        {/* Moderated Banned Users directory (4 Columns) */}
        <div className="lg:col-span-4 bg-zinc-900 border border-zinc-850 rounded-[32px] p-6 shadow-md text-left">
          <div className="border-b border-zinc-850 pb-3 mb-4 flex items-center gap-1.5">
            <Ban className="text-red-500 w-4.5 h-4.5" />
            <h3 className="font-extrabold text-xs text-white uppercase tracking-wider">Moderated Accounts</h3>
          </div>

          {bannedUsers.length > 0 ? (
            <div className="space-y-3">
              {bannedUsers.map((banned) => (
                <div key={banned.id} className="bg-zinc-950/60 border border-zinc-850 p-3 rounded-2xl flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <AvatarHelper avatarId={banned.profilePic} size="sm" className="opacity-60" />
                    <div>
                      <p className="font-bold text-white text-[11px] leading-tight truncate max-w-[120px]">{banned.name}</p>
                      <span className="text-[8px] text-zinc-500 font-mono block">Status: Banned</span>
                    </div>
                  </div>
                  <button
                    onClick={() => onUnbanUser(banned.id)}
                    className="px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white text-[10px] font-bold"
                  >
                    Unban
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="p-4 text-center text-zinc-500 text-xs italic">No restricted profiles currently exist.</p>
          )}
        </div>

      </div>
    </div>
  );
};
