/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type FitnessLevel = 'Beginner' | 'Intermediate' | 'Advanced';

export type PrimaryGoal = 
  | 'Lose weight'
  | 'Build muscle'
  | 'Strength'
  | 'Endurance'
  | 'Sports'
  | 'General fitness';

export type ActivityType =
  | 'Gym'
  | 'Running'
  | 'Basketball'
  | 'Soccer'
  | 'Tennis'
  | 'Hiking'
  | 'Pickleball'
  | 'Cycling'
  | 'Swimming'
  | 'Yoga'
  | 'Boxing'
  | 'Climbing';

export type AvailabilityDay = 'Weekdays' | 'Weekends' | 'Both';

export type PreferredTime = 'Morning' | 'Afternoon' | 'Evening' | 'Night';

export type FrequencyType =
  | 'Daily'
  | '2x/week'
  | '3x/week'
  | '4x/week'
  | 'Flexible';

export type GenderType = 'Male' | 'Female' | 'Non-binary' | 'Prefer not to say';

export interface UserPreferences {
  genderPreference: 'Male' | 'Female' | 'No preference';
  ageRangeMin: number;
  ageRangeMax: number;
  skillRangeMin: FitnessLevel;
  skillRangeMax: FitnessLevel;
}

export interface UserSchedule {
  weekdays: PreferredTime[];
  weekends: PreferredTime[];
}

export interface User {
  id: string;
  name: string;
  age: number;
  gender: GenderType;
  profilePic: string; // Avatar ID or SVG description
  bio: string;
  locationName: string; // e.g. "Seattle, WA"
  coordinates: { x: number; y: number }; // Simulated relative coordinates (0 to 100)
  fitnessLevel: FitnessLevel;
  primaryGoal: PrimaryGoal;
  activities: ActivityType[];
  availability: AvailabilityDay;
  preferredTime: PreferredTime[];
  maxTravelDistance: number; // in miles
  preferredFrequency: FrequencyType;
  preferences: UserPreferences;
  achievements: string[];
  favoriteGym: string;
  lastActive: string; // e.g., "Active 5m ago"
  isBanned?: boolean;
}

export type InviteStatus = 'Pending' | 'Accepted' | 'Declined' | 'Maybe';

export interface WorkoutInvite {
  id: string;
  senderId: string;
  receiverId: string;
  activity: ActivityType | string;
  location: string;
  date: string;
  time: string;
  status: InviteStatus;
  createdAt: string;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  imageUrl?: string;
  location?: { lat: number; lng: number; name: string };
  workoutInviteId?: string; // Reference to workout invitation
  createdAt: string;
  read: boolean;
}

export interface Chat {
  id: string;
  participantIds: string[];
  lastMessageText: string;
  lastMessageTime: string;
  isTyping?: { [userId: string]: boolean };
  unreadCount?: { [userId: string]: number };
}

export interface Match {
  id: string;
  userIds: string[]; // [user1, user2]
  createdAt: string;
  compatibilityScore: number;
}

export interface Report {
  id: string;
  reporterId: string;
  reportedUserId: string;
  reason: string;
  details: string;
  status: 'Pending' | 'Reviewed' | 'Banned' | 'Dismissed';
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  body: string;
  type: 'Match' | 'Message' | 'Invite' | 'System';
  relatedId?: string; // Chat ID or Invite ID or Match ID
  read: boolean;
  createdAt: string;
}

export interface Friend {
  id: string;
  userId: string; // logged-in user
  friendId: string; // friend user ID
  connectedAt: string;
}
