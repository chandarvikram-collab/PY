/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect, useMemo } from 'react';
import { User, Chat, Message, WorkoutInvite, Report, Notification, Match, InviteStatus, FitnessLevel, ActivityType } from './types';
import { 
  INITIAL_USERS, 
  INITIAL_CHATS, 
  INITIAL_MESSAGES, 
  INITIAL_NOTIFICATIONS, 
  calculateCompatibility 
} from './data';
import { Onboarding } from './components/Onboarding';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { Discover } from './components/Discover';
import { ChatView } from './components/ChatView';
import { FriendsView } from './components/FriendsView';
import { AdminPanel } from './components/AdminPanel';
import { Settings } from './components/Settings';
import { Dumbbell, ShieldAlert, Sparkles, LogIn, ChevronRight, UserPlus, Compass } from 'lucide-react';

export default function App() {
  // --- DATABASE STATES (Synced with LocalStorage) ---
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [workoutInvites, setWorkoutInvites] = useState<WorkoutInvite[]>([]);
  const [reports, setReports] = useState<Report[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [blockedUsersIds, setBlockedUsersIds] = useState<string[]>([]);
  const [connectedBuddiesIds, setConnectedBuddiesIds] = useState<string[]>([]);

  // --- NAVIGATION STATES ---
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [showToast, setShowToast] = useState<{ title: string; body: string } | null>(null);

  // --- INITIALIZATION ---
  useEffect(() => {
    // Load database collections from localStorage or fallback to defaults
    const storedUsers = localStorage.getItem('ff_users');
    const storedChats = localStorage.getItem('ff_chats');
    const storedMessages = localStorage.getItem('ff_messages');
    const storedInvites = localStorage.getItem('ff_invites');
    const storedReports = localStorage.getItem('ff_reports');
    const storedNotifs = localStorage.getItem('ff_notifs');
    const storedBlocks = localStorage.getItem('ff_blocks');
    const storedCurrentUser = localStorage.getItem('ff_current_user');

    const initialUsers = storedUsers ? JSON.parse(storedUsers) : INITIAL_USERS;
    setAllUsers(initialUsers);

    const activeUser = storedCurrentUser ? JSON.parse(storedCurrentUser) : null;
    if (activeUser) {
      setCurrentUser(activeUser);
      // Load user-specific details
      const userChats = storedChats ? JSON.parse(storedChats) : INITIAL_CHATS(activeUser.id);
      const userMessages = storedMessages ? JSON.parse(storedMessages) : INITIAL_MESSAGES(activeUser.id);
      const userNotifs = storedNotifs ? JSON.parse(storedNotifs) : INITIAL_NOTIFICATIONS(activeUser.id);
      
      setChats(userChats);
      setMessages(userMessages);
      setNotifications(userNotifs);

      // Compute connected buddies based on matches/chats
      // To keep demo simple: anyone you have a chat room with is a connected friend!
      const buddyIds = userChats.flatMap((c: Chat) => c.participantIds.filter((id: string) => id !== activeUser.id));
      setConnectedBuddiesIds(buddyIds);
    }

    setWorkoutInvites(storedInvites ? JSON.parse(storedInvites) : []);
    setReports(storedReports ? JSON.parse(storedReports) : []);
    setBlockedUsersIds(storedBlocks ? JSON.parse(storedBlocks) : []);
  }, []);

  // --- SAVE DB LOGIC ON STATE CHANGES ---
  const saveStateToLocalStorage = (key: string, data: any) => {
    localStorage.setItem(key, JSON.stringify(data));
  };

  // --- AUTH ACTIONS ---
  const handleLoginAsDemoUser = (user: User) => {
    setCurrentUser(user);
    saveStateToLocalStorage('ff_current_user', user);

    // Bootstrap user-specific chats, notifications, messages if none exist
    const storedChats = localStorage.getItem('ff_chats');
    const storedMessages = localStorage.getItem('ff_messages');
    const storedNotifs = localStorage.getItem('ff_notifs');

    const userChats = storedChats ? JSON.parse(storedChats) : INITIAL_CHATS(user.id);
    const userMessages = storedMessages ? JSON.parse(storedMessages) : INITIAL_MESSAGES(user.id);
    const userNotifs = storedNotifs ? JSON.parse(storedNotifs) : INITIAL_NOTIFICATIONS(user.id);

    setChats(userChats);
    setMessages(userMessages);
    setNotifications(userNotifs);

    // Compute buddy connections
    const buddyIds = userChats.flatMap((c: Chat) => c.participantIds.filter((id: string) => id !== user.id));
    setConnectedBuddiesIds(buddyIds);

    // Trigger welcoming Toast notification
    triggerToast("Authentication Success", `Welcome back, ${user.name}! Enjoy your workouts.`);
  };

  const handleRegisterComplete = (newUser: User) => {
    const updatedUsers = [...allUsers, newUser];
    setAllUsers(updatedUsers);
    saveStateToLocalStorage('ff_users', updatedUsers);

    setCurrentUser(newUser);
    saveStateToLocalStorage('ff_current_user', newUser);

    // Clear user chat/messages for clean profile
    setChats([]);
    setMessages([]);
    setNotifications([]);
    setConnectedBuddiesIds([]);
    setIsRegistering(false);

    triggerToast("Profile Activated!", "Your account is active. Calculate overlays in the discover section!");
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('ff_current_user');
    setChats([]);
    setMessages([]);
    setNotifications([]);
    setConnectedBuddiesIds([]);
    triggerToast("Logged Out", "You have been securely logged out.");
  };

  const handleDeleteAccount = () => {
    if (currentUser) {
      const updatedUsers = allUsers.filter(u => u.id !== currentUser.id);
      setAllUsers(updatedUsers);
      saveStateToLocalStorage('ff_users', updatedUsers);
      handleLogout();
      triggerToast("Account Deleted", "Your account data has been completely erased.");
    }
  };

  // --- DEVT SWITCH ACCOUNTS ACTIONS ---
  const handleSwitchUser = (userId: string) => {
    const targetUser = allUsers.find(u => u.id === userId);
    if (targetUser) {
      handleLoginAsDemoUser(targetUser);
    }
  };

  // --- CHAT & CONNECT ACTIONS ---
  const handleConnectWithUser = (buddyId: string) => {
    if (!currentUser) return;

    // Check if chat already exists
    const existingChat = chats.find(c => c.participantIds.includes(buddyId) && c.participantIds.includes(currentUser.id));
    if (existingChat) {
      setActiveTab('messages');
      return;
    }

    const targetBuddy = allUsers.find(u => u.id === buddyId);
    if (!targetBuddy) return;

    // Create mutual chat room
    const newChatId = 'chat_' + currentUser.id + '_' + buddyId;
    const newChat: Chat = {
      id: newChatId,
      participantIds: [currentUser.id, buddyId],
      lastMessageText: "You are now connected! Plan a joint gym workout here.",
      lastMessageTime: new Date().toISOString(),
      unreadCount: { [currentUser.id]: 0, [buddyId]: 0 },
      isTyping: { [currentUser.id]: false, [buddyId]: false }
    };

    const updatedChats = [...chats, newChat];
    setChats(updatedChats);
    saveStateToLocalStorage('ff_chats', updatedChats);

    // Create a greeting message
    const welcomeMsg: Message = {
      id: 'msg_greet_' + Date.now(),
      senderId: buddyId, // simulated initial greet from matching candidate!
      text: `Hey ${currentUser.name.split(' ')[0]}! We have a ${calculateCompatibility(currentUser, targetBuddy)}% match overlap. I notice we both like ${targetBuddy.activities[0]}! Let's schedule a session together!`,
      createdAt: new Date().toISOString(),
      read: false
    };

    const updatedMessages = [...messages, welcomeMsg];
    setMessages(updatedMessages);
    saveStateToLocalStorage('ff_messages', updatedMessages);

    // Add buddy to connections
    const updatedBuddies = [...connectedBuddiesIds, buddyId];
    setConnectedBuddiesIds(updatedBuddies);

    // Push notification
    const newNotif: Notification = {
      id: 'notif_conn_' + Date.now(),
      userId: currentUser.id,
      title: 'Mutual Match Connect!',
      body: `You connected with ${targetBuddy.name}! Hit them up in chat.`,
      type: 'Match',
      relatedId: newChatId,
      read: false,
      createdAt: new Date().toISOString()
    };
    const updatedNotifs = [...notifications, newNotif];
    setNotifications(updatedNotifs);
    saveStateToLocalStorage('ff_notifs', updatedNotifs);

    triggerToast("It's a Match!", `You connected with ${targetBuddy.name}! Say hello!`);
  };

  const handleSendMessage = (chatId: string, text: string, options?: { imageUrl?: string; location?: any; workoutInviteId?: string }) => {
    if (!currentUser) return;

    const newMsg: Message = {
      id: 'msg_user_' + Date.now(),
      senderId: currentUser.id,
      text,
      imageUrl: options?.imageUrl,
      location: options?.location,
      workoutInviteId: options?.workoutInviteId,
      createdAt: new Date().toISOString(),
      read: true
    };

    const updatedMessages = [...messages, newMsg];
    setMessages(updatedMessages);
    saveStateToLocalStorage('ff_messages', updatedMessages);

    // Update Chat room summaries
    const updatedChats = chats.map(c => {
      if (c.id === chatId) {
        return {
          ...c,
          lastMessageText: text,
          lastMessageTime: new Date().toISOString()
        };
      }
      return c;
    });
    setChats(updatedChats);
    saveStateToLocalStorage('ff_chats', updatedChats);
  };

  const handleSendWorkoutInvite = (inviteData: Omit<WorkoutInvite, 'id' | 'status' | 'createdAt'>): string => {
    const inviteId = 'invite_' + Date.now();
    const newInvite: WorkoutInvite = {
      ...inviteData,
      id: inviteId,
      status: 'Pending',
      createdAt: new Date().toISOString()
    };

    const updatedInvites = [...workoutInvites, newInvite];
    setWorkoutInvites(updatedInvites);
    saveStateToLocalStorage('ff_invites', updatedInvites);

    return inviteId;
  };

  const handleUpdateInviteStatus = (inviteId: string, status: InviteStatus) => {
    const updatedInvites = workoutInvites.map(i => {
      if (i.id === inviteId) {
        return { ...i, status };
      }
      return i;
    });
    setWorkoutInvites(updatedInvites);
    saveStateToLocalStorage('ff_invites', updatedInvites);

    // Trigger system notification
    if (currentUser) {
      const invite = workoutInvites.find(i => i.id === inviteId);
      if (invite) {
        const partnerId = invite.senderId === currentUser.id ? invite.receiverId : invite.senderId;
        const partner = allUsers.find(u => u.id === partnerId);
        
        if (partner) {
          const newNotif: Notification = {
            id: 'notif_invite_' + Date.now(),
            userId: currentUser.id,
            title: 'Schedule Updated!',
            body: `Your joint ${invite.activity} workout with ${partner.name.split(' ')[0]} was marked as: ${status}`,
            type: 'Invite',
            relatedId: inviteId,
            read: false,
            createdAt: new Date().toISOString()
          };
          setNotifications([...notifications, newNotif]);
        }
      }
    }
  };

  // --- SIMULATED RESPONSES FROM MATCHES ---
  const handleSimulatedReply = (chatId: string, senderId: string, text: string) => {
    const botMsg: Message = {
      id: 'msg_sim_' + Date.now(),
      senderId,
      text,
      createdAt: new Date().toISOString(),
      read: false
    };

    setMessages(prev => {
      const next = [...prev, botMsg];
      saveStateToLocalStorage('ff_messages', next);
      return next;
    });

    setChats(prev => {
      const next = prev.map(c => {
        if (c.id === chatId) {
          return {
            ...c,
            lastMessageText: text,
            lastMessageTime: new Date().toISOString(),
            unreadCount: {
              ...c.unreadCount,
              [currentUser?.id || '']: (c.unreadCount?.[currentUser?.id || ''] || 0) + 1
            }
          };
        }
        return c;
      });
      saveStateToLocalStorage('ff_chats', next);
      return next;
    });

    const senderUser = allUsers.find(u => u.id === senderId);
    if (senderUser && currentUser) {
      // Add notification
      const newNotif: Notification = {
        id: 'notif_msg_' + Date.now(),
        userId: currentUser.id,
        title: `Message from ${senderUser.name.split(' ')[0]}`,
        body: text,
        type: 'Message',
        relatedId: chatId,
        read: false,
        createdAt: new Date().toISOString()
      };
      setNotifications(prev => {
        const next = [...prev, newNotif];
        saveStateToLocalStorage('ff_notifs', next);
        return next;
      });

      triggerToast(`New Message from ${senderUser.name.split(' ')[0]}`, text);
    }
  };

  const handleSimulatedInviteReply = (chatId: string, senderId: string, inviteId: string, status: InviteStatus) => {
    // Updates invite array locally inside parent
    setWorkoutInvites(prev => {
      const next = prev.map(i => i.id === inviteId ? { ...i, status } : i);
      saveStateToLocalStorage('ff_invites', next);
      return next;
    });
  };

  // --- DISCONNECT & BLOCKS ---
  const handleRemoveFriend = (friendId: string) => {
    if (!currentUser) return;
    const updatedBuddies = connectedBuddiesIds.filter(id => id !== friendId);
    setConnectedBuddiesIds(updatedBuddies);

    // Delete mutual chat room
    const updatedChats = chats.filter(c => !(c.participantIds.includes(friendId) && c.participantIds.includes(currentUser.id)));
    setChats(updatedChats);
    saveStateToLocalStorage('ff_chats', updatedChats);

    triggerToast("Buddy Removed", "The connection has been safely terminated.");
  };

  const handleBlockUser = (userId: string) => {
    const updatedBlocks = [...blockedUsersIds, userId];
    setBlockedUsersIds(updatedBlocks);
    saveStateToLocalStorage('ff_blocks', updatedBlocks);

    // Disconnect if friends
    handleRemoveFriend(userId);
    triggerToast("User Blocked", "You will no longer see this user on the radar maps or directory.");
  };

  const handleUnblockUser = (userId: string) => {
    const updatedBlocks = blockedUsersIds.filter(id => id !== userId);
    setBlockedUsersIds(updatedBlocks);
    saveStateToLocalStorage('ff_blocks', updatedBlocks);
    triggerToast("User Unblocked", "Account unblocked successfully.");
  };

  // --- ADMIN ACTIONS ---
  const handleReportUser = (reportedUserId: string, reason: string, details: string) => {
    if (!currentUser) return;
    const newReport: Report = {
      id: 'report_' + Date.now(),
      reporterId: currentUser.id,
      reportedUserId,
      reason,
      details,
      status: 'Pending',
      createdAt: new Date().toISOString()
    };
    const updatedReports = [...reports, newReport];
    setReports(updatedReports);
    saveStateToLocalStorage('ff_reports', updatedReports);
    triggerToast("Complaint Filed", "Thank you. Our moderation team will audit this profile within 24 hours.");
  };

  const handleBanUser = (userId: string) => {
    const updatedUsers = allUsers.map(u => u.id === userId ? { ...u, isBanned: true } : u);
    setAllUsers(updatedUsers);
    saveStateToLocalStorage('ff_users', updatedUsers);

    // Resolve reports associated with banned user
    const updatedReports = reports.map(r => r.reportedUserId === userId ? { ...r, status: 'Banned' as const } : r);
    setReports(updatedReports);
    saveStateToLocalStorage('ff_reports', updatedReports);

    // Disconnect from buddies
    handleRemoveFriend(userId);
    triggerToast("User Account Terminated", "Account banned and removed from active listings.");
  };

  const handleUnbanUser = (userId: string) => {
    const updatedUsers = allUsers.map(u => u.id === userId ? { ...u, isBanned: false } : u);
    setAllUsers(updatedUsers);
    saveStateToLocalStorage('ff_users', updatedUsers);
    triggerToast("User Reinstated", "Account unlocked successfully.");
  };

  const handleDismissReport = (reportId: string) => {
    const updatedReports = reports.map(r => r.id === reportId ? { ...r, status: 'Dismissed' as const } : r);
    setReports(updatedReports);
    saveStateToLocalStorage('ff_reports', updatedReports);
    triggerToast("Report Dismissed", "Complaint cleared from verification queue.");
  };

  // --- PROFILE UPDATE ---
  const handleUpdateProfile = (updatedFields: Partial<User>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updatedFields };
    setCurrentUser(updatedUser);
    saveStateToLocalStorage('ff_current_user', updatedUser);

    const updatedUsers = allUsers.map(u => u.id === currentUser.id ? updatedUser : u);
    setAllUsers(updatedUsers);
    saveStateToLocalStorage('ff_users', updatedUsers);
  };

  // --- TOAST NOTIFICATIONS HELPER ---
  const triggerToast = (title: string, body: string) => {
    setShowToast({ title, body });
    setTimeout(() => setShowToast(null), 4000);
  };

  // --- UNREAD CHATS COUNT ---
  const unreadChatsCount = useMemo(() => {
    // Messages sent by others that have read === false
    return messages.filter(m => m.senderId !== currentUser?.id && !m.read).length;
  }, [messages, currentUser]);

  // Is Admin Check (Vikram is configured as admin)
  const isAdminUser = useMemo(() => {
    return currentUser?.id === 'user_vikram';
  }, [currentUser]);

  return (
    <div className="min-h-screen bg-[#121212] text-white flex flex-col font-sans selection:bg-[#E53935] selection:text-white antialiased">
      
      {currentUser ? (
        <>
          {/* Main Navigation Header */}
          <Navbar 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            currentUser={currentUser}
            allUsers={allUsers.filter(u => !u.isBanned)}
            onSwitchUser={handleSwitchUser}
            notificationsCount={unreadChatsCount}
            isAdmin={isAdminUser}
          />

          {/* Active View Router */}
          <main className="flex-1 w-full relative">
            {activeTab === 'dashboard' && (
              <Dashboard 
                currentUser={currentUser} 
                allUsers={allUsers}
                onConnect={handleConnectWithUser}
                onBlock={handleBlockUser}
                onReport={handleReportUser}
                connectedBuddiesIds={connectedBuddiesIds}
              />
            )}

            {activeTab === 'discover' && (
              <Discover 
                currentUser={currentUser} 
                allUsers={allUsers}
                onConnect={handleConnectWithUser}
                connectedBuddiesIds={connectedBuddiesIds}
              />
            )}

            {activeTab === 'messages' && (
              <ChatView 
                currentUser={currentUser}
                allUsers={allUsers}
                chats={chats}
                messages={messages}
                workoutInvites={workoutInvites}
                onSendMessage={handleSendMessage}
                onSendWorkoutInvite={handleSendWorkoutInvite}
                onUpdateInviteStatus={handleUpdateInviteStatus}
                onDeleteConversation={handleRemoveFriend} // Deletes friend chat
                onBlockUser={handleBlockUser}
                onSimulatedReply={handleSimulatedReply}
                onSimulatedInviteReply={handleSimulatedInviteReply}
              />
            )}

            {activeTab === 'friends' && (
              <FriendsView 
                currentUser={currentUser}
                allUsers={allUsers}
                connectedBuddiesIds={connectedBuddiesIds}
                workoutInvites={workoutInvites}
                onRemoveFriend={handleRemoveFriend}
                onOpenChatWith={(buddyId) => {
                  const chat = chats.find(c => c.participantIds.includes(buddyId));
                  if (chat) {
                    localStorage.setItem('ff_active_chat_id', chat.id);
                  }
                  setActiveTab('messages');
                }}
                onNavigateToDiscover={() => setActiveTab('dashboard')}
              />
            )}

            {activeTab === 'settings' && (
              <Settings 
                currentUser={currentUser}
                onUpdateProfile={handleUpdateProfile}
                onDeleteAccount={handleDeleteAccount}
                onLogout={handleLogout}
                blockedUsersIds={blockedUsersIds}
                allUsers={allUsers}
                onUnblockUser={handleUnblockUser}
              />
            )}

            {activeTab === 'admin' && isAdminUser && (
              <AdminPanel 
                allUsers={allUsers}
                reports={reports}
                onBanUser={handleBanUser}
                onDismissReport={handleDismissReport}
                onUnbanUser={handleUnbanUser}
              />
            )}
          </main>
        </>
      ) : (
        /* --- AUTH LANDING PAGE SCREEN --- */
        <div className="flex-1 flex flex-col items-center justify-center py-20 px-4 relative overflow-hidden" id="auth-landing-page">
          {/* Subtle geometric circles */}
          <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-[#E53935]/5 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-[#E53935]/5 rounded-full blur-3xl pointer-events-none" />

          {isRegistering ? (
            <div className="w-full">
              <div className="mb-4">
                <button
                  onClick={() => setIsRegistering(false)}
                  className="px-4 py-2 bg-[#1A1A1A] border border-white/10 hover:bg-[#2A2A2A] rounded-xl text-xs font-bold text-white/60 hover:text-white transition-all"
                >
                  ← Back to Sign In
                </button>
              </div>
              <Onboarding onComplete={handleRegisterComplete} />
            </div>
          ) : (
            <div className="w-full max-w-lg bg-[#1A1A1A] border border-white/10 rounded-[40px] p-8 sm:p-12 shadow-2xl space-y-8 relative z-10 text-center">
              
              {/* App Icon */}
              <div className="mx-auto w-16 h-16 bg-[#E53935] rounded-3xl flex items-center justify-center shadow-2xl shadow-[#E53935]/20">
                <Dumbbell className="text-white w-8 h-8" />
              </div>

              {/* Headings */}
              <div className="space-y-2">
                <h1 className="text-4xl font-black tracking-tighter text-white">
                  FITNESS <span className="text-[#E53935]">FRIEND</span>
                </h1>
                <p className="text-sm text-white/50 font-medium max-w-md mx-auto leading-relaxed">
                  Connect with compatible training partners based on location, preferred sports, experience levels, and schedules.
                </p>
              </div>

              {/* Sports highlight line */}
              <div className="flex flex-wrap items-center justify-center gap-1.5 py-1 text-[10px] font-bold font-mono text-white/30 uppercase tracking-wide">
                <span>GYM</span><span>•</span>
                <span>RUNNING</span><span>•</span>
                <span>PICKLEBALL</span><span>•</span>
                <span>YOGA</span><span>•</span>
                <span>CYCLING</span><span>•</span>
                <span>CLIMBING</span>
              </div>

              {/* Login Shortcut Block */}
              <div className="space-y-3">
                <button
                  onClick={() => {
                    const vikram = allUsers.find(u => u.id === 'user_vikram') || INITIAL_USERS[0];
                    handleLoginAsDemoUser(vikram);
                  }}
                  className="w-full py-4 bg-[#E53935] hover:bg-[#D32F2F] text-white font-black text-sm rounded-2xl flex items-center justify-center gap-2 shadow-xl shadow-[#E53935]/20 hover:scale-101 active:scale-99 transition-all cursor-pointer uppercase tracking-wider"
                >
                  <LogIn className="w-4.5 h-4.5" />
                  <span>SIGN IN AS VIKRAM CHANDAR</span>
                </button>

                <button
                  onClick={() => setIsRegistering(true)}
                  className="w-full py-4 bg-[#0A0A0A] border border-white/10 hover:bg-white/5 text-white/80 hover:text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2 transition-all active:scale-99 cursor-pointer uppercase tracking-wider"
                >
                  <UserPlus className="w-4.5 h-4.5 text-[#E53935]" />
                  <span>REGISTER A NEW PROFILE</span>
                </button>
              </div>

              {/* Third party logins */}
              <div className="pt-6 border-t border-white/5 text-center space-y-4">
                <span className="text-[10px] font-bold text-white/30 uppercase tracking-widest block">Third Party Sign-In</span>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => {
                      triggerToast("Google Auth Flow", "Successfully authenticated with Google Auth.");
                      const tempUser = allUsers.find(u => u.id === 'user_sarah') || INITIAL_USERS[1];
                      handleLoginAsDemoUser(tempUser);
                    }}
                    className="py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold text-white/60 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <span>Google Sign-In</span>
                  </button>
                  <button
                    onClick={() => {
                      triggerToast("Apple Auth Flow", "Successfully authenticated with Apple Auth.");
                      const tempUser = allUsers.find(u => u.id === 'user_elena') || INITIAL_USERS[3];
                      handleLoginAsDemoUser(tempUser);
                    }}
                    className="py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold text-white/60 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <span>Apple Sign-In</span>
                  </button>
                </div>
              </div>

            </div>
          )}
        </div>
      )}

      {/* --- FLOATING TOAST COMPONENT --- */}
      {showToast && (
        <div 
          className="fixed bottom-6 right-6 z-50 max-w-sm bg-[#1A1A1A] border border-[#E53935] p-4 rounded-2xl shadow-2xl flex items-start gap-3 animate-[slideIn_0.3s_ease] text-left"
          id="toast-notification"
        >
          <div className="w-8 h-8 rounded-xl bg-[#E53935]/10 border border-[#E53935]/20 flex items-center justify-center text-[#E53935] flex-shrink-0">
            <Sparkles className="w-4 h-4 fill-[#E53935]" />
          </div>
          <div>
            <h5 className="font-extrabold text-xs text-white leading-tight">{showToast.title}</h5>
            <p className="text-[11px] text-white/50 mt-1 leading-snug">{showToast.body}</p>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="py-6 border-t border-white/5 text-center bg-[#0A0A0A] text-[10px] text-white/30 font-mono tracking-wider">
        <span>FITNESS FRIEND V1.0 © 2026 • PREMIUM SPORT RECRUITER</span>
      </footer>
    </div>
  );
}
