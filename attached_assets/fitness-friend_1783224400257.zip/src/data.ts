/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { User, Match, Chat, Message, WorkoutInvite, Report, Notification, Friend, FitnessLevel, ActivityType } from './types';

// Let's create beautiful gradient avatars with fitness icons as SVG strings or CSS configurations
export const AVATARS = [
  { id: 'avatar_vikram', bg: 'linear-gradient(135deg, #11998e, #38ef7d)', emoji: '💪', label: 'Athlete Red' },
  { id: 'avatar_sarah', bg: 'linear-gradient(135deg, #ff9966, #ff5e62)', emoji: '🏃‍♀️', label: 'Runner Pink' },
  { id: 'avatar_mark', bg: 'linear-gradient(135deg, #00c6ff, #0072ff)', emoji: '🏋️‍♂️', label: 'Gym Blue' },
  { id: 'avatar_elena', bg: 'linear-gradient(135deg, #7F00FF, #E100FF)', emoji: '🧘‍♀️', label: 'Yoga Violet' },
  { id: 'avatar_carlos', bg: 'linear-gradient(135deg, #11998e, #38ef7d)', emoji: '⚽', label: 'Soccer Green' },
  { id: 'avatar_jessica', bg: 'linear-gradient(135deg, #F9D423, #FF4E50)', emoji: '🧗‍♀️', label: 'Climber Orange' },
  { id: 'avatar_david', bg: 'linear-gradient(135deg, #3a7bd5, #3a6073)', emoji: '🚴‍♂️', label: 'Cyclist Teal' },
  { id: 'avatar_charlie', bg: 'linear-gradient(135deg, #FF416C, #FF4B2B)', emoji: '🥊', label: 'Boxer Red' },
  { id: 'avatar_user', bg: 'linear-gradient(135deg, #e53935, #121212)', emoji: '⚡', label: 'You' }
];

export const INITIAL_USERS: User[] = [
  {
    id: 'user_vikram',
    name: 'Vikram Chandar',
    age: 26,
    gender: 'Male',
    profilePic: 'avatar_vikram',
    bio: 'Dedicated powerlifter and pickleball enthusiast. Looking for a partner to push limits at the gym or play a friendly match on the court!',
    locationName: 'Seattle, WA',
    coordinates: { x: 45, y: 50 },
    fitnessLevel: 'Advanced',
    primaryGoal: 'Strength',
    activities: ['Gym', 'Pickleball', 'Tennis'],
    availability: 'Both',
    preferredTime: ['Evening', 'Night'],
    maxTravelDistance: 15,
    preferredFrequency: '4x/week',
    preferences: {
      genderPreference: 'No preference',
      ageRangeMin: 20,
      ageRangeMax: 40,
      skillRangeMin: 'Intermediate',
      skillRangeMax: 'Advanced'
    },
    achievements: ['300lb Squat Club', 'Pickleball Local Champ 2026', 'Consistent 4 Months'],
    favoriteGym: '24 Hour Fitness - Downtown',
    lastActive: 'Active now'
  },
  {
    id: 'user_sarah',
    name: 'Sarah Jenkins',
    age: 25,
    gender: 'Female',
    profilePic: 'avatar_sarah',
    bio: 'Marathon training and absolute outdoor lover! Usually out running early mornings. Let’s hit the trails together or run the waterfront.',
    locationName: 'Capitol Hill, Seattle',
    coordinates: { x: 47, y: 48 }, // Close to Vikram
    fitnessLevel: 'Advanced',
    primaryGoal: 'Endurance',
    activities: ['Running', 'Hiking', 'Yoga'],
    availability: 'Weekends',
    preferredTime: ['Morning'],
    maxTravelDistance: 20,
    preferredFrequency: '3x/week',
    preferences: {
      genderPreference: 'No preference',
      ageRangeMin: 21,
      ageRangeMax: 32,
      skillRangeMin: 'Intermediate',
      skillRangeMax: 'Advanced'
    },
    achievements: ['Seattle Half Marathon Finisher', 'Peak Bagger (10 summits)', '5AM Club'],
    favoriteGym: 'Pacific Northwest Trails & Seattle Athletics',
    lastActive: 'Active 2m ago'
  },
  {
    id: 'user_mark',
    name: 'Mark Henderson',
    age: 29,
    gender: 'Male',
    profilePic: 'avatar_mark',
    bio: 'Bodybuilding enthusiast focused on hypertrophy and strength. Let’s motivate each other through heavy compounds! Gym partner wanted.',
    locationName: 'Belltown, Seattle',
    coordinates: { x: 42, y: 52 },
    fitnessLevel: 'Advanced',
    primaryGoal: 'Build muscle',
    activities: ['Gym', 'Boxing'],
    availability: 'Weekdays',
    preferredTime: ['Evening'],
    maxTravelDistance: 10,
    preferredFrequency: '4x/week',
    preferences: {
      genderPreference: 'Male',
      ageRangeMin: 24,
      ageRangeMax: 35,
      skillRangeMin: 'Intermediate',
      skillRangeMax: 'Advanced'
    },
    achievements: ['Strict Diet Consistency 180 Days', 'Bench Press PR: 275lb'],
    favoriteGym: 'Iron Works Gym',
    lastActive: 'Active 15m ago'
  },
  {
    id: 'user_elena',
    name: 'Elena Rostova',
    age: 27,
    gender: 'Female',
    profilePic: 'avatar_elena',
    bio: 'Vinyasa yoga teacher and outdoor rock climber. Looking to practice yoga, do core sessions, or go bouldering. Mind-muscle connection is key!',
    locationName: 'Fremont, Seattle',
    coordinates: { x: 44, y: 42 },
    fitnessLevel: 'Intermediate',
    primaryGoal: 'General fitness',
    activities: ['Yoga', 'Climbing', 'Hiking'],
    availability: 'Both',
    preferredTime: ['Morning', 'Afternoon'],
    maxTravelDistance: 15,
    preferredFrequency: '3x/week',
    preferences: {
      genderPreference: 'No preference',
      ageRangeMin: 22,
      ageRangeMax: 35,
      skillRangeMin: 'Beginner',
      skillRangeMax: 'Advanced'
    },
    achievements: ['Yoga Alliance 200hr Certified', 'V5 Bouldering Project Completed'],
    favoriteGym: 'Seattle Bouldering Project',
    lastActive: 'Active 1h ago'
  },
  {
    id: 'user_carlos',
    name: 'Carlos Mendez',
    age: 24,
    gender: 'Male',
    profilePic: 'avatar_carlos',
    bio: 'Former college soccer player. Playing recreational soccer, basketball, and hiking. Let’s kick the ball around or run drills!',
    locationName: 'Ballard, Seattle',
    coordinates: { x: 38, y: 44 },
    fitnessLevel: 'Advanced',
    primaryGoal: 'Sports',
    activities: ['Soccer', 'Basketball', 'Running'],
    availability: 'Weekends',
    preferredTime: ['Afternoon', 'Evening'],
    maxTravelDistance: 25,
    preferredFrequency: '2x/week',
    preferences: {
      genderPreference: 'No preference',
      ageRangeMin: 20,
      ageRangeMax: 30,
      skillRangeMin: 'Intermediate',
      skillRangeMax: 'Advanced'
    },
    achievements: ['NCAA Div III Player', 'Hiking Mount Rainier Sky Trail'],
    favoriteGym: 'Ballard Community Center Fields',
    lastActive: 'Active 3h ago'
  },
  {
    id: 'user_jessica',
    name: 'Jessica Wong',
    age: 28,
    gender: 'Female',
    profilePic: 'avatar_jessica',
    bio: 'Intermediate gym goer focused on fat loss and endurance. Enjoy hiking and pickleball on sunny weekends! Let’s stay accountable together.',
    locationName: 'Kirkland, WA',
    coordinates: { x: 62, y: 46 }, // Across Lake Washington (a bit further)
    fitnessLevel: 'Intermediate',
    primaryGoal: 'Lose weight',
    activities: ['Gym', 'Hiking', 'Pickleball'],
    availability: 'Both',
    preferredTime: ['Evening'],
    maxTravelDistance: 30,
    preferredFrequency: '3x/week',
    preferences: {
      genderPreference: 'Female',
      ageRangeMin: 23,
      ageRangeMax: 34,
      skillRangeMin: 'Beginner',
      skillRangeMax: 'Intermediate'
    },
    achievements: ['Lost 25 lbs!', 'Hiking Mailbox Peak Completed'],
    favoriteGym: 'Gold Gym - Kirkland',
    lastActive: 'Active 4h ago'
  },
  {
    id: 'user_david',
    name: 'David Miller',
    age: 31,
    gender: 'Male',
    profilePic: 'avatar_david',
    bio: 'Avid road cyclist and climber. Doing 50-mile rides on weekends. Let’s find new cycling routes, pedal around Lake Washington, or head to the climbing gym.',
    locationName: 'Bellevue, WA',
    coordinates: { x: 58, y: 52 },
    fitnessLevel: 'Advanced',
    primaryGoal: 'Endurance',
    activities: ['Cycling', 'Climbing', 'Gym'],
    availability: 'Weekends',
    preferredTime: ['Morning', 'Afternoon'],
    maxTravelDistance: 40,
    preferredFrequency: '2x/week',
    preferences: {
      genderPreference: 'No preference',
      ageRangeMin: 25,
      ageRangeMax: 45,
      skillRangeMin: 'Intermediate',
      skillRangeMax: 'Advanced'
    },
    achievements: ['100 Mile Century Ride Finisher', 'Climbed Cascade Pass'],
    favoriteGym: 'Bellevue Club & Outdoors',
    lastActive: 'Active 1d ago'
  }
];

/**
 * Weighted Compatibility Matching Algorithm
 * Location: 30%
 * Activity overlap: 25%
 * Skill level: 20%
 * Availability: 15%
 * Goals: 10%
 */
export function calculateCompatibility(u1: User, u2: User): number {
  let score = 0;

  // 1. Location (30%)
  const dx = u1.coordinates.x - u2.coordinates.x;
  const dy = u1.coordinates.y - u2.coordinates.y;
  const rawDist = Math.sqrt(dx * dx + dy * dy);
  const distanceMiles = rawDist * 0.7; // Scale coordinates to miles
  let locationScore = 0;
  if (distanceMiles <= 5) {
    locationScore = 100;
  } else if (distanceMiles >= 40) {
    locationScore = 20;
  } else {
    // Linear interpolation
    locationScore = 100 - ((distanceMiles - 5) / 35) * 80;
  }
  score += locationScore * 0.3;

  // 2. Activity overlap (25%)
  const overlappingActivities = u1.activities.filter(act => u2.activities.includes(act));
  let activityScore = 0;
  if (overlappingActivities.length > 0) {
    // Ratio of overlap to whichever user has more activities to reward high commonality
    const maxActivities = Math.max(u1.activities.length, u2.activities.length, 1);
    const minActivities = Math.min(u1.activities.length, u2.activities.length, 1);
    const overlapRatio = (overlappingActivities.length / minActivities);
    activityScore = Math.min(overlapRatio * 100, 100);
    // Add bonus if more than one overlaps
    if (overlappingActivities.length > 1) {
      activityScore = Math.min(activityScore + 15, 100);
    }
  } else {
    activityScore = 0;
  }
  score += activityScore * 0.25;

  // 3. Skill level (20%)
  const levels: FitnessLevel[] = ['Beginner', 'Intermediate', 'Advanced'];
  const idx1 = levels.indexOf(u1.fitnessLevel);
  const idx2 = levels.indexOf(u2.fitnessLevel);
  const diff = Math.abs(idx1 - idx2);
  let skillScore = 0;
  if (diff === 0) skillScore = 100;
  else if (diff === 1) skillScore = 65;
  else skillScore = 25;
  score += skillScore * 0.20;

  // 4. Availability (15%)
  // Day overlap: 7.5%
  let dayOverlap = false;
  if (u1.availability === 'Both' || u2.availability === 'Both') {
    dayOverlap = true;
  } else if (u1.availability === u2.availability) {
    dayOverlap = true;
  }
  const dayScore = dayOverlap ? 100 : 30;

  // Time overlap: 7.5%
  const timeOverlap = u1.preferredTime.filter(t => u2.preferredTime.includes(t));
  const timeScore = timeOverlap.length > 0 ? 100 : 25;

  score += ((dayScore + timeScore) / 2) * 0.15;

  // 5. Goals (10%)
  let goalScore = 0;
  if (u1.primaryGoal === u2.primaryGoal) {
    goalScore = 100;
  } else {
    // Check if goal categories are complementary (Strength & Muscle, Endurance & Cardio/Sports)
    const complementary: { [key: string]: string[] } = {
      'Strength': ['Build muscle', 'General fitness'],
      'Build muscle': ['Strength', 'General fitness'],
      'Endurance': ['Sports', 'General fitness'],
      'Sports': ['Endurance', 'General fitness'],
      'Lose weight': ['General fitness', 'Endurance'],
      'General fitness': ['Lose weight', 'Strength', 'Build muscle', 'Endurance', 'Sports']
    };
    if (complementary[u1.primaryGoal]?.includes(u2.primaryGoal)) {
      goalScore = 70;
    } else {
      goalScore = 40;
    }
  }
  score += goalScore * 0.10;

  return Math.round(score);
}

// Simulated conversation pre-population
export const INITIAL_CHATS = (currentUserId: string): Chat[] => {
  if (currentUserId === 'user_vikram') {
    return [
      {
        id: 'chat_vikram_sarah',
        participantIds: ['user_vikram', 'user_sarah'],
        lastMessageText: "Hey Sarah! Saw you're training for the half marathon. Do you ever do trail runs around Capitol Hill?",
        lastMessageTime: new Date(Date.now() - 3600000 * 2).toISOString(), // 2 hours ago
        unreadCount: { 'user_vikram': 0, 'user_sarah': 1 }
      },
      {
        id: 'chat_vikram_mark',
        participantIds: ['user_vikram', 'user_mark'],
        lastMessageText: "Awesome, let's crush that leg session on Monday. 6 PM at Iron Works works for me!",
        lastMessageTime: new Date(Date.now() - 3600000 * 24).toISOString(), // 1 day ago
        unreadCount: { 'user_vikram': 0, 'user_mark': 0 }
      }
    ];
  }
  return [];
};

export const INITIAL_MESSAGES = (currentUserId: string): Message[] => {
  if (currentUserId === 'user_vikram') {
    return [
      {
        id: 'msg_v_m_1',
        senderId: 'user_mark',
        text: "Hey Vikram! Your lift PRs are seriously impressive. Looking for a spotter or someone to alternate sets with?",
        createdAt: new Date(Date.now() - 3600000 * 24.5).toISOString(),
        read: true
      },
      {
        id: 'msg_v_m_2',
        senderId: 'user_vikram',
        text: "Thanks Mark! Absolutely. Always good to have an advanced lifter around for heavy days. What days are you at Iron Works?",
        createdAt: new Date(Date.now() - 3600000 * 24.2).toISOString(),
        read: true
      },
      {
        id: 'msg_v_m_3',
        senderId: 'user_mark',
        text: "Usually Monday, Wednesday and Friday evenings. I do heavy squats and deadlifts.",
        createdAt: new Date(Date.now() - 3600000 * 24.1).toISOString(),
        read: true
      },
      {
        id: 'msg_v_m_4',
        senderId: 'user_vikram',
        text: "Awesome, let's crush that leg session on Monday. 6 PM at Iron Works works for me!",
        createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
        read: true
      },
      {
        id: 'msg_v_s_1',
        senderId: 'user_vikram',
        text: "Hey Sarah! Saw you're training for the half marathon. Do you ever do trail runs around Capitol Hill?",
        createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
        read: true
      }
    ];
  }
  return [];
};

export const INITIAL_NOTIFICATIONS = (currentUserId: string): Notification[] => {
  return [
    {
      id: 'notif_1',
      userId: currentUserId,
      title: 'New Match!',
      body: 'You and Sarah Jenkins connected! Send her a message to arrange a workout.',
      type: 'Match',
      relatedId: 'chat_vikram_sarah',
      read: false,
      createdAt: new Date(Date.now() - 3600000 * 2.2).toISOString()
    },
    {
      id: 'notif_2',
      userId: currentUserId,
      title: 'Workout Invitation',
      body: 'Mark Henderson sent you a workout invitation for heavy lifting.',
      type: 'Invite',
      relatedId: 'chat_vikram_mark',
      read: true,
      createdAt: new Date(Date.now() - 3600000 * 24.6).toISOString()
    }
  ];
};

export const CHAT_BOT_RESPONSES: { [key: string]: string[] } = {
  'user_sarah': [
    "Hey! Yes, I love Capitol Hill trail runs! The Interlaken Park trail is super nice. Do you run trails or stick to the gym?",
    "That sounds great. I'm usually free mornings around 7 AM. Would a weekend morning jog work for you?",
    "Perfect! Let’s do 5 miles. I'll send an invitation so we can lock in the time.",
    "Woohoo! Can't wait! See you then. Don't forget water!"
  ],
  'user_mark': [
    "Yes, heavy squats on Monday! I'm shooting for a new PR.",
    "Iron Works is perfect. They have great squat racks. See you at 6 PM!",
    "No problem, I'll send an official workout invitation so it shows up in our schedule."
  ],
  'user_elena': [
    "Namaste! Yes, bouldering is amazing for core. Have you climbed at Seattle Bouldering Project before?",
    "Let’s meet up for a session. I can show you some neat routes!",
    "Awesome. Tuesday afternoon works for me. Let’s do it!"
  ],
  'user_carlos': [
    "Hey! We're doing a friendly soccer scrimmage this Saturday. Want to join us?",
    "Sweet! It's super casual, we play on the turf fields. I'll send you the location.",
    "Awesome, see you on the field!"
  ]
};
